$(document).on("keypress", ":input:not(textarea):not([type=submit])", function(event) {
    if (event.keyCode == 13) {
        event.preventDefault();
    }
});

$(".admin_form").submit(function () {
         $(this).find(':submit').attr('disabled', 'disabled');
		 $(this).find(':submit').html('');
		 $(this).find(':submit').html('Please wait...');
		 swal("Processing...", "Please wait for a while.", "warning")
        return true;
    });
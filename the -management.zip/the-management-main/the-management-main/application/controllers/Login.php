<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('login_model');
		date_default_timezone_set("Asia/Kolkata");
	}

	public function index()
	{
		if($login_details = $this->input->post())
		{
			$validate = $this->login_model->validate_admin($login_details);
			if($validate)
			{
				$validate = json_decode(json_encode($validate), True);
				$this->session->set_userdata($validate);
				 return redirect('admin');				
			}
			else
			{
				 $this->session->set_flashdata('login_failed','Invalid login details');
				 return redirect('login');
			}
		}
		else
		{
			$this->load->view('login');
		}
	}
}

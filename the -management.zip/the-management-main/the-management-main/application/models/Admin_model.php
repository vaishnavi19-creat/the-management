<?php

Class Admin_model extends CI_Model
{
	 public function get_id($table_name,$field_name)
	{
		$this->load->helper('string');
		$rand_num = rand(15,30);
		$random_string = random_string('alnum', $rand_num);
		$is_unique = $this->check_unique($table_name,$field_name,$random_string);
		if($is_unique)
		{
			$this->get_id($table_name,$field_name);
		}
		else
		{
			return $random_string;
		}
	}
	
	public function check_unique($table_name,$field_name,$match_with)
	{
		$is_match = $this->db->select('*')->from($table_name)->where([$field_name=>$match_with])->get();
		return $is_match->row();
	}	
	public function get_shop_details()
	{
		$shop_details = $this->db->select('*')->from('shop_mstr')->where('shop_id',1)->get();
		return $shop_details->row();
	}
	public function update_shop_details($shop_input_details)
	{
		$shop_input_details = $this->security->xss_clean($shop_input_details);
		return $this->db->where('shop_id',1)->update('shop_mstr',$shop_input_details);
	}
	public function get_all_products_count()
	{
		$all_products_count = $this->db->select('count(product_id)as total_count')->from('product_mstr')->where(['product_status'=>1])->get();
		return $all_products_count->row();
	}
	public function get_all_customers_count()
	{
		$all_customers_count = $this->db->select('count(customer_id)as total_count,sum(customer_outstand) as total_outstand')->from('customer_mstr')->where(['customer_status'=>1])->get();
		return $all_customers_count->row();
	}
	public function get_all_vendors_count()
	{
		$all_vendors_count = $this->db->select('count(vendor_id)as total_count,sum(vendor_outstand) as total_outstand')->from('vendor_mstr')->where(['vendor_status'=>1])->get();
		return $all_vendors_count->row();
	}
	public function all_min_stocked_count()
	{
		$all_products_count = $this->db->select('count(product_id)as total_count')->from('product_mstr')->where(['product_status'=>1])->where('product_stock <= product_min_stock')->get();
		return $all_products_count->row();
	}
	public function all_min_stocked($limit,$offset)
	{
		$all_products = $this->db->select('product_mstr.*,vendor_mstr.*,group_concat(tax_mstr.tax_name) taxes')->from('product_mstr')->where(['product_status'=>1])->where('product_stock <= product_min_stock')->join('vendor_mstr','product_mstr.product_vendor_code=vendor_mstr.vendor_id','left outer')->join('tax_mstr','FIND_IN_SET(tax_mstr.tax_id, product_mstr.product_taxes) > 0','left outer')->group_by('product_mstr.product_id')->limit($limit,$offset)->get();
		return $all_products->result();
	}
	public function todays_invoices_count()
	{
		$todays_invoices = $this->db->select('count(bill_no) as total_count, sum(final_amount) as total_sale')->from('bill_mstr')->like(['bill_date'=>date('Y-m-d')])->get();
		return $todays_invoices->row();
	}
	public function add_tax($tax_details)
	{
		$tax_details = $this->security->xss_clean($tax_details);
		$reg_id = $this->get_id('tax_mstr','tax_id');
		$tax_details['tax_id'] = $reg_id;
		$tax_details['tax_added_date'] = date('Y-m-d H:i:s');
		return $this->db->insert('tax_mstr',$tax_details);
	}
	public function get_taxes()
	{
		$all_taxes = $this->db->select('*')->where(['tax_status'=>1])->from('tax_mstr')->get();
		return $all_taxes->result();
	}
	public function update_tax($tax_details,$tax_id)
	{
		$tax_details = $this->security->xss_clean($tax_details);
		return $this->db->where(['tax_id'=>$tax_id,'tax_status'=>1])->update('tax_mstr',$tax_details);
	}
	public function get_tax($tax_id)
	{
		$tax_details = $this->db->select('*')->from('tax_mstr')->where(['tax_id'=>$tax_id])->get();
		return $tax_details->row();
	}
	public function delete_tax($tax_id)
	{
		return $this->db->where(['tax_id'=>$tax_id])->update('tax_mstr',['tax_status'=>'0']);
	}
	public function add_vendor($vendor_details)
	{
		$vendor_details = $this->security->xss_clean($vendor_details);
		$this->db->trans_begin();
		$reg_id = $this->get_id('vendor_mstr','vendor_id');
		$vendor_details['vendor_id'] = $reg_id;
		
		
		
		$transaction_date = $vendor_details['v_transaction_date'] !== null ? $vendor_details['v_transaction_date'] : date('Y-m-d');
		
		unset($vendor_details['v_transaction_date']);
		
		$vendor_details['vendor_added_date'] = date($transaction_date);
		$add_vendor_mstr = $this->db->insert('vendor_mstr',$vendor_details);
		$tr_id = $this->get_id('vendor_transactions','v_transaction_id');
		$add_vendor_tran = $this->db->insert('vendor_transactions',['v_transaction_id'=>$tr_id,'vendor_id'=>$reg_id,'v_transaction_date'=>date($transaction_date),'v_transaction_discription'=>'Initial balance(Prev.)','v_transaction_amount'=>$vendor_details['vendor_outstand']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	public function get_vendors()
	{
		$all_vendors = $this->db->select('*')->from('vendor_mstr')->where(['vendor_status'=>1])->get();
		return $all_vendors->result();
	}
	public function get_searched_vendors_num($search_array)
	{
		$all_vendors = $this->db->select('count(vendor_id) as total_count')->from('vendor_mstr')->where(['vendor_status'=>1]);
		if($search_array['vendor_name'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_name'=>$search_array['vendor_name']]);
			$this->db->group_end();
		}
		if($search_array['vendor_address'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_address'=>$search_array['vendor_address']]);
			$this->db->group_end();
		}
		if($search_array['vendor_contact_no'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_contact_no'=>$search_array['vendor_contact_no']]);
			$this->db->group_end();
		}
		if($search_array['vendor_contact_person'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_contact_person'=>$search_array['vendor_contact_person']]);
			$this->db->group_end();
		}
		$all_vendors = $this->db->get();
		return $all_vendors->row();
	}
	public function get_searched_vendors($search_array,$limit,$offset)
	{
		$all_vendors = $this->db->select('*')->from('vendor_mstr')->where(['vendor_status'=>1]);
		if($search_array['vendor_name'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_name'=>$search_array['vendor_name']]);
			$this->db->group_end();
		}
		if($search_array['vendor_address'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_address'=>$search_array['vendor_address']]);
			$this->db->group_end();
		}
		if($search_array['vendor_contact_no'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_contact_no'=>$search_array['vendor_contact_no']]);
			$this->db->group_end();
		}
		if($search_array['vendor_contact_person'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_contact_person'=>$search_array['vendor_contact_person']]);
			$this->db->group_end();
		}
		$all_vendors = $this->db->limit($limit,$offset)->get();
		return $all_vendors->result();
	}
	public function get_vendor($vendor_id)
	{
		$vendor_details = $this->db->select('*')->from('vendor_mstr')->where(['vendor_id'=>$vendor_id,'vendor_status'=>1])->get();
		return $vendor_details->row();
	}
	public function update_vendor($vendor_details,$vendor_id)
	{
		$vendor_details = $this->security->xss_clean($vendor_details);
		$this->db->trans_begin();
		$update_vendor = $this->db->where(['vendor_id'=>$vendor_id])->update('vendor_mstr',$vendor_details);
		$tr_id = $this->get_id('vendor_transactions','v_transaction_id');
		$add_vendor_tran = $this->db->insert('vendor_transactions',['v_transaction_id'=>$tr_id,'vendor_id'=>$vendor_id,'v_transaction_date'=>date('Y-m-d H:i'),'v_transaction_discription'=>'Updated Entry','v_transaction_amount'=>$vendor_details['vendor_outstand']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	public function delete_vendor($vendor_id)
	{
		$this->db->trans_begin();
		$update_vendor = $this->db->where(['vendor_id'=>$vendor_id])->update('vendor_mstr',['vendor_status'=>0]);
		$tr_id = $this->get_id('vendor_transactions','v_transaction_id');
		$add_vendor_tran = $this->db->insert('vendor_transactions',['v_transaction_id'=>$tr_id,'vendor_id'=>$vendor_id,'v_transaction_date'=>date('Y-m-d H:i'),'v_transaction_discription'=>'Deleted Vendor']);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	public function add_customer($customer_details)
	{
		$customer_details = $this->security->xss_clean($customer_details);
		$this->db->trans_begin();
		$reg_id = $this->get_id('customer_mstr','customer_id');
		$customer_details['customer_id'] = $reg_id;
		$customer_details['customer_added_date'] = date('Y-m-d H:i:s');
		$add_customer_mstr = $this->db->insert('customer_mstr',$customer_details);
		$tr_id = $this->get_id('customer_transactions','c_transaction_id');
		$add_customer_tran = $this->db->insert('customer_transactions',['c_transaction_id'=>$tr_id,'customer_id'=>$reg_id,'c_transaction_date'=>date('Y-m-d H:i'),'c_transaction_discription'=>'Initial balance(Prev.)','c_transaction_amount'=>$customer_details['customer_outstand']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	public function get_customers()
	{
		$all_customers = $this->db->select('*')->from('customer_mstr')->where(['customer_status'=>1])->get();
		return $all_customers->result();
	}
	public function get_searched_customers_num($search_array)
	{
		$all_customers = $this->db->select('count(customer_id) as total_count')->from('customer_mstr')->where(['customer_status'=>1]);
		if($search_array['customer_name'])
		{
			$this->db->group_start();
			$this->db->like(['customer_name'=>$search_array['customer_name']]);
			$this->db->group_end();
		}
		if($search_array['customer_address'])
		{
			$this->db->group_start();
			$this->db->like(['customer_address'=>$search_array['customer_address']]);
			$this->db->group_end();
		}
		if($search_array['customer_contact_no'])
		{
			$this->db->group_start();
			$this->db->like(['customer_contact_no'=>$search_array['customer_contact_no']]);
			$this->db->group_end();
		}
		if($search_array['customer_contact_person'])
		{
			$this->db->group_start();
			$this->db->like(['customer_contact_person'=>$search_array['customer_contact_person']]);
			$this->db->group_end();
		}
		$all_customers = $this->db->get();
		return $all_customers->row();
	}
	public function get_searched_customers($search_array,$limit,$offset)
	{
		$all_customers = $this->db->select('*')->from('customer_mstr')->where(['customer_status'=>1]);
		if($search_array['customer_name'])
		{
			$this->db->group_start();
			$this->db->like(['customer_name'=>$search_array['customer_name']]);
			$this->db->group_end();
		}
		if($search_array['customer_address'])
		{
			$this->db->group_start();
			$this->db->like(['customer_address'=>$search_array['customer_address']]);
			$this->db->group_end();
		}
		if($search_array['customer_contact_no'])
		{
			$this->db->group_start();
			$this->db->like(['customer_contact_no'=>$search_array['customer_contact_no']]);
			$this->db->group_end();
		}
		if($search_array['customer_contact_person'])
		{
			$this->db->group_start();
			$this->db->like(['customer_contact_person'=>$search_array['customer_contact_person']]);
			$this->db->group_end();
		}
		$all_customers = $this->db->limit($limit,$offset)->get();
		return $all_customers->result();
	}
	public function get_customer($customer_id)
	{
		$customer_details = $this->db->select('*')->from('customer_mstr')->where(['customer_id'=>$customer_id,'customer_status'=>1])->get();
		return $customer_details->row();
	}
	public function update_customer($customer_details,$customer_id)
	{
		$customer_details = $this->security->xss_clean($customer_details);
		$this->db->trans_begin();
		$update_customer = $this->db->where(['customer_id'=>$customer_id])->update('customer_mstr',$customer_details);
		$tr_id = $this->get_id('customer_transactions','c_transaction_id');
		$add_customer_tran = $this->db->insert('customer_transactions',['c_transaction_id'=>$tr_id,'customer_id'=>$customer_id,'c_transaction_date'=>date('Y-m-d H:i'),'c_transaction_discription'=>'Updated Entry','c_transaction_amount'=>$customer_details['customer_outstand']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	public function delete_customer($customer_id)
	{
		$this->db->trans_begin();
		$update_customer = $this->db->where(['customer_id'=>$customer_id])->update('customer_mstr',['customer_status'=>0]);
		$tr_id = $this->get_id('customer_transactions','c_transaction_id');
		$add_customer_tran = $this->db->insert('customer_transactions',['c_transaction_id'=>$tr_id,'customer_id'=>$customer_id,'c_transaction_date'=>date('Y-m-d H:i'),'c_transaction_discription'=>'Deleted customer']);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}

	//adding products
	public function add_product($product_details)
	{
		$product_details = $this->security->xss_clean($product_details);
		if(count($product_details['product_taxes']) > 0)
		{
			$taxes = implode($product_details['product_taxes'],',');
			$product_details['product_taxes'] = $taxes;
		}
		else
		{
			$product_details['product_taxes'] = '';
		}
		$reg_id = $this->get_id('product_mstr','product_id');
		$product_details['product_id'] = $reg_id;
		$product_details['product_added_date'] = date('Y-m-d H:i:s');
		return $this->db->insert('product_mstr',$product_details);
	}
	public function get_products()
	{
		$all_products = $this->db->select('product_mstr.*,vendor_mstr.*,group_concat(tax_mstr.tax_name) taxes')->from('product_mstr')->where(['product_status'=>1])->join('vendor_mstr','product_mstr.product_vendor_code=vendor_mstr.vendor_id','left outer')->join('tax_mstr','FIND_IN_SET(tax_mstr.tax_id, product_mstr.product_taxes) > 0','left outer')->group_by('product_mstr.product_id')->get();
		return $all_products->result();
	}
	public function get_searched_products_num($search_array)
	{
		$product_details = $this->db->select('count(product_id) as total_count')->from('product_mstr')->where(['product_status'=>1]);		
		
		if($search_array['product_name'])
		{
			$this->db->group_start();
			$this->db->like(['product_name'=>$search_array['product_name']]);
			$this->db->group_end();
		}

		//added    expiry date and batch no
        if($search_array['product_expiry_date'])
		{
			$this->db->group_start();
			$this->db->like(['product_expiry_date'=>$search_array['product_expiry_date']]);
			$this->db->group_end();
		}

		if($search_array['product_batch_no'])
		{
			$this->db->group_start();
			$this->db->like(['product_batch_no'=>$search_array['product_batch_no']]);
			$this->db->group_end();
		}

		if($search_array['product_hsn'])
		{
			$this->db->group_start();
			$this->db->like(['product_hsn_code'=>$search_array['product_hsn']]);
			$this->db->group_end();
		}
		if($search_array['product_vendor_name'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_name'=>$search_array['product_vendor_name']]);
			$this->db->group_end();
		}
		if($search_array['product_discription'])
		{
			$this->db->group_start();
			$this->db->like(['product_discription'=>$search_array['product_discription']]);
			$this->db->group_end();
		}
		
		$product_details = $this->db->join('vendor_mstr','product_mstr.product_vendor_code=vendor_mstr.vendor_id','left outer')->get();
		return $product_details->row();
	}
	public function get_searched_products($search_array,$limit,$offset)
	{
		$product_details = $this->db->select('product_mstr.*,vendor_mstr.*,GROUP_CONCAT(tax_mstr.tax_name) as taxes')->from('product_mstr')->where(['product_status'=>1]);		
		
		if($search_array['product_name'])
		{
			$this->db->group_start();
			$this->db->like(['product_name'=>$search_array['product_name']]);
			$this->db->group_end();
		}
		if($search_array['product_hsn'])
		{
			$this->db->group_start();
			$this->db->like(['product_hsn_code'=>$search_array['product_hsn']]);
			$this->db->group_end();
		}
		if($search_array['product_vendor_name'])
		{
			$this->db->group_start();
			$this->db->like(['vendor_name'=>$search_array['product_vendor_name']]);
			$this->db->group_end();
		}
		if($search_array['product_discription'])
		{
			$this->db->group_start();
			$this->db->like(['product_discription'=>$search_array['product_discription']]);
			$this->db->group_end();
		}
		
		$product_details = $this->db->join('vendor_mstr','product_mstr.product_vendor_code=vendor_mstr.vendor_id','left outer')->join('tax_mstr','FIND_IN_SET(tax_mstr.tax_id, product_mstr.product_taxes)','left outer')->group_by('product_mstr.product_id')->limit($limit,$offset)->get();
		
		return $product_details->result();
	}
	public function get_product($product_id)
	{
		$product_details = $this->db->select('product_mstr.*,vendor_mstr.*,group_concat(tax_mstr.tax_name) taxes,group_concat(tax_mstr.tax_amount) amounts')->from('product_mstr')->where(['product_status'=>1,'product_id'=>$product_id])->join('vendor_mstr','product_mstr.product_vendor_code=vendor_mstr.vendor_id','left outer')->join('tax_mstr','FIND_IN_SET(tax_mstr.tax_id, product_mstr.product_taxes) > 0','left outer')->group_by('product_mstr.product_id')->get();
		return $product_details->row();
	}
	public function check_duplicate_value($table_name,$required_field,$required_field_value,$id_field,$id_field_value)
	{
		$get_details = $this->db->select('*')->from($table_name)->where([$required_field=>$required_field_value,$id_field.'!=' => $id_field_value])->get();
		return $get_details->result();
	}
	public function update_product($product_details,$product_id)
	{
		$product_details = $this->security->xss_clean($product_details);
		if(count($product_details['product_taxes']) > 0)
		{
			$taxes = implode($product_details['product_taxes'],',');
			$product_details['product_taxes'] = $taxes;
		}
		else
		{
			$product_details['product_taxes'] = '';
		}
		return $this->db->where(['product_id'=>$product_id,'product_status'=>1])->update('product_mstr',$product_details);
	}
	public function delete_product($product_id)
	{
		return $this->db->where(['product_id'=>$product_id,'product_status'=>1])->update('product_mstr',['product_status'=>0]);
	}
	public function create_purchase_entry($purchase_details)
	{
		$purchase_details = $this->security->xss_clean($purchase_details);
		$this->db->trans_begin();
		$remained = $purchase_details['total_amount'] - $purchase_details['paid_amount'];
		$transaction_date = $purchase_details['transaction_date'] !== '' ? date($purchase_details['transaction_date']) : date('Y-m-d H:i');
		//Update customrer outstanding
		$update_vendor_outstand = $this->db->where(['vendor_id'=>$purchase_details['vendor_id']])->set('vendor_outstand', 'vendor_outstand + '.$remained, FALSE)->update('vendor_mstr');
		$tr_id = $this->get_id('vendor_transactions','v_transaction_id');
		$add_vendor_tran = $this->db->insert('vendor_transactions',['v_transaction_id'=>$tr_id,'vendor_id'=>$purchase_details['vendor_id'],'v_transaction_date'=>$transaction_date,'v_transaction_discription'=>'Purchased of bill no'.$purchase_details['invoice_no'].'. Paid '.$purchase_details['paid_amount'].' And total amount'.$purchase_details['total_amount'],'v_transaction_amount'=>$purchase_details['paid_amount'], 'v_transaction_note'=>$purchase_details['note'], 'v_transaction_total_amount'=> $purchase_details['total_amount']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return $bill_id;
		}
	}
	public function add_tax_invoice($invoice_details)
	{
		$invoice_details = $this->security->xss_clean($invoice_details);
		$this->db->trans_begin();
		$customer_id = $invoice_details['customer_id'];
		if($invoice_details['customer_id'] == '')
		{
			$customer_array = array('customer_name'=>$invoice_details['customer_name'],'customer_address'=>$invoice_details['customer_address'],'customer_contact_no'=>$invoice_details['customer_contact_no'],'customer_contact_person'=>$invoice_details['customer_contact_person'],'customer_email_id'=>$invoice_details['customer_email_id'],'customer_outstand'=>$invoice_details['customer_outstand'],'customer_gst_no'=>$invoice_details['customer_gst_no']);
			$customer_id = $this->get_id('customer_mstr','customer_id');
			$customer_array['customer_id'] = $customer_id;
			$customer_array['customer_added_date'] = date('Y-m-d H:i:s');
			$add_customer_mstr = $this->db->insert('customer_mstr',$customer_array);
			$tr_id = $this->get_id('customer_transactions','c_transaction_id');
			$add_customer_tran = $this->db->insert('customer_transactions',['c_transaction_id'=>$tr_id,'customer_id'=>$customer_id,'c_transaction_date'=>date('Y-m-d H:i'),'c_transaction_discription'=>'Initial balance(Prev.)','c_transaction_amount'=>$customer_array['customer_outstand']]);
		}
		$bill_id = $this->get_id('bill_mstr','bill_id');
		$bill_no = date('YmdHism');
		$insert_bill = $this->db->insert('bill_mstr',['bill_id'=>$bill_id,'bill_no'=>$bill_no,'bill_date'=>date('Y-m-d H:i:s'),'customer_id'=>$customer_id,'tax_bill'=>'1','total_amount'=>$invoice_details['total_amount'],'discount_amount'=>$invoice_details['discount_amount'],'final_amount'=>$invoice_details['final_amount'],'paid_amount'=>$invoice_details['paid_amount'],'remained_amount'=>$invoice_details['remained_amount']]);
		
		//Insert products in billed product_added_date
		for($i=0;$i<count($invoice_details['product_id']);$i++)
		{
			$tr_id = $this->get_id('billed_product_mstr','tr_id');
			$product_id = $invoice_details['product_id'][$i];
			$product_quantity = $invoice_details['product_quantity'][$i];
			$product_rate = $invoice_details['product_rate'][$i];
			$applied_taxes = $invoice_details['product_taxes'][$i];
			$insert_billed_products = $this->db->insert('billed_product_mstr',['tr_id'=>$tr_id,'bill_id'=>$bill_id,'product_id'=>$product_id,'product_quantity'=>$product_quantity,'product_rate'=>$product_rate,'applied_taxes'=>$applied_taxes]);
			//Update product stock
			$update_stock = $this->db->where(['product_id'=>$product_id])->set('product_stock', 'product_stock-'.$product_quantity, FALSE)->update('product_mstr');
		}
		//Update customrer outstanding
		$update_customer_outstand = $this->db->where(['customer_id'=>$customer_id])->set('customer_outstand', 'customer_outstand + '.$invoice_details['remained_amount'], FALSE)->update('customer_mstr');
		$tr_id = $this->get_id('customer_transactions','c_transaction_id');
		$add_customer_tran2 = $this->db->insert('customer_transactions',['c_transaction_id'=>$tr_id,'customer_id'=>$customer_id,'c_transaction_date'=>date('Y-m-d H:i'),'c_transaction_discription'=>'Purchased of bill no'.$bill_no,'c_transaction_amount'=>$invoice_details['remained_amount']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return $bill_id;
		}
	}
	public function add_invoice($invoice_details)
	{
		$invoice_details = $this->security->xss_clean($invoice_details);
		$this->db->trans_begin();
		$customer_id = $invoice_details['customer_id'];
		if($invoice_details['customer_id'] == '')
		{
			$customer_array = array('customer_name'=>$invoice_details['customer_name'],'customer_address'=>$invoice_details['customer_address'],'customer_contact_no'=>$invoice_details['customer_contact_no'],'customer_contact_person'=>$invoice_details['customer_contact_person'],'customer_email_id'=>$invoice_details['customer_email_id'],'customer_outstand'=>$invoice_details['customer_outstand'],'customer_gst_no'=>$invoice_details['customer_gst_no']);
			$customer_id = $this->get_id('customer_mstr','customer_id');
			$customer_array['customer_id'] = $customer_id;
			$customer_array['customer_added_date'] = date('Y-m-d H:i:s');
			$add_customer_mstr = $this->db->insert('customer_mstr',$customer_array);
			$tr_id = $this->get_id('customer_transactions','c_transaction_id');
			$add_customer_tran = $this->db->insert('customer_transactions',['c_transaction_id'=>$tr_id,'customer_id'=>$customer_id,'c_transaction_date'=>date('Y-m-d H:i'),'c_transaction_discription'=>'Initial balance(Prev.)','c_transaction_amount'=>$customer_array['customer_outstand']]);
		}
		$bill_id = $this->get_id('bill_mstr','bill_id');
		if($invoice_details['invoice_number'] == ''){
			$bill_no = date('YmdHism');
		} else {
			$bill_no = $invoice_details['invoice_number'];
		}
		$insert_bill = $this->db->insert('bill_mstr',['bill_id'=>$bill_id,'bill_no'=>$bill_no,'bill_date'=>date('Y-m-d H:i:s'),'customer_id'=>$customer_id,'tax_bill'=>'0','total_amount'=>$invoice_details['total_amount'],'discount_amount'=>$invoice_details['discount_amount'],'final_amount'=>$invoice_details['final_amount'],'paid_amount'=>$invoice_details['paid_amount'],'remained_amount'=>$invoice_details['remained_amount']]);
		
		//Insert products in billed product_added_date
		for($i=0;$i<count($invoice_details['product_id']);$i++)
		{
			$tr_id = $this->get_id('billed_product_mstr','tr_id');
			$product_id = $invoice_details['product_id'][$i];
			$product_quantity = $invoice_details['product_quantity'][$i];
			$product_rate = $invoice_details['product_rate'][$i];
			$applied_taxes = $invoice_details['product_taxes'][$i];
			$insert_billed_products = $this->db->insert('billed_product_mstr',['tr_id'=>$tr_id,'bill_id'=>$bill_id,'product_id'=>$product_id,'product_quantity'=>$product_quantity,'product_rate'=>$product_rate,'applied_taxes'=>$applied_taxes]);
			//Update product stock
			$update_stock = $this->db->where(['product_id'=>$product_id])->set('product_stock', 'product_stock-'.$product_quantity, FALSE)->update('product_mstr');
		}
		//Update customrer outstanding
		$update_customer_outstand = $this->db->where(['customer_id'=>$customer_id])->set('customer_outstand', 'customer_outstand + '.$invoice_details['remained_amount'], FALSE)->update('customer_mstr');
		$tr_id = $this->get_id('customer_transactions','c_transaction_id');
		$add_customer_tran2 = $this->db->insert('customer_transactions',['c_transaction_id'=>$tr_id,'customer_id'=>$customer_id,'c_transaction_date'=>date('Y-m-d H:i'),'c_transaction_discription'=>'Purchased of bill no'.$bill_no,'c_transaction_amount'=>$invoice_details['remained_amount']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return $bill_id;
		}
	}
	public function get_searched_invoices_num($search_array)
	{
		$invoice_details = $this->db->select('count(bill_id) as total_count')->from('bill_mstr');
		if($search_array['customer_id'])
		{
			$this->db->group_start();
			$this->db->like(['bill_mstr.customer_id'=>$search_array['customer_id']]);
			$this->db->group_end();
		}
		if($search_array['customer_contact_no'])
		{
			$this->db->group_start();
			$this->db->like(['customer_contact_no'=>$search_array['customer_contact_no']]);
			$this->db->group_end();
		}
		if($search_array['from_date'])
		{
			$this->db->group_start();
			$this->db->where(['bill_date >='=>$search_array['from_date'].' 00:00:00']);
			$this->db->group_end();
		}
		if($search_array['to_date'])
		{
			$this->db->group_start();
			$this->db->where(['bill_date <='=>$search_array['to_date'].' 00:00:00']);
			$this->db->group_end();
		}
		if($search_array['bill_no'])
		{
			$this->db->group_start();
			$this->db->like(['bill_no'=>$search_array['bill_no']]);
			$this->db->group_end();
		}
		
		$invoice_details = $this->db->join('customer_mstr','bill_mstr.customer_id=customer_mstr.customer_id','left outer')->get();
		return $invoice_details->row();
	}
	public function get_searched_invoices($search_array,$limit,$offset)
	{
		$invoice_details = $this->db->select('*')->from('bill_mstr');
		if($search_array['customer_id'])
		{
			$this->db->group_start();
			$this->db->like(['bill_mstr.customer_id'=>$search_array['customer_id']]);
			$this->db->group_end();
		}
		if($search_array['customer_contact_no'])
		{
			$this->db->group_start();
			$this->db->like(['customer_contact_no'=>$search_array['customer_contact_no']]);
			$this->db->group_end();
		}
		if($search_array['from_date'])
		{
			$this->db->group_start();
			$this->db->where(['bill_date >='=>$search_array['from_date'].' 00:00:00']);
			$this->db->group_end();
		}
		if($search_array['to_date'])
		{
			$this->db->group_start();
			$this->db->where(['bill_date <='=>$search_array['to_date'].' 00:00:00']);
			$this->db->group_end();
		}
		if($search_array['bill_no'])
		{
			$this->db->group_start();
			$this->db->like(['bill_no'=>$search_array['bill_no']]);
			$this->db->group_end();
		}
		
		$invoice_details = $this->db->join('customer_mstr','bill_mstr.customer_id=customer_mstr.customer_id','left outer')->order_by('bill_date','desc')->limit($limit,$offset)->get();
		return $invoice_details->result();
	}
	public function get_invoice($invoice_id)
	{
		$invoice_details = $this->db->select('*')->from('bill_mstr')->where(['bill_id'=>$invoice_id])->join('customer_mstr','bill_mstr.customer_id=customer_mstr.customer_id','left outer')->get();
		return $invoice_details->row();
	}
	public function get_billed_products($invoice_id)
	{
		$product_details = $this->db->select('billed_product_mstr.*,product_mstr.*,GROUP_CONCAT(tax_mstr.tax_name) as taxes,GROUP_CONCAT(tax_mstr.tax_amount) as amounts,SUM(tax_mstr.tax_amount) as total_taxes')->from('billed_product_mstr')->where(['bill_id'=>$invoice_id])->join('product_mstr','billed_product_mstr.product_id=product_mstr.product_id','left outer')->join('tax_mstr','FIND_IN_SET(tax_mstr.tax_id, billed_product_mstr.applied_taxes) > 0','left outer')->group_by('billed_product_mstr.tr_id')->get();
		return $product_details->result();
	}
	public function make_inward_transaction($transaction_details)
	{
		$transaction_details = $this->security->xss_clean($transaction_details);
		$this->db->trans_begin();
		$customer_id = $transaction_details['customer_id'];
		$update_customer_outstand = $this->db->where(['customer_id'=>$customer_id])->set('customer_outstand', 'customer_outstand -'.$transaction_details['paid_amount'], FALSE)->update('customer_mstr');
		$tr_id = $this->get_id('customer_transactions','c_transaction_id');
		$add_customer_tran2 = $this->db->insert('customer_transactions',['c_transaction_id'=>$tr_id,'customer_id'=>$customer_id,'c_transaction_date'=>date('Y-m-d H:i'),'c_transaction_discription'=>'Paid. '.$transaction_details['paid_note'],'c_transaction_amount'=>$transaction_details['paid_amount']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return $bill_id;
		}
	}
	public function make_outward_transaction($transaction_details)
	{
		$transaction_details = $this->security->xss_clean($transaction_details);
		$this->db->trans_begin();
		$vendor_id = $transaction_details['vendor_id'];
		$update_vendor_outstand = $this->db->where(['vendor_id'=>$vendor_id])->set('vendor_outstand', 'vendor_outstand -'.$transaction_details['paid_amount'], FALSE)->update('vendor_mstr');
		$tr_id = $this->get_id('vendor_transactions','v_transaction_id');
		$add_customer_tran2 = $this->db->insert('vendor_transactions',['v_transaction_id'=>$tr_id,'vendor_id'=>$vendor_id,'v_transaction_date'=>date('Y-m-d H:i'),'v_transaction_discription'=>'Paid. '.$transaction_details['paid_note'],'v_transaction_amount'=>$transaction_details['paid_amount']]);
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return $bill_id;
		}
	}
	
	public function get_customer_transactions_num($search_array)
	{
		$customer_transactions = $this->db->select('count(c_transaction_id) as total_count')->from('customer_transactions')->where(['customer_id'=>$search_array['customer_id']]);
		if($search_array['from_date'])
		{
			$this->db->group_start();
			$this->db->where(['c_transaction_date >='=>$search_array['from_date'].' 00:00']);
			$this->db->group_end();
		}
		if($search_array['to_date'])
		{
			$this->db->group_start();
			$this->db->where(['c_transaction_date <='=>$search_array['to_date'].' 00:00']);
			$this->db->group_end();
		}
		$customer_transactions = $this->db->get();
		return $customer_transactions->row();
	}
	
	public function get_customer_transactions($search_array,$limit,$offset)
	{
		$customer_transactions = $this->db->select('*')->from('customer_transactions')->where(['customer_id'=>$search_array['customer_id']]);
		if($search_array['from_date'])
		{
			$this->db->group_start();
			$this->db->where(['c_transaction_date >='=>$search_array['from_date'].' 00:00']);
			$this->db->group_end();
		}
		if($search_array['to_date'])
		{
			$this->db->group_start();
			$this->db->where(['c_transaction_date <='=>$search_array['to_date'].' 00:00']);
			$this->db->group_end();
		}
		$customer_transactions = $this->db->order_by('c_transaction_date','desc')->limit($limit,$offset)->get();
		return $customer_transactions->result();
	}
	
	public function get_vendor_transactions_num($search_array)
	{
		$vendor_transactions = $this->db->select('count(v_transaction_id) as total_count')->from('vendor_transactions')->where(['vendor_id'=>$search_array['vendor_id']]);
		if($search_array['from_date'])
		{
			$this->db->group_start();
			$this->db->where(['v_transaction_date >='=>$search_array['from_date'].' 00:00']);
			$this->db->group_end();
		}
		if($search_array['to_date'])
		{
			$this->db->group_start();
			$this->db->where(['v_transaction_date <='=>$search_array['to_date'].' 00:00']);
			$this->db->group_end();
		}
		$vendor_transactions = $this->db->get();
		return $vendor_transactions->row();
	}
	
	public function get_vendor_transactions($search_array,$limit,$offset)
	{
		$vendor_transactions = $this->db->select('*')->from('vendor_transactions')->where(['vendor_id'=>$search_array['vendor_id']]);
		if($search_array['from_date'])
		{
			$this->db->group_start();
			$this->db->where(['v_transaction_date >='=>$search_array['from_date'].' 00:00']);
			$this->db->group_end();
		}
		if($search_array['to_date'])
		{
			$this->db->group_start();
			$this->db->where(['v_transaction_date <='=>$search_array['to_date'].' 00:00']);
			$this->db->group_end();
		}
		$vendor_transactions = $this->db->order_by('v_transaction_date','asc')->limit($limit,$offset)->get();
		return $vendor_transactions->result();
	}
	
	
}

?>
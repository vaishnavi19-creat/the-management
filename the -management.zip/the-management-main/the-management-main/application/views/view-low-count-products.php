<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Minimum Stock Products</strong></span>
					</div>
					<div class="col-md-6">
						<?php if(isset($all_products)){ ?>
							<button class="btn btn-success" data-toggle="modal" data-target="#exportModal"><span class="fa fa-print"></span> Export</button>
						<?php } ?>
					</div>
				</div>
            </div>
			
			<div class="col-md-12 white-div">
			<?php
			if(isset($all_products))
			{
				?>
				<div class="row">
					 <div class="col-md-12">
					 <?php if($all_products && count($all_products)>0){ ?>
						<div class="table-responsive">
							<table class="table table-bordered list-table">
								<thead><tr><td>Index</td><td>Product Id</td><td>Product Name</td><td>HSN Code</td><td>Stock</td><td>Min Stock</td><td>Mrp</td><td>ASP</td><td>Taxes</td><td>Discription</td><td>Vendor</td><td>Action</td></tr></thead>
								<tbody>
									<?php
									$i=1;
										foreach($all_products as $product)
										{
											if($product->product_status==1)
											{
											?>
											<tr><td><?php echo $i;?></td><td><?php echo $product->product_id;?></td><td><?php echo $product->product_name;?></td><td><?php echo $product->product_hsn_code;?></td><td><?php echo $product->product_stock;?></td><td><?php echo $product->product_min_stock;?></td><td><?php echo $product->product_mrp;?></td><td><?php echo $product->product_asp;?></td><td><?php echo $product->taxes;?></td><td><?php echo $product->product_discription;?></td><td><?php echo $product->vendor_name;?></td><td><?php echo anchor('admin/editProduct/'.$product->product_id,'<button class="btn btn-success">Edit</button>');?><?php echo anchor('admin/deleteProduct/'.$product->product_id,'<button class="btn btn-danger">Delete</button>');?></td></tr>
											<?php
											$i++;
											}
										}										
									?>
								</tbody>
							</table>
						</div> 
						<?php } else{
							?>
							<div class="alert alert-warning">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<i class="material-icons">close</i>
								</button>
								<span>
								<b> Warning - </b> You haven't added any Product details. Kindly click on "Add New Product" button. </span>
							</div>
							<?php
						}?>						
                     </div>
				</div>
				<div class="row">
					 <div class="col-md-12">
					 <?php echo $this->pagination->create_links();?>
					 </div>
				</div>
			<?php } ?>
				
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			
<!--Action modal-->	
 <div class="modal fade" id="exportModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
		  <!--Action buttons-->
		  <button type="button" id="export_to_excel" class="btn btn-primary">Get data in Excel</button>
		  <button type="button" id="export_to_print" class="btn btn-primary">Print</button>
        </div>
        <div class="modal-body">
          <div id="action_div">
		  
		  		<?php if(isset($all_products)){ ?>
				<div class="row printable_div" style="margin-top:3%">
					 <div class="col-md-12 col-xs-12">
                        <div class="table-responsive">
							<table class="table table-bordered">
								<thead>
									<tr><td colspan="12"><center>Products list less than minimum stock</center></td></tr>
								</thead>
								
								<tbody>
								<tr><td colspan="12"><center>Report Date : <?php echo date('Y-m-d');?></center></td></tr>
								<tr><td>Index</td><td>Product Id</td><td>Product Name</td><td>HSN Code</td><td>Stock</td><td>Min Stock</td><td>Mrp</td><td>ASP</td><td>Taxes</td><td>Discription</td><td>Vendor</td></tr>
									<?php
									$i=1;
										foreach($all_products as $product)
										{
											if($product->product_status==1)
											{
											?>
											<tr><td><?php echo $i;?></td><td><?php echo $product->product_id;?></td><td><?php echo $product->product_name;?></td><td><?php echo $product->product_hsn_code;?></td><td><?php echo $product->product_stock;?></td><td><?php echo $product->product_min_stock;?></td><td><?php echo $product->product_mrp;?></td><td><?php echo $product->product_asp;?></td><td><?php echo $product->taxes;?></td><td><?php echo $product->product_discription;?></td><td><?php echo $product->vendor_name;?></td></tr>
											<?php
											$i++;
											}
										}										
									?>
								</tbody>
							</table>
						</div> 
                     </div>
				</div>
				<div class="row">
					 <div class="col-md-12">
					 <?php echo $this->pagination->create_links();?>
					 </div>
				</div>
				<?php } ?>
		  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!--EndAction modal-->			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Shop Details</strong></span>
					</div>
					<div class="col-md-6">
						<span class="pull-right">
							<?php echo anchor('admin/updateShopDetails','<button class="btn btn-success"><span class="fa fa-eye"></span> Update Shop Details</button>');?>
						</span>
					</div>
				</div>
            </div>
			
			<form method="post" action="#" name="login-form">
			<div class="col-md-12 white-div">
			<?php if($shop_details) { ?>
				<div class="row">
					 <div class="col-md-12">
                        <center><img src="<?php echo base_url();?>thems/assets/img/<?php echo $shop_details->shop_logo;?>" id="shop_logo" class="img" style="width:200px;"></img></center>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Shop Name : </label>
							<span class="form-control"><?php echo $shop_details->shop_name;?></span>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address : </label>
							<span class="form-control"><?php echo $shop_details->shop_address;?></span>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact No : </label>
							<span class="form-control"><?php echo $shop_details->shop_contact_no;?></span>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<span class="form-control"><?php echo $shop_details->shop_contact_person;?></span>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">GST No : </label>
							<span class="form-control"><?php echo $shop_details->shop_gst_no;?></span>
						</div>
                     </div>
					 
				</div>
				<?php } else { ?>
				<div class="row">
				<div class="col-md-12">
					<div class="alert alert-warning">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <i class="material-icons">close</i>
						</button>
						<span>
						  <b> Warning - </b> You haven't updated any shop details. Kindly click on "Update Shop details" button </span>
					  </div>
				</div>
				</div>
				<?php } ?>
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			</form>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
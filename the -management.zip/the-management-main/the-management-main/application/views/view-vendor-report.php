<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Vendor Report</strong></span>
					</div>
					<div class="col-md-6 pull-right">
					<?php if(isset($all_transactions)){ ?>
							<button class="btn btn-success" data-toggle="modal" data-target="#exportModal"><span class="fa fa-print"></span> Export</button>
					<?php } ?>
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/vendorReport');?>
			<div class="col-md-12 white-div">
				
				<?php if(isset($all_transactions)){ ?>
				<div class="row" style="margin-top:3%">
					 <div class="col-md-12">
                        <div class="table-responsive">
                          <table class="table table-bordered">
						  <thead><tr><td colspan="6"><center><strong><?php echo $vendor_details->vendor_name;?></strong><br><?php echo $vendor_details->vendor_address;?><br><?php echo $vendor_details->vendor_contact_no;?></center></td></tr></thead>
						  <tbody>
						  
						  <tr><td colspan="2">From Date : <?php if($this->session->userdata('searched_vreport_from_date')){ echo date("d-M-Y", strtotime($this->session->userdata('searched_vreport_from_date'))); } ?></td><td colspan="2">To Date : <?php if($this->session->userdata('searched_vreport_to_date')){ echo date("d-M-Y", strtotime($this->session->userdata('searched_vreport_to_date'))); } ?></td></tr>
						  <tr><td>Index</td><td>Transaction Date</td><td>Bill Amount</td><td>Paid Amount</td><td>Discription</td><td>Note</td></tr>
						  
						  <?php
						  $i = 1;
							if(count($all_transactions) > 0)
							{
								foreach($all_transactions as $tr)
								{
									?>
									<tr><td><?php echo $i;?></td>
									<td><?php echo date("d-M-Y", strtotime($tr->v_transaction_date) );?></td>
									<td><?php if($tr->v_transaction_discription === 'Initial balance(Prev.)') { echo '-'; } else { echo round($tr->v_transaction_total_amount,2); }?></td>
									<td><?php if($tr->v_transaction_discription === 'Initial balance(Prev.)') { echo '-'; } else { echo round($tr->v_transaction_amount,2); }?></td>
									<td><?php echo $tr->v_transaction_discription; 
										if($tr->v_transaction_discription === 'Initial balance(Prev.)') { echo ' ' . round($tr->v_transaction_amount,2); }
									?></td>
									<td><?php echo $tr->v_transaction_note;?></td></tr>
									<?php
									$i++;
								}
							}
							else
							{
								echo '<tr><td colspan="4">Transactions Are Not Available</td></tr>';
							}
						  ?>
						  <tr><td colspan="3"><span class="pull-right text text-danger">Total Outstand</span></td><td><span class="text text-danger">( &#8377 ) <?php echo round($vendor_details->vendor_outstand,2);?></span></td><td colspan="3"></td></tr>
						  </tbody>
						  </table>
						</div>
                     </div>
				</div>
				<div class="row">
					 <div class="col-md-12">
					 <?php echo $this->pagination->create_links();?>
					 </div>
				</div>
				<?php } ?>
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>

<!--Action modal-->	
 <div class="modal fade" id="exportModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
		  <!--Action buttons-->
		  <button type="button" id="export_to_excel" class="btn btn-primary">Get data in Excel</button>
		  <button type="button" id="export_to_print" class="btn btn-primary">Print</button>
        </div>
        <div class="modal-body">
          <div id="action_div">
		  
		  		<?php if(isset($all_transactions)){ ?>
				<div class="row printable_div" style="margin-top:3%">
					 <div class="col-md-12 col-xs-12">
                        <div class="table-responsive">
						  <table class="table table-bordered list-table">
						  <thead><tr><td colspan="6"><center><strong><?php echo $vendor_details->vendor_name;?></strong><br><?php echo $vendor_details->vendor_address;?><br><?php echo $vendor_details->vendor_contact_no;?></center></td></tr></thead>
						  <tbody>
						  
						  <tr><td colspan="2">From Date : <?php if($this->session->userdata('searched_vreport_from_date')){ echo date("d-M-Y", strtotime($this->session->userdata('searched_vreport_from_date'))); } ?></td><td colspan="2">To Date : <?php if($this->session->userdata('searched_vreport_to_date')){ echo date("d-M-Y", strtotime($this->session->userdata('searched_vreport_to_date'))); } ?></td></tr>
						  <tr><td>Index</td><td>Transaction Date</td><td>Bill Amount</td><td>Paid Amount</td><td>Discription</td><td>Note</td></tr>
						  
						  <?php
						  $i = 1;
							if(count($all_transactions) > 0)
							{
								foreach($all_transactions as $tr)
								{
									?>
									<tr><td><?php echo $i;?></td>
									<td><?php echo date("d-M-Y", strtotime($tr->v_transaction_date) );?></td>
									<td><?php if($tr->v_transaction_discription === 'Initial balance(Prev.)') { echo '-'; } else { echo round($tr->v_transaction_total_amount,2); }?></td>
									<td><?php if($tr->v_transaction_discription === 'Initial balance(Prev.)') { echo '-'; } else { echo round($tr->v_transaction_amount,2); }?></td>
									<td><?php echo $tr->v_transaction_discription; 
										if($tr->v_transaction_discription === 'Initial balance(Prev.)') { echo ' ' . round($tr->v_transaction_amount,2); }
									?></td>
									<td><?php echo $tr->v_transaction_note;?></td></tr>
									<?php
									$i++;
								}
							}
							else
							{
								echo '<tr><td colspan="4">Transactions Are Not Available</td></tr>';
							}
						  ?>
						  <tr><td colspan="3"><span class="pull-right text text-danger">Total Outstand</span></td><td><span class="text text-danger">( &#8377 ) <?php echo round($vendor_details->vendor_outstand,2);?></span></td><td colspan="3"></td></tr>
						  </tbody>
						  </table>
						</div>
                     </div>
				</div>
				<div class="row">
					 <div class="col-md-12">
					 <?php echo $this->pagination->create_links();?>
					 </div>
				</div>
				<?php } ?>
		  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!--EndAction modal-->	
		   <!-- Main designing ends here -->
<?php include('footer.php');?>

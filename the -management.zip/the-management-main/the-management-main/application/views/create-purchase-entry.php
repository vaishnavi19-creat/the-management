<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Purchase Entry</strong></span>
					</div>
					<div class="col-md-6">
							<?php echo anchor('admin/createPurchaseEntry','<button class="btn btn-success"><span class="fa fa-plus"></span> Add new</button>',['class'=>'pull-right']);?>
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/createPurchaseEntry');?>
			<div class="col-md-12 white-div">
				<div class="row dark-background">
					<div class="col-md-3">
                        <div class="form-group">
							<?php 
									$all_vendors1 = $all_vendors;
									$vendors ="";
									$vendors = array('' => 'Select vendor',);
									foreach($all_vendors1 as $vndr)
									{
										if($vndr->vendor_status==1)
										{
											$vendor_id=$vndr->vendor_id;
											$vendor_name=$vndr->vendor_name;
											$vendors[$vendor_id]=$vendor_name;
										}
									}
									echo form_dropdown('vendor_id', $vendors,  set_value('vendor_id'), ['class'=>'form-control','id'=>'vendor_id']);
							?>
							<?php echo form_error('vendor_id');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">vendor Name : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'vendor_name','class'=>'form-control vendor-details','id'=>'vendor_name','required'=>'required','value'=>set_value('vendor_name')]);?>
							<?php echo form_error('vendor_name');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'vendor_address','class'=>'form-control vendor-details','required'=>'required','id'=>'vendor_address','value'=>set_value('vendor_address')]);?>
							<?php echo form_error('vendor_address');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact No : </label>
							<?php echo form_input(['name'=>'vendor_contact_no','class'=>'form-control vendor-details', 'id'=>'vendor_contact_no','value'=>set_value('vendor_contact_no')]);?>
							<?php echo form_error('vendor_contact_no');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<?php echo form_input(['name'=>'vendor_contact_person','class'=>'form-control vendor-details', 'id'=>'vendor_contact_person','value'=>set_value('vendor_contact_person')]);?>
							<?php echo form_error('vendor_contact_person');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Id : </label>
							<?php echo form_input(['name'=>'vendor_email_id','class'=>'form-control vendor-details', 'id'=>'vendor_email_id','value'=>set_value('vendor_email_id')]);?>
							<?php echo form_error('vendor_email_id');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Outstanding : </label>
							<?php echo form_input(['name'=>'vendor_outstand','class'=>'form-control vendor-details', 'id'=>'vendor_outstand','value'=>set_value('vendor_outstand')]);?>
							<?php echo form_error('vendor_outstand');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">GST No : </label>
							<?php echo form_input(['name'=>'vendor_gst_no','class'=>'form-control vendor-details', 'id'=>'vendor_gst_no','value'=>set_value('vendor_gst_no')]);?>
							<?php echo form_error('vendor_gst_no');?>
						</div>
                     </div>
					
				</div>
				<div class="row" style="margin-top:3%">
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Total Amount : </label>
							<?php echo form_input(['name'=>'total_amount','class'=>'form-control product-detailss', 'id'=>'total_amount','value'=>set_value('total_amount')]);?>
							<?php echo form_error('total_amount');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Paid : </label>
							<?php echo form_input(['name'=>'paid_amount','class'=>'form-control product-detailss', 'id'=>'paid_amount','value'=>set_value('paid_amount')]);?>
							<?php echo form_error('paid_amount');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Invoice No : </label>
							<?php echo form_input(['name'=>'invoice_no','class'=>'form-control product-detailss', 'id'=>'invoice_no','value'=>set_value('invoice_no')]);?>
							<?php echo form_error('invoice_no');?>
						</div>
                     </div>
				</div>	
				
				
				<div class="row" style="margin-top:3%">
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Date : </label>
							<?php echo form_input(['name'=>'transaction_date', 'type' => 'date', 'class'=>'form-control product-detailss', 'id'=>'transaction_date','value'=>set_value('transaction_date')]);?>
							<?php echo form_error('transaction_date');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Note : </label>
							<?php echo form_input(['name'=>'note', 'class'=>'form-control product-detailss', 'id'=>'note','value'=>set_value('note')]);?>
							<?php echo form_error('note');?>
						</div>
                     </div>
					  <div class="col-md-3">
                        <div class="form-group">
                         <button type="submit" id="add-product-btnn" class="btn btn-info" ><span class="fa fa-plus"></span>Submit</button>
						 </div>
                     </div>
				</div>	
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
<script>
var csrfName = '<?php echo $this->security->get_csrf_token_name();?>',
csrfHash = '<?php echo $this->security->get_csrf_hash();?>';
$('#vendor_id').change(function(){
	
	var vendor_id = $(this).val();
	if(vendor_id != '')
	{
		$('#vendor_name').val('');
		$('#vendor_address').val('');
		$('#vendor_contact_no').val('');
		$('#vendor_contact_person').val('');
		$('#vendor_email_id').val('');
		$('#vendor_outstanding').val('');
		$('#vendor_gst_no').val('');
		 $('.vendor-details').attr('readonly', false);
		//Ajax request
		 $.ajax({
									       url      :  "<?php echo base_url()?>api/getvendor/"+vendor_id,
									      type      :  "POST",
									      data      :  {'csrf_test_name':csrfHash},
										 dataType   : 'json',
									      success   :  function(response){
											$('#vendor_name').val(response.vendor_name);
											$('#vendor_address').val(response.vendor_address);
											$('#vendor_contact_no').val(response.vendor_contact_no);
											$('#vendor_contact_person').val(response.vendor_contact_person);
											$('#vendor_email_id').val(response.vendor_email_id);
											$('#vendor_outstand').val(response.vendor_outstand);
											$('#vendor_gst_no').val(response.vendor_gst_no);
											$('#vendor_name').focus();
											 $('.vendor-details').attr('readonly', true);
									  },
									  error : function(){
										  alert('An Error has occured.Try after refreshing the page.');
										     $('#vendor_name').val('');
											$('#vendor_address').val('');
											$('#vendor_contact_no').val('');
											$('#vendor_contact_person').val('');
											$('#vendor_email_id').val('');
											$('#vendor_outstanding').val('');
											$('#vendor_gst_no').val('');
											$('.vendor-details').attr('readonly', false);
									  }
								  });
		//End AJAX request
	}
	else
	{
		$('#vendor_name').val('');
		$('#vendor_address').val('');
		$('#vendor_contact_no').val('');
		$('#vendor_contact_person').val('');
		$('#vendor_email_id').val('');
		$('#vendor_outstanding').val('');
		$('#vendor_gst_no').val('');
		$('.vendor-details').attr('readonly', false);
	}
});
</script>
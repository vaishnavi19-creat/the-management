-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2020 at 02:36 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `billing`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_mstr`
--

CREATE TABLE `admin_mstr` (
  `admin_id` varchar(50) NOT NULL,
  `admin_full_name` varchar(150) NOT NULL,
  `admin_added_date` varchar(50) NOT NULL,
  `admin_status` int(11) NOT NULL DEFAULT '1',
  `admin_username` varchar(10) NOT NULL,
  `admin_password` text NOT NULL,
  `admin_contact_number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_mstr`
--

INSERT INTO `admin_mstr` (`admin_id`, `admin_full_name`, `admin_added_date`, `admin_status`, `admin_username`, `admin_password`, `admin_contact_number`) VALUES
('151277', 'Shripad Bhadole', '2018-12-23', 1, 'bhadole', 'bhadole', '7028050808');

-- --------------------------------------------------------

--
-- Table structure for table `billed_product_mstr`
--

CREATE TABLE `billed_product_mstr` (
  `tr_id` varchar(50) NOT NULL,
  `bill_id` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `product_quantity` double NOT NULL,
  `product_rate` double NOT NULL,
  `applied_taxes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billed_product_mstr`
--

INSERT INTO `billed_product_mstr` (`tr_id`, `bill_id`, `product_id`, `product_quantity`, `product_rate`, `applied_taxes`) VALUES
('4dMhlSaeZLqJ5NC9YDQT8mrPF3obI', 'p7RJYGi45Dq20uAzk9IKa', 'wDyC54qHP7aVz96W', 4, 330, ''),
('Ndiu7CFlsQq8Thbj', 'p7RJYGi45Dq20uAzk9IKa', '3Yc4dxWIiCK2v7BSk9AGOyEUe', 6, 2900, ''),
('sUTARdb9fjM2W10PF54xQiL', 'uF2eZ0TVzlI7Ok6g3', '3U8lctR421TrW9ms6fVkgMnBEa', 10, 20, '');

-- --------------------------------------------------------

--
-- Table structure for table `bill_mstr`
--

CREATE TABLE `bill_mstr` (
  `bill_id` varchar(50) NOT NULL,
  `bill_no` varchar(50) NOT NULL,
  `bill_date` varchar(50) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `tax_bill` int(11) NOT NULL DEFAULT '0',
  `total_amount` double NOT NULL,
  `discount_amount` double NOT NULL,
  `final_amount` double NOT NULL,
  `paid_amount` double NOT NULL,
  `remained_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill_mstr`
--

INSERT INTO `bill_mstr` (`bill_id`, `bill_no`, `bill_date`, `customer_id`, `tax_bill`, `total_amount`, `discount_amount`, `final_amount`, `paid_amount`, `remained_amount`) VALUES
('p7RJYGi45Dq20uAzk9IKa', '2020022614100502', '2020-02-26 14:10:05', 'ZCMjQcuemhSTA0qdX7BHzp6P', 0, 18720, 0, 18720, 18720, 0),
('uF2eZ0TVzlI7Ok6g3', '2020102418041410', '2020-10-24 18:04:14', 'ZCMjQcuemhSTA0qdX7BHzp6P', 0, 200, 5, 190, 190, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_mstr`
--

CREATE TABLE `customer_mstr` (
  `customer_id` varchar(50) NOT NULL,
  `customer_name` text NOT NULL,
  `customer_address` text NOT NULL,
  `customer_contact_person` varchar(50) NOT NULL,
  `customer_contact_no` varchar(50) NOT NULL,
  `customer_email_id` varchar(50) NOT NULL,
  `customer_gst_no` varchar(50) NOT NULL,
  `customer_outstand` double NOT NULL,
  `customer_status` int(11) NOT NULL DEFAULT '1',
  `customer_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_mstr`
--

INSERT INTO `customer_mstr` (`customer_id`, `customer_name`, `customer_address`, `customer_contact_person`, `customer_contact_no`, `customer_email_id`, `customer_gst_no`, `customer_outstand`, `customer_status`, `customer_added_date`) VALUES
('ZCMjQcuemhSTA0qdX7BHzp6P', 'Bapu Lokande', 'Yawali', '', '9922286088', '', '', 0, 1, '2020-02-26 14:10:05');

-- --------------------------------------------------------

--
-- Table structure for table `customer_transactions`
--

CREATE TABLE `customer_transactions` (
  `c_transaction_id` varchar(50) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `c_transaction_date` varchar(50) NOT NULL,
  `c_transaction_discription` text NOT NULL,
  `c_transaction_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_transactions`
--

INSERT INTO `customer_transactions` (`c_transaction_id`, `customer_id`, `c_transaction_date`, `c_transaction_discription`, `c_transaction_amount`) VALUES
('ijkQs4BdxZ0mTy5gCVMLrGzb', 'ZCMjQcuemhSTA0qdX7BHzp6P', '2020-10-24 18:04', 'Purchased of bill no2020102418041410', 0),
('MIdpKZteqofxRVJwrQG8b01O5SWvma', 'ZCMjQcuemhSTA0qdX7BHzp6P', '2020-02-26 14:10', 'Purchased of bill no2020022614100502', 0),
('o08gVH17BevdFxOhwyjQULt', 'ZCMjQcuemhSTA0qdX7BHzp6P', '2020-02-26 14:10', 'Initial balance(Prev.)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_mstr`
--

CREATE TABLE `product_mstr` (
  `product_id` varchar(50) NOT NULL,
  `product_name` text NOT NULL,
  `product_stock` double NOT NULL,
  `product_unit` varchar(10) NOT NULL,
  `product_min_stock` double NOT NULL,
  `product_hsn_code` varchar(50) NOT NULL,
  `product_mrp` double NOT NULL,
  `product_asp` double NOT NULL,
  `product_discription` text NOT NULL,
  `product_taxes` text NOT NULL,
  `product_vendor_code` varchar(50) NOT NULL,
  `product_status` int(11) NOT NULL DEFAULT '1',
  `product_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_mstr`
--

INSERT INTO `product_mstr` (`product_id`, `product_name`, `product_stock`, `product_unit`, `product_min_stock`, `product_hsn_code`, `product_mrp`, `product_asp`, `product_discription`, `product_taxes`, `product_vendor_code`, `product_status`, `product_added_date`) VALUES
('2EHXwyZN0SR3r8aPoxdUJmpYcGQqB', 'SP L type Hock MS Kothair', 14, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 16:56:59'),
('3U8lctR421TrW9ms6fVkgMnBEa', 'SP L type Service Sad Kothair', -5, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 17:01:25'),
('3wudxmaTpUqneKWSj2ErgyQDHI', 'SP L type Elbow Kothair', 2, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-24 16:56:14'),
('3Yc4dxWIiCK2v7BSk9AGOyEUe', '20mm Inline 250mtr Kothari', 0, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-25 14:15:08'),
('47X3ZQwladY0ChtT', 'SP 75mm Spikler set Kothari LType', 0, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-25 13:57:46'),
('6LsXozhevqYKSZkb58Qp', 'SP K type pump bottam', 5, 'PC', 2, '', 0, 0, '', '', '', 0, '2020-02-24 16:35:27'),
('7EbLB3NhYJ5kprsRlUezdfVxQ0nI', 'SP L type Tee Kothair', 3, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 17:03:24'),
('7XlBexkIdPSTm8p', '16 mm Joiner Drip Kothari', 550, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-25 14:08:04'),
('9Fz4NMagHP06GWYDiOlToCVIbX7Rqj', '16mm on line 400 mtr plan Kothair', 7, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 16:58:23'),
('9nNlZVdS6cCh2xwm', 'SP K type  Services sad Kothair', 3, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-24 17:02:24'),
('c9L4nBCusqaMQjrt27eE', 'SP K type Elbow Kothair', 2, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-24 16:52:33'),
('ClXIbsQr1pzfMPa9nFDh8NHRk62', '8 Litter Driper Kothair', 1450, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-24 16:51:29'),
('D49e2yBYXvFR6NOS1saCMTgtH', '63 mm Ball valve Kothari', 1, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-25 14:12:40'),
('D9uzT5jsoPAlmIpxhaRrW4MFQeY0CS', '16 mm Grommet Drip Kothari ', 1047, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-25 14:09:31'),
('diQDIL0mhjs6kU1vKPnC8tAMJ', 'Mini Spikler Set with ms rod Kothari', 2, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-25 14:13:41'),
('eqF8JmDpfns7uxlcHOWoStCK', '63 mm Fresh valave Kothari', 5, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-25 14:01:00'),
('fPy8vmH57WUtiLOSMhZc', '75 mm pvc Kothair', 0, 'PC', 5, '', 0, 0, '', '', '', 1, '2020-02-24 16:33:56'),
('gmkdAhc2W1fSTYaZ83N6RPjIB7l', '16 mm Tee Drip Kothari', 168, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-25 14:02:26'),
('HuwakFGbCm6h1TIQsf5', '16 mm Cock Drip Kothari', 470, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-25 14:03:03'),
('jn6PC9yMcHGzioD', '16mm on line 100 mtr plan Kothair', 0, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-24 16:58:52'),
('kfRNFhAsdLTcxZMrUY4gV6y2KCbpl', 'SP ruber Kothair', 45, 'PC', 5, '', 0, 0, '', '', '', 1, '2020-02-24 16:44:21'),
('KNoiAu1BSpvXHyTMm5lkY9z7d2tWQ', 'SP L type pump conector Kothair', 4, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 16:36:54'),
('KVBYU9X3r2RExfguhbeo41JMyaS8', '75 mm Fresh valave Kothari', 5, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-25 14:00:30'),
('lxg10TqZrUJKnYpwHQM4iE6bm', '75 mm Same Auto Filter Kothair', 0, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-24 16:43:21'),
('Mao920fzjvW7JyOs', 'SP K type Tee Kothair', 3, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 17:02:56'),
('P2RHEI3AJkCz6h51spvwn9M', '75 mm Filter PP Reuler Kothair', 1, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-24 16:42:51'),
('q2XlWegdp7hRc6zmoEQ5T', '75 mm Ball valve Kothari', 5, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-25 13:59:42'),
('Qb7sS8tf39lmgrRq1', '14 Litter Driper Kothair', 3400, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-24 16:45:36'),
('qwNicPpVxkyOeIoQBDfUsaG1t2S4', '16 mm End cap Drip Kothari ', 200, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-25 14:10:19'),
('r45BYTdfiAZoISqxWOy9wG30j8eMcn', '16 mm take off Drip ', 700, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-25 14:08:53'),
('RSlH3m1YgOocIkvw2WT0ZsCL', '20mm Online Drip 100mtr Kothair', 1, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-26 16:36:32'),
('Sp7Lz6d3b08P9FQiMBGNwjJxOqotZ', '8 mm Spry pipe Blue Kothair', 2, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-24 16:59:50'),
('TL51aYvt7CSxJI4RlVzkgmKG3nj', 'SP K type pump conector Kothair', 5, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 16:38:04'),
('UiT8VoJx7jdM9YWtkl6H', 'SP 75mm Spikler set Kothair K Type', 0, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-03-16 14:59:22'),
('v3VY9wE1GPFu5nyxg4LebzoN', '16 mm Lbow Drip Kothari', 500, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-25 14:01:53'),
('V4gdf5o9BpRJcMb3CeKOFAshzjQ', 'SP Rizzer Pipe Kothair', 10, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 16:43:53'),
('VlH04ur8XdDRnwY2jAbqkL', 'SP Nozzal Kothair', 11, 'PC', 2, '', 0, 0, '', '', '', 1, '2020-02-24 16:41:03'),
('wDyC54qHP7aVz96W', '63 mm pvc kothari', 10, 'PC', 5, '', 0, 0, '', '', '', 1, '2020-02-24 16:34:27'),
('x6NOet5CTWbwKFPXlAz4Mk0Z1En', '63 mm Filter MS Reguler Kothari', 1, 'PC', 1, '', 0, 0, '', '', '', 1, '2020-02-24 16:41:44'),
('Xm0ThpNuaMlGHYowVq', '16mm *20mm Take off Drip Kothari ', 400, 'PC', 100, '', 0, 0, '', '', '', 1, '2020-02-25 14:11:12');

-- --------------------------------------------------------

--
-- Table structure for table `shop_mstr`
--

CREATE TABLE `shop_mstr` (
  `shop_id` int(11) NOT NULL,
  `shop_name` text NOT NULL,
  `shop_address` text NOT NULL,
  `shop_contact_person` text NOT NULL,
  `shop_contact_no` varchar(70) NOT NULL,
  `shop_email_id` varchar(70) NOT NULL,
  `shop_gst_no` varchar(50) NOT NULL,
  `shop_logo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_mstr`
--

INSERT INTO `shop_mstr` (`shop_id`, `shop_name`, `shop_address`, `shop_contact_person`, `shop_contact_no`, `shop_email_id`, `shop_gst_no`, `shop_logo`) VALUES
(1, 'New Bhadole Machinery stoers', 'Vairag', 'Shripad bhadole.', '9604245997/7058692203', 'shop@gmail.com', '', 'Vairag.8.gif');

-- --------------------------------------------------------

--
-- Table structure for table `tax_mstr`
--

CREATE TABLE `tax_mstr` (
  `tax_id` varchar(50) NOT NULL,
  `tax_name` varchar(50) NOT NULL,
  `tax_amount` double NOT NULL,
  `tax_added_date` varchar(50) NOT NULL,
  `tax_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_mstr`
--

CREATE TABLE `vendor_mstr` (
  `vendor_id` varchar(50) NOT NULL,
  `vendor_name` text NOT NULL,
  `vendor_address` text NOT NULL,
  `vendor_contact_person` varchar(50) NOT NULL,
  `vendor_contact_no` varchar(50) NOT NULL,
  `vendor_email_id` varchar(50) NOT NULL,
  `vendor_gst_no` varchar(50) NOT NULL,
  `vendor_outstand` double NOT NULL,
  `vendor_status` int(11) NOT NULL DEFAULT '1',
  `vendor_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_transactions`
--

CREATE TABLE `vendor_transactions` (
  `v_transaction_id` varchar(50) NOT NULL,
  `vendor_id` varchar(50) NOT NULL,
  `v_transaction_date` varchar(50) NOT NULL,
  `v_transaction_discription` text NOT NULL,
  `v_transaction_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_mstr`
--
ALTER TABLE `admin_mstr`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `billed_product_mstr`
--
ALTER TABLE `billed_product_mstr`
  ADD PRIMARY KEY (`tr_id`);

--
-- Indexes for table `bill_mstr`
--
ALTER TABLE `bill_mstr`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `customer_mstr`
--
ALTER TABLE `customer_mstr`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_transactions`
--
ALTER TABLE `customer_transactions`
  ADD PRIMARY KEY (`c_transaction_id`);

--
-- Indexes for table `product_mstr`
--
ALTER TABLE `product_mstr`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `shop_mstr`
--
ALTER TABLE `shop_mstr`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `tax_mstr`
--
ALTER TABLE `tax_mstr`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `vendor_mstr`
--
ALTER TABLE `vendor_mstr`
  ADD PRIMARY KEY (`vendor_id`);

--
-- Indexes for table `vendor_transactions`
--
ALTER TABLE `vendor_transactions`
  ADD PRIMARY KEY (`v_transaction_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2024 at 02:19 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `billing`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_mstr`
--

CREATE TABLE `admin_mstr` (
  `admin_id` varchar(50) NOT NULL,
  `admin_full_name` varchar(150) NOT NULL,
  `admin_added_date` varchar(50) NOT NULL,
  `admin_status` int(11) NOT NULL DEFAULT '1',
  `admin_username` varchar(10) NOT NULL,
  `admin_password` text NOT NULL,
  `admin_contact_number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_mstr`
--

INSERT INTO `admin_mstr` (`admin_id`, `admin_full_name`, `admin_added_date`, `admin_status`, `admin_username`, `admin_password`, `admin_contact_number`) VALUES
('151277', 'Shripad Bhadole', '2018-12-23', 1, 'bhadole', 'bhadole', '7028050808');

-- --------------------------------------------------------

--
-- Table structure for table `billed_product_mstr`
--

CREATE TABLE `billed_product_mstr` (
  `tr_id` varchar(50) NOT NULL,
  `bill_id` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `product_quantity` double NOT NULL,
  `product_rate` double NOT NULL,
  `applied_taxes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bill_mstr`
--

CREATE TABLE `bill_mstr` (
  `bill_id` varchar(50) NOT NULL,
  `bill_no` varchar(50) NOT NULL,
  `bill_date` varchar(50) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `tax_bill` int(11) NOT NULL DEFAULT '0',
  `total_amount` double NOT NULL,
  `discount_amount` double NOT NULL,
  `final_amount` double NOT NULL,
  `paid_amount` double NOT NULL,
  `remained_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_mstr`
--

CREATE TABLE `customer_mstr` (
  `customer_id` varchar(50) NOT NULL,
  `customer_name` text NOT NULL,
  `customer_address` text NOT NULL,
  `customer_contact_person` varchar(50) NOT NULL,
  `customer_contact_no` varchar(50) NOT NULL,
  `customer_email_id` varchar(50) NOT NULL,
  `customer_gst_no` varchar(50) NOT NULL,
  `customer_outstand` double NOT NULL,
  `customer_status` int(11) NOT NULL DEFAULT '1',
  `customer_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_transactions`
--

CREATE TABLE `customer_transactions` (
  `c_transaction_id` varchar(50) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `c_transaction_date` varchar(50) NOT NULL,
  `c_transaction_discription` text NOT NULL,
  `c_transaction_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_mstr`
--

CREATE TABLE `product_mstr` (
  `product_id` varchar(50) NOT NULL,
  `product_name` text NOT NULL,
  `product_stock` double NOT NULL,
  `product_unit` varchar(10) NOT NULL,
  `product_min_stock` double NOT NULL,
  `product_expiry_date` double NOT NULL,
  `product_batch_no` VARCHAR(50) NOT NULL,
  `product_hsn_code` varchar(50) NOT NULL,
  `product_mrp` double NOT NULL,
  `product_asp` double NOT NULL,
  `product_discription` text NOT NULL,
  `product_taxes` text NOT NULL,
  `product_vendor_code` varchar(50) NOT NULL,
  `product_status` int(11) NOT NULL DEFAULT '1',
  `product_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shop_mstr`
--

CREATE TABLE `shop_mstr` (
  `shop_id` int(11) NOT NULL,
  `shop_name` text NOT NULL,
  `shop_address` text NOT NULL,
  `shop_contact_person` text NOT NULL,
  `shop_contact_no` varchar(70) NOT NULL,
  `shop_email_id` varchar(70) NOT NULL,
  `shop_gst_no` varchar(50) NOT NULL,
  `shop_logo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_mstr`
--

INSERT INTO `shop_mstr` (`shop_id`, `shop_name`, `shop_address`, `shop_contact_person`, `shop_contact_no`, `shop_email_id`, `shop_gst_no`, `shop_logo`) VALUES
(1, ' Bhadole Machinaries Stores ', 'Vairag Tal-Barshi  Dist- Solapur Pin -413402', '', '9604245997=7058692203', 'dfdf@fgsdf.com', '', '316459123_2402525806583015_6620130024897776000_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tax_mstr`
--

CREATE TABLE `tax_mstr` (
  `tax_id` varchar(50) NOT NULL,
  `tax_name` varchar(50) NOT NULL,
  `tax_amount` double NOT NULL,
  `tax_added_date` varchar(50) NOT NULL,
  `tax_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_mstr`
--

CREATE TABLE `vendor_mstr` (
  `vendor_id` varchar(50) NOT NULL,
  `vendor_name` text NOT NULL,
  `vendor_address` text NOT NULL,
  `vendor_contact_person` varchar(50) NOT NULL,
  `vendor_contact_no` varchar(50) NOT NULL,
  `vendor_email_id` varchar(50) NOT NULL,
  `vendor_gst_no` varchar(50) NOT NULL,
  `vendor_outstand` double NOT NULL,
  `vendor_status` int(11) NOT NULL DEFAULT '1',
  `vendor_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_mstr`
--

INSERT INTO `vendor_mstr` (`vendor_id`, `vendor_name`, `vendor_address`, `vendor_contact_person`, `vendor_contact_no`, `vendor_email_id`, `vendor_gst_no`, `vendor_outstand`, `vendor_status`, `vendor_added_date`) VALUES
('1v0SfXhwyWlNpRLOK4YG', 'Akshay Treders', 'Pandharpur', '', '', '', '', 90680, 1, '2024-03-31'),
('25aySIWUqLZHbVwzBTjFuRpdnDMh', 'zzzz', 'nbb', '', '', '', '', 3800, 1, '2024-06-07'),
('3mX1AEpLVywFhkiKBbl', 'S.S.Agro', 'Kurdwadi', '', '', '', '', 32030, 1, '2024-04-01'),
('6v8PUJKGXOWrSB21gksea0p', 'Arjun Pipe ', 'Mangelwedha', '', '', '', '', 159091, 1, '2024-04-01'),
('CYuDZNHF2oz5pG08rWKaiOnytdm', 'Jay Patil Vipo Pump', 'Ahemadabad', '', '', '', '', 171334, 1, '2024-06-19'),
('DwN4gt39H6R8zne2IcC1', 'Maharajeshwar Machinery', 'Barsshi', '', '', '', '', 14200, 1, '2024-04-01'),
('kgeaTx8FUQRPmu2li0V9nq7dzh', 'Rati', 'Kalkuta', '', '', '', '', 34464, 1, '2024-04-01'),
('MucpHjrITOF0CyXtnQW5d3ez', 'Yogi Plastic', 'Barshi', '', '', '', '', 117048, 1, '2024-04-01'),
('qcS51dk072Cx9UMeln4fmbJr6NY8sO', 'Doshi Plastic', 'Barshi', '', '', '', '', 50295, 1, '2024-03-31'),
('S47GcNrJmDoQveAP', 'Sahyadri Services', 'Solapur', '', '', '', '', 22120, 1, '2024-03-01'),
('tIn8cmeLrJh06KNbqBfFGZzloRP4V', 'Kotiyard', 'Ahemadabad', '', '', '', '', 18014, 1, '2024-04-01'),
('UhJGBRwYMoKZ781sfuiHWcT', 'ccccc', 'Vairag', '', '', '', '', 300, 1, '2024-06-20'),
('UiT8VoJx7jdM9YWtkl6H', 'aaa', 'a', '', '', '', '', 1800, 1, '2024-06-05'),
('wCqMdnZe8zKtjERSD34OLchvQJp', 'Purohit ', 'Kurdwadi', '', '', '', '', 4000, 1, '2024-03-31'),
('XqQL3CNoHR2ecO0fFE5MSdw', 'Laxmi Sals', 'Barshi', '', '', '', '', 16534, 1, '2024-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_transactions`
--

CREATE TABLE `vendor_transactions` (
  `v_transaction_id` varchar(50) NOT NULL,
  `vendor_id` varchar(50) NOT NULL,
  `v_transaction_date` varchar(50) NOT NULL,
  `v_transaction_discription` text NOT NULL,
  `v_transaction_amount` double NOT NULL,
  `v_transaction_total_amount` double DEFAULT NULL,
  `v_transaction_note` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_transactions`
--

INSERT INTO `vendor_transactions` (`v_transaction_id`, `vendor_id`, `v_transaction_date`, `v_transaction_discription`, `v_transaction_amount`, `v_transaction_total_amount`, `v_transaction_note`) VALUES
('0vzhONl8TgZuP62', '3mX1AEpLVywFhkiKBbl', '2024-04-22', 'Purchased of bill no. Paid 13750 And total amount', 13750, 0, 'Cash'),
('1Johx4Z3BwSDf2GLcXKpWbPQFV86', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-05', 'Purchased of bill no. Paid  And total amount77205', 0, 77205, 'Bill'),
('1JYtaAqRFwLbPCshgX', '3mX1AEpLVywFhkiKBbl', '2024-04-12', 'Purchased of bill no. Paid 28249 And total amount45549', 28249, 45549, 'Bill or Cassh'),
('2LHPuasG4zkZmj897lxg', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-26', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('31zct9jGOJlVWrXF', '1v0SfXhwyWlNpRLOK4YG', '2024-05-13', 'Purchased of bill no. Paid 70000 And total amount', 70000, 0, 'RTGS Central Bank'),
('35zwmdnVcYr4CUyJLvpA1Xlb', 'UiT8VoJx7jdM9YWtkl6H', '2024-06-07', 'Purchased of bill no. Paid 200 And total amount', 200, 0, 'ghfxgh'),
('3kVfKnIj7EMahLr640o', '6v8PUJKGXOWrSB21gksea0p', '2024-05-24', 'Purchased of bill no. Paid 25750 And total amount', 25750, 0, 'RTGS O.J.S.Bank'),
('4ut57EcwNmoJlaWCkfqbHTMBOK', 'UiT8VoJx7jdM9YWtkl6H', '2024-06-05', 'Initial balance(Prev.)', 2000, NULL, NULL),
('5AwopzOfZDucWkJyQd6mPrL', '25aySIWUqLZHbVwzBTjFuRpdnDMh', '2024-06-07', 'Initial balance(Prev.)', 0, NULL, NULL),
('5zgbTy1jWK2YeH4XPdmkhDtaVMOJ', 'DwN4gt39H6R8zne2IcC1', '2024-05-06', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('6T8ZwsMd14Oc3aQoCRiI', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-07-03', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('8sqGw2nrUWHJTbuaNclQti59fyX', '1v0SfXhwyWlNpRLOK4YG', '2024-04-23', 'Purchased of bill no. Paid 40000 And total amount', 40000, 0, 'Rt'),
('9eyMq1BNFaRwQ0DXoT8', 'wCqMdnZe8zKtjERSD34OLchvQJp', '2024-04-05', 'Purchased of bill no. Paid 5470 And total amount5970', 5470, 5970, 'bill or cash'),
('9ML6WEvQHdG7qhXxu', '3mX1AEpLVywFhkiKBbl', '2024-07-13', 'Purchased of bill no. Paid 15000 And total amount', 15000, 0, 'Cash'),
('9tOkoZeiE4lpJNBvFXT8sS1qDIMc6', '6v8PUJKGXOWrSB21gksea0p', '2024-05-20', 'Purchased of bill no. Paid 25000 And total amount', 25000, 0, 'RTGS O.J.S.Bank'),
('a9JtWRnbsHOErZKYvlGizNpTA3VSF', 'S47GcNrJmDoQveAP', '2024-04-03', 'Purchased of bill no. Paid  And total amount13780', 0, 13780, '1HP Motor Bill'),
('aM5vJOydCbxKZD3iX498VBh', '3mX1AEpLVywFhkiKBbl', '2024-04-22', 'Purchased of bill no. Paid  And total amount12750', 0, 12750, 'Bill'),
('AOjxS64LYr9msZH2ca8EpKt', '3mX1AEpLVywFhkiKBbl', '2024-05-02', 'Purchased of bill no. Paid 6600 And total amount', 6600, 0, 'Cash'),
('Aoz6STKkNqBigv4ufPnJ9M1ZQ', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-19', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('apKHWVZcSukQvdoRT7NIPF2r5O3B', 'XqQL3CNoHR2ecO0fFE5MSdw', '2024-04-05', 'Purchased of bill no. Paid 5000 And total amount', 5000, 0, 'Cash '),
('aVmYLuGjJTitpvNh5r8Ds9Ekxd2C', '1v0SfXhwyWlNpRLOK4YG', '2024-04-13', 'Purchased of bill no. Paid 50000 And total amount', 50000, 0, 'RTGS Central Bank'),
('CaDGYNcbqMRBzTjUunW1ES45Xfm', 'S47GcNrJmDoQveAP', '2024-04-15', 'Purchased of bill no. Paid  And total amount19950', 0, 19950, '14mm Cable Bill'),
('CGlKPSa2iqoTYB7vJQkLtHrx6FRp', 'kgeaTx8FUQRPmu2li0V9nq7dzh', '2024-06-15', 'Purchased of bill no. Paid  And total amount34464', 0, 34464, 'Bill'),
('cmf5wQsrkg17u6C3ULFjiJD9', 'XqQL3CNoHR2ecO0fFE5MSdw', '2024-01-01', 'Purchased of bill no. Paid  And total amount19996', 0, 19996, ''),
('CmjZSiMEQKe5DILa9J8vXktwc', '1v0SfXhwyWlNpRLOK4YG', '2024-05-15', 'Purchased of bill no. Paid  And total amount61687', 0, 61687, 'Bill'),
('Cpva0S9oBceFKtmPWgAj', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-06-19', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('dFNDsWSjYuC3RniXc6', 'XqQL3CNoHR2ecO0fFE5MSdw', '2024-05-22', 'Purchased of bill no. Paid 5000 And total amount', 5000, 0, 'Cash'),
('dfpaO1BKnmbLCWcGZ5hVvQYUz76kA3', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-01', 'Initial balance(Prev.)', 98944, NULL, NULL),
('dgvO9AFNX0okPwRJCU2S5DfQ1luBM', 'wCqMdnZe8zKtjERSD34OLchvQJp', '2024-05-10', 'Purchased of bill no. Paid 4180 And total amount3180', 4180, 3180, 'Bill or Cassh'),
('DXZgoKzpLysNlMrQV', 'S47GcNrJmDoQveAP', '2024-05-10', 'Purchased of bill no. Paid  And total amount17130', 0, 17130, '0.5 HP motor or 3/2\'\' Garden pipe Bill'),
('dzcQBp0ULtRjAFnr7Co', 'DwN4gt39H6R8zne2IcC1', '2024-04-01', 'Initial balance(Prev.)', 21500, NULL, NULL),
('e4fuilqcKMm83nX5FaIWTJj', '3mX1AEpLVywFhkiKBbl', '2024-06-15', 'Purchased of bill no. Paid  And total amount4050', 0, 4050, 'Bill'),
('e4iIfuEUvAQLtykhZ5B2', '1v0SfXhwyWlNpRLOK4YG', '2024-06-13', 'Purchased of bill no. Paid 35000 And total amount', 35000, 0, 'RTGS Central Bank'),
('e6jXaRxzOytkYm3S7ZF4K5duVU2siH', 'kgeaTx8FUQRPmu2li0V9nq7dzh', '2024-04-01', 'Initial balance(Prev.)', 0, NULL, NULL),
('e7w1xJ39Uy6iOro', '3mX1AEpLVywFhkiKBbl', '2024-07-03', 'Purchased of bill no. Paid 15000 And total amount', 15000, 0, 'phone pay Sagar'),
('EH2y3uAmlsRt4PZQeapnCdNShfD9T8', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-13', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('ENAiJCsevVfyaPh', 'tIn8cmeLrJh06KNbqBfFGZzloRP4V', '2024-04-17', 'Purchased of bill no. Paid 2400 And total amount', 2400, 0, 'Cash '),
('ExpAFgX2DPeZ3jyLkfYq', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-06', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('fdgkLCeEZy5zh0Kc', 'XqQL3CNoHR2ecO0fFE5MSdw', '2024-04-23', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('FEy1XVamGCqg4zNZK2093RifIkbohL', '1v0SfXhwyWlNpRLOK4YG', '2024-06-19', 'Purchased of bill no. Paid  And total amount46272', 0, 46272, 'Bill'),
('fGxN5bYKP8I2WVmkEBgs', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-06-29', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('fMPOApGhga2tLYiNusR3S', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-03', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('GDcMPQsdCgWjJt6enAK7', '1v0SfXhwyWlNpRLOK4YG', '2024-04-13', 'Purchased of bill no. Paid  And total amount50000', 0, 50000, 'Mistak by my entry'),
('GXqDNoPHQ0wS52rte3usLAyUn', '1v0SfXhwyWlNpRLOK4YG', '2024-05-03', 'Purchased of bill no. Paid  And total amount76950', 0, 76950, 'Bill'),
('HGz3yBWLOlEwPNRUrbmI', '3mX1AEpLVywFhkiKBbl', '2024-05-02', 'Purchased of bill no. Paid  And total amount8600', 0, 8600, 'Bill'),
('HycdaNbGSoMC2fZ3r8TFlmutwzkY', 'S47GcNrJmDoQveAP', '2024-04-08', 'Purchased of bill no. Paid 20000 And total amount', 20000, 0, 'RTGS O.J.S.Bank'),
('IMPgA3hfkqRduYwBK4DZzUvimJxe', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-06-08', 'Purchased of bill no. Paid  And total amount64827', 0, 64827, 'Bill Rate diffrance 975 add 110mm pipe'),
('InxsGOd83iTKywVHfEWqzjD', 'DwN4gt39H6R8zne2IcC1', '2024-07-24', 'Purchased of bill no. Paid  And total amount8500', 0, 8500, '3 hp big ss o/w Laxmi'),
('iy84oaEKPurWHk1nNtmwpUCs', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-12', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('iZp0VYKWaFvrSwT8k3dEhxuJ9QsDt', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-06-03', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('J6BNpTWbytLrSFYPH', '1v0SfXhwyWlNpRLOK4YG', '2024-04-15', 'Purchased of bill no. Paid 90000 And total amount', 90000, 0, 'RTGS Central Bank'),
('Jf4SsXNRC9PBpL1xTokUM6bQH', 'UhJGBRwYMoKZ781sfuiHWcT', '2024-06-21', 'Purchased of bill no. Paid 200 And total amount', 200, 0, 'Cash'),
('JfLTZKkE3n7NmURdgi', '6v8PUJKGXOWrSB21gksea0p', '2024-04-30', 'Purchased of bill no. Paid 23750 And total amount', 23750, 0, 'RTGS O.J.S.Bank'),
('jLSvGh1mFkVIoQXzn5g', '1v0SfXhwyWlNpRLOK4YG', '2024-04-03', 'Purchased of bill no. Paid 50000 And total amount', 50000, 0, 'RTGS Central Bank'),
('JVXdfbT95LRm6QGAlrNP2y', '25aySIWUqLZHbVwzBTjFuRpdnDMh', '2024-06-20', 'Purchased of bill no. Paid 200 And total amount', 200, 0, 'Bill'),
('JyZfYbRpgvLqscX', '1v0SfXhwyWlNpRLOK4YG', '2024-03-31', 'Initial balance(Prev.)', 132700, NULL, NULL),
('jzE6iYBXO9THuta7ImJ', '3mX1AEpLVywFhkiKBbl', '2024-04-13', 'Purchased of bill no. Paid  And total amount1900', 0, 1900, 'Bill'),
('k7GOsBi1wjDQLXzUWrK6V4aJbyxPEq', 'qcS51dk072Cx9UMeln4fmbJr6NY8sO', '2024-07-09', 'Purchased of bill no. Paid  And total amount10000', 0, 10000, 'misstak bill'),
('KptjFylqS3f8AbaMHLi4nCBQxVgDv1', '1v0SfXhwyWlNpRLOK4YG', '2024-05-06', 'Purchased of bill no. Paid 40000 And total amount', 40000, 0, 'RTGS Central Bank'),
('kwnOl4IdSLsFrKmb', '3mX1AEpLVywFhkiKBbl', '2024-05-02', 'Purchased of bill no. Paid 18574 And total amount', 18574, 0, 'Cash'),
('kzj17YXHCgb0Jmwsl', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-06-07', 'Purchased of bill no. Paid 15000 And total amount', 15000, 0, 'Cash'),
('l1brN5X2w70CimWTAz9xVhq', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-06-26', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('l1W6sI40aJYymoMQPtTv', '25aySIWUqLZHbVwzBTjFuRpdnDMh', '2024-06-14', 'Purchased of bill no. Paid  And total amount4000', 0, 4000, 'cash'),
('l2Kj3DuLpWYck9NHUaOxVAgIEi', 'S47GcNrJmDoQveAP', '2024-04-15', 'Purchased of bill no. Paid 19950 And total amount', 19950, 0, 'Cash Cable bill'),
('l45IuPoGYkM0nHbUx892yqSz1d', 'DwN4gt39H6R8zne2IcC1', '2024-05-01', 'Purchased of bill no. Paid  And total amount2700', 0, 2700, '5 hp rate diffrens'),
('l6mH7EGNUAF1vjgLyfRke', '3mX1AEpLVywFhkiKBbl', '2024-05-14', 'Purchased of bill no. Paid  And total amount38575', 0, 38575, 'Bill'),
('LfvjrTnmFa3z1RYCAU', 'tIn8cmeLrJh06KNbqBfFGZzloRP4V', '2024-04-17', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Chak O.J.S.Bank'),
('lh5P8B6xL7MpX1c9KZJoGYIQ3', '6v8PUJKGXOWrSB21gksea0p', '2024-04-06', 'Purchased of bill no. Paid  And total amount73750', 0, 73750, 'Bill'),
('ljPsmbFVkwNp8QcX5M', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-29', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('lnAsVxrqSC1m7DwOH9Mp6Gk4hWU', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-10', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('lnzhuGXcx8qsfySKbjC46dRQVYp', '6v8PUJKGXOWrSB21gksea0p', '2024-05-26', 'Purchased of bill no. Paid  And total amount109590', 0, 109590, 'Bill'),
('lOj7tApY1sDZau9Ind3chfVTe4U', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-20', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('MGO3kDi4P5C9oxudSybmLtnrUZe', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-05', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('MjXNYGH8velrBqp', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-29', 'Purchased of bill no. Paid 15000 And total amount', 15000, 0, 'Cash'),
('MLQOR3HTSvyI18gBDzFGKt', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-20', 'Purchased of bill no. Paid  And total amount75970', 0, 75970, 'Bill'),
('NbF2swuD45SK3pEO1gf', 'CYuDZNHF2oz5pG08rWKaiOnytdm', '2024-06-19', 'Initial balance(Prev.)', 171334, NULL, NULL),
('NBOnK0rlzTDpScxw5u1Jd9LjokvPXs', 'qcS51dk072Cx9UMeln4fmbJr6NY8sO', '2024-07-09', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('NCEeGf2jTwP6XaAqiM8JYFt1z', '1v0SfXhwyWlNpRLOK4YG', '2024-04-15', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'RTGS Central Bank'),
('NtywD7khxLfv52m3VTcApHsjd', 'S47GcNrJmDoQveAP', '2024-05-08', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'RTGS O.J.S.Bank'),
('NzpoOMWy5L3JZYe9vXf6G', '3mX1AEpLVywFhkiKBbl', '2024-05-01', 'Purchased of bill no. Paid 6000 And total amount', 6000, 0, 'phone pay'),
('OaN46oiqgfkeBh8', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-27', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('ocFCrySs3qPtgpjl8R5vMJU6', 'DwN4gt39H6R8zne2IcC1', '2024-07-24', 'Purchased of bill no. Paid 8500 And total amount', 8500, 0, '3 hp cash'),
('ODdjznR2xaF54ErKcMu3GykX8s1SpP', 'XqQL3CNoHR2ecO0fFE5MSdw', '2024-03-31', 'Initial balance(Prev.)', 16538, NULL, NULL),
('oerHh4y9zVpTWJg0NG1ZctiXf782', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-01', 'Purchased of bill no. Paid 15000 And total amount', 15000, 0, 'Cash'),
('p5lFH6vhxtZaY3o', '1v0SfXhwyWlNpRLOK4YG', '2024-05-25', 'Purchased of bill no. Paid  And total amount72657', 0, 72657, 'Bill'),
('Ptwg85RX3q2EDTI6C1', 'S47GcNrJmDoQveAP', '2024-04-12', 'Purchased of bill no. Paid 15000 And total amount', 15000, 0, 'RTGS O.J.S.Bank'),
('qlQ5AEzZGF2eaVpDMTxJbC', '1v0SfXhwyWlNpRLOK4YG', '2024-04-12', 'Purchased of bill no. Paid 40000 And total amount', 40000, 0, 'R'),
('qOJdmSwHlGp5AtWLs', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-02', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('Qr4oV3IaZMKDticmzClxBWJu', 'tIn8cmeLrJh06KNbqBfFGZzloRP4V', '2024-05-01', 'Purchased of bill no. Paid  And total amount9381', 0, 9381, 'Ball valve Bill'),
('QVhNGd0OoSyKJn9j4mIM6qe7ErLpbY', 'S47GcNrJmDoQveAP', '2024-06-29', 'Purchased of bill no. Paid 20000 And total amount', 20000, 0, 'RTGS O.J.S.Bank'),
('QvhOnj2UfPLaeImD894MS', 'wCqMdnZe8zKtjERSD34OLchvQJp', '2024-03-31', 'Initial balance(Prev.)', 4500, NULL, NULL),
('R5DQa3Zd2iHcCjuFeWOzV', 'S47GcNrJmDoQveAP', '2024-04-15', 'Purchased of bill no. Paid  And total amount20960', 0, 20960, '0.5HP or 1Hp Motor Bill'),
('RygMjzOfVHWocQ74Ps2xIrXlabTSkA', '1v0SfXhwyWlNpRLOK4YG', '2024-06-22', 'Purchased of bill no. Paid 45000 And total amount', 45000, 0, 'RTGS Central Bank'),
('rYL4GFQeZh2PjycRHwDOTXE0', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-10', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('s94kHKIZqFoM6TVn2xWpwCG1', '6v8PUJKGXOWrSB21gksea0p', '2024-04-01', 'Initial balance(Prev.)', 49501, NULL, NULL),
('sg8EZnoyUf6wRdLVCIuhFlAMi', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-18', 'Purchased of bill no. Paid 15000 And total amount', 15000, 0, 'Cash'),
('SKt58TbEzh0Cik79HpPQ', '3mX1AEpLVywFhkiKBbl', '2024-07-13', 'Purchased of bill no. Paid  And total amount14500', 0, 14500, 'Bill'),
('t3hAJrfzpZ67L1e2', '3mX1AEpLVywFhkiKBbl', '2024-06-24', 'Purchased of bill no. Paid 14051 And total amount49030', 14051, 49030, 'Bill or Cassh'),
('t3iNEh81WGjAZgTesz6LKoQwU', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-10', 'Purchased of bill no. Paid  And total amount69065', 0, 69065, 'Bill'),
('TD1LfZKJhCujwsPrQvUSXe', '3mX1AEpLVywFhkiKBbl', '2024-04-01', 'Initial balance(Prev.)', 3700, NULL, NULL),
('TeVbpNDiHtdBJ2C3kza650qgF', '3mX1AEpLVywFhkiKBbl', '2024-04-12', 'Purchased of bill no. Paid 7900 And total amount', 7900, 0, '63mm or 75mm ballvalve missing rate diffrens'),
('uEKV7q8lGvyQFbhd9Ci6wYJ', '6v8PUJKGXOWrSB21gksea0p', '2024-04-08', 'Purchased of bill no. Paid 50000 And total amount', 50000, 0, 'RTGS O.J.S.Bank'),
('uf9qxtdR4CK2DZ1SGpjTsv', '1v0SfXhwyWlNpRLOK4YG', '2024-04-13', 'Purchased of bill no. Paid  And total amount180664', 0, 180664, 'Bill'),
('UwHOc5TyE7GbhvMRDBnFxl62X8', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-07-09', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('V3LIJ7zsMUSjZeCw1Gh2PoOqkQAY', 'tIn8cmeLrJh06KNbqBfFGZzloRP4V', '2024-04-01', 'Initial balance(Prev.)', 21033, NULL, NULL),
('V7lzsIAhwRYf58a1jQBX', '3mX1AEpLVywFhkiKBbl', '2024-07-13', 'Purchased of bill no. Paid 1500 And total amount', 1500, 0, 'bill rate difrens pump nozzal cock'),
('WFiLqEnuj5S8rXbQkTYmB4Px2vsNc', 'S47GcNrJmDoQveAP', '2024-03-22', 'Purchased of bill no. Paid  And total amount13005', 0, 13005, '3/4\'\' Garden pipe Bill'),
('wLXTOUugDJ7dsaSxQ', '6v8PUJKGXOWrSB21gksea0p', '2024-04-09', 'Purchased of bill no. Paid  And total amount50750', 0, 50750, 'Bill'),
('wnMGsqgotlxU2QchYEXu1ANv', 'qcS51dk072Cx9UMeln4fmbJr6NY8sO', '2024-03-31', 'Initial balance(Prev.)', 50295, NULL, NULL),
('wtmqiCWx7UygE4dJvP3uFBf0R5ok', '3mX1AEpLVywFhkiKBbl', '2024-06-15', 'Purchased of bill no. Paid 20000 And total amount', 20000, 0, 'Cash'),
('WZ4St5EaldIpODVKAhU0C6B', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-07-16', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('XIcrSGWA8JP7fnZN5M6', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-04-17', 'Purchased of bill no. Paid 20000 And total amount', 20000, 0, 'Cash'),
('xl5oJFfprhW4NQbS3Cau0IeAwnDmtc', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-05-20', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('xz7dZbfGg6XpolULcrSheqWN', '1v0SfXhwyWlNpRLOK4YG', '2024-05-28', 'Purchased of bill no. Paid 50000 And total amount', 50000, 0, 'RTGS Central Bank'),
('y58tvlaoIuw6J3Li', 'UhJGBRwYMoKZ781sfuiHWcT', '2024-06-20', 'Initial balance(Prev.)', 500, NULL, NULL),
('Y8eBawfThC0iHsqSDnX1d3z6tg2AQy', '1v0SfXhwyWlNpRLOK4YG', '2024-06-01', 'Purchased of bill no. Paid 25000 And total amount', 25000, 0, 'RTGS Central Bank'),
('y9fGJjRF3uNlxQeM5p18DcOwv', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-06-25', 'Purchased of bill no. Paid  And total amount31037', 0, 31037, 'Bill'),
('ydg4FHmcpLs37ODheUkCft0nu9jQ', 'S47GcNrJmDoQveAP', '2024-03-01', 'Initial balance(Prev.)', 22245, NULL, NULL),
('Z13G4nkxtYMhXTau', 'MucpHjrITOF0CyXtnQW5d3ez', '2024-06-16', 'Purchased of bill no. Paid 10000 And total amount', 10000, 0, 'Cash'),
('ZnPeERBt9zx4sbUL1u', '1v0SfXhwyWlNpRLOK4YG', '2024-06-22', 'Purchased of bill no. Paid  And total amount39750', 0, 39750, 'Bill'),
('zTZIqHhkvEyiVP0', '1v0SfXhwyWlNpRLOK4YG', '2024-07-11', 'Purchased of bill no. Paid 25000 And total amount', 25000, 0, 'RTGS Central Bank');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_mstr`
--
ALTER TABLE `admin_mstr`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `billed_product_mstr`
--
ALTER TABLE `billed_product_mstr`
  ADD PRIMARY KEY (`tr_id`);

--
-- Indexes for table `bill_mstr`
--
ALTER TABLE `bill_mstr`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `customer_mstr`
--
ALTER TABLE `customer_mstr`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_transactions`
--
ALTER TABLE `customer_transactions`
  ADD PRIMARY KEY (`c_transaction_id`);

--
-- Indexes for table `product_mstr`
--
ALTER TABLE `product_mstr`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `shop_mstr`
--
ALTER TABLE `shop_mstr`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `tax_mstr`
--
ALTER TABLE `tax_mstr`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `vendor_mstr`
--
ALTER TABLE `vendor_mstr`
  ADD PRIMARY KEY (`vendor_id`);

--
-- Indexes for table `vendor_transactions`
--
ALTER TABLE `vendor_transactions`
  ADD PRIMARY KEY (`v_transaction_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
		date_default_timezone_set("Asia/Kolkata");
	}
	public function dashboard()
	{
		$all_products_count = $this->admin_model->get_all_products_count();
		$all_customers_count = $this->admin_model->get_all_customers_count();
		$all_vendors_count = $this->admin_model->get_all_vendors_count();
		$all_min_stocked_count = $this->admin_model->all_min_stocked_count();
		$todays_invoices_count = $this->admin_model->todays_invoices_count();
		$this->load->view('dashboard',['all_products_count'=>$all_products_count,'all_customers_count'=>$all_customers_count,'all_vendors_count'=>$all_vendors_count,'all_min_stocked_count'=>$all_min_stocked_count,'todays_invoices_count'=>$todays_invoices_count]);
	}
	public function getLowStockProducts($offset=0)
	{
		$this->load->library('pagination');
		
		$searched_products_num = $this->admin_model->all_min_stocked_count();
		$pagination_generic = $this->set_pagination();
		$pagination_generic['base_url'] = base_url('admin/getLowStockProducts');
		$pagination_generic['per_page'] = 10;
		$pagination_generic['total_rows'] = $searched_products_num->total_count;
		$this->pagination->initialize($pagination_generic);
		$all_products = $this->admin_model->all_min_stocked($pagination_generic['per_page'],$this->uri->segment(3));
		$this->load->view('view-low-count-products',['all_products'=>$all_products]);
	}
	
	public function index()
	{
		$shop_details = $this->admin_model->get_shop_details();
		$this->load->view('shop_details',['shop_details'=>$shop_details]);
	}
	function set_upload_options()
	{
		//upload an image options
		$config = array();
		$config['upload_path'] = './thems/assets/img';
		$config['allowed_types'] = '*';
		$config['overwrite']     = FALSE;
		return $config;
	}
	public function remove_file($file_name)
	{
		$this->load->helper('file');
		if(file_exists("./thems/assets/img/".$file_name)==true)
		{
			$path_to_file = "./thems/assets/img/".$file_name;
			if(unlink($path_to_file))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	public function set_pagination()
	{
		$config =[
					'full_tag_open'=>"<ul class='pagination block-center'>",
					'full_tag_close'=>'</ul>',
					'next_tag_open'=>'<li class="page-link">',
					'next_tag_close'=>'</li>',
					'prev_tag_open'=>'<li class="page-link">',
					'prev_tag_close'=>'</li>',
					'num_tag_open'=>'<li class="page-link">',
					'num_tag_close'=>'</li>',
					'cur_tag_open'=>'<li class="active page-link"><a>',
					'cur_tag_close'=>'</a></li>',
					'first_tag_open'=>'<li class="page-link">',
					'first_tag_close'=>'</li>',
					'last_tag_open'=>'<li class="page-link">',
					'last_tag_close'=>'</li>',
					'next_link'=>'NEXT >> ',
					'prev_link'=>' << PREV ',
					'first_url'=>'0',
					];
		return $config;
	}
	public function pageNotFound()
	{
		echo 'Page not found';
	}
	
	public function updateShopDetails()
	{
		$shop_details = $this->admin_model->get_shop_details();
		if($shop_input_details = $this->input->post())
		{
			$this->load->library('upload');
			$this->upload->initialize($this->set_upload_options());
			if($this->upload->do_upload('shop_logo'))
			{
				$data=$this->upload->data();
				$shop_logo = $data['raw_name'].$data['file_ext'];
				$shop_input_details['shop_logo']=$shop_logo;
				$remove_file = $this->remove_file($shop_details->shop_logo);
				
			}
			return $this->_flashdatacheck($success=$this->admin_model->update_shop_details($shop_input_details),"Successfully updated","Failed to save. please try again",'admin');
		}
		else
		{
			$this->load->view('update_shop_details',['shop_details'=>$shop_details]);
		}
	}
	public function addTax()
	{
		if($tax_details = $this->input->post())
		{
			$this->load->library('form_validation');
		    $this->form_validation->set_rules('tax_name','Tax Name','required|is_unique[tax_mstr.tax_name]');
		    $this->form_validation->set_rules('tax_amount','Tax Amount','required');
			if($this->form_validation->run())
			{
				return $this->_flashdatacheck($success=$this->admin_model->add_tax($tax_details),"Successfully updated","Failed to save. please try again",'admin/addtax');
			}
			else
			{
				$this->form_validation->set_error_delimiters("<span class='text text-danger'>", "</span>");
				$this->load->view('add-tax');
			}
		}
		else
		{
			$this->load->view('add-tax');
		}
	}
	public function getTaxes()
	{
		$all_taxes = $this->admin_model->get_taxes();
		$this->load->view('view-taxes',['all_taxes'=>$all_taxes]);		
	}
	public function editTax($tax_id=null)
	{
		if($tax_id)
		{
			$tax_details = $this->admin_model->get_tax($tax_id);
			if($tax_details)
			{
				if($tax_detailss = $this->input->post())
				{
					$this->load->library('form_validation');
					
					$check_duplicate_value = $this->admin_model->check_duplicate_value('tax_mstr','tax_name',$tax_detailss['tax_name'],'tax_id',$tax_id);
					if($check_duplicate_value)
					{
						$this->form_validation->set_rules('tax_name','Tax Name','required|is_unique[tax_mstr.tax_name]');
					}
					else
					{
						$this->form_validation->set_rules('tax_name','Tax Name','required');
					}
					$this->form_validation->set_rules('tax_amount','Tax Amount','required');
					if($this->form_validation->run())
					{
						return $this->_flashdatacheck($success=$this->admin_model->update_tax($tax_detailss,$tax_id),"Successfully updated","Failed to save. please try again",'admin/getTaxes');
					}
					else
					{
						$this->form_validation->set_error_delimiters("<span class='text text-danger'>", "</span>");
						$this->load->view('edit-tax',['tax_details'=>$tax_details]);
					}
				}
				else
				{
					$this->load->view('edit-tax',['tax_details'=>$tax_details]);
				}
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	
	public function deleteTax($tax_id=null)
	{
		if($tax_id)
		{
			$tax_details = $this->admin_model->get_tax($tax_id);
			if($tax_details)
			{
				return $this->_flashdatacheck($success=$this->admin_model->delete_tax($tax_id),"Successfully deleted","Failed to save. please try again",'admin/getTaxes');
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	public function addVendor()
	{
		if($vendor_details = $this->input->post())
		{
			$this->load->library('form_validation');
		    $this->form_validation->set_rules('vendor_name','Vendor Name','required');
		    $this->form_validation->set_rules('vendor_address','Vendor Address','required');
			if($this->form_validation->run())
			{
				return $this->_flashdatacheck($success=$this->admin_model->add_vendor($vendor_details),"Successfully saved","Failed to save. please try again",'admin/addVendor');
			}
			else
			{
				$this->form_validation->set_error_delimiters("<span class='text text-danger'>", "</span>");
				$this->load->view('add-tax');
			}
		}
		else
		{
			$this->load->view('add-vendor');
		}
	}
	public function getVendors($offset = 0)
	{
		$vendor_name = '';
		$vendor_address = '';
		$vendor_contact_no = '';
		$vendor_contact_person = '';
		$per_page_row = 10;
		if($searched_vendor_details = $this->input->post())
		{
			$this->session->set_userdata('serarched_vendor_name',$searched_vendor_details['vendor_name']);
			$this->session->set_userdata('serarched_vendor_address',$searched_vendor_details['vendor_address']);
			$this->session->set_userdata('serarched_vendor_contact_no',$searched_vendor_details['vendor_contact_no']);
			$this->session->set_userdata('serarched_vendor_contact_person',$searched_vendor_details['vendor_contact_person']);
			$this->session->set_userdata('searched_vendor_per_page',$searched_vendor_details['per_page_row']);
			$this->session->set_userdata('searched_vendor',1);
		}
		if($this->session->userdata('searched_vendor'))
		{
			$vendor_name = $this->session->userdata('serarched_vendor_name');
			$vendor_address = $this->session->userdata('serarched_vendor_address');
			$vendor_contact_no = $this->session->userdata('serarched_vendor_contact_no');
			$vendor_contact_person = $this->session->userdata('serarched_vendor_contact_person');
			$per_page_row = $this->session->userdata('searched_vendor_per_page');
		}
		$search_array['vendor_name']=$vendor_name;
		$search_array['vendor_address']=$vendor_address;
		$search_array['vendor_contact_no']=$vendor_contact_no;
		$search_array['vendor_contact_person']=$vendor_contact_person;
		
		$this->load->library('pagination');
		
		$searched_vendors_num = $this->admin_model->get_searched_vendors_num($search_array);
		$pagination_generic = $this->set_pagination();
		$pagination_generic['base_url'] = base_url('admin/getVendors');
		$pagination_generic['per_page'] = $per_page_row;
		$pagination_generic['total_rows'] = $searched_vendors_num->total_count;
		$this->pagination->initialize($pagination_generic);
		$all_vendors = $this->admin_model->get_searched_vendors($search_array,$per_page_row,$this->uri->segment(3));
		$this->load->view('view-vendors',['all_vendors'=>$all_vendors]);
	}
	public function editVendor($vendor_id=null)
	{
		if($vendor_id)
		{
			$vendor_details = $this->admin_model->get_vendor($vendor_id);
			if($vendor_details)
			{
				if($vendor_detailss = $this->input->post())
				{
					$this->load->library('form_validation');
					$this->form_validation->set_rules('vendor_name','vendor Name','required');
					$this->form_validation->set_rules('vendor_address','vendor Address','required');
					if($this->form_validation->run())
					{
						return $this->_flashdatacheck($success=$this->admin_model->update_vendor($vendor_detailss,$vendor_id),"Successfully updated","Failed to save. please try again",'admin/getVendors');
					}
					else
					{
						$this->form_validation->set_error_delimiters("<span class='text text-danger'>", "</span>");
						$this->load->view('edit-vendor',['vendor_details'=>$vendor_details]);
					}
				}
				else
				{
					$this->load->view('edit-vendor',['vendor_details'=>$vendor_details]);
				}
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	public function deleteVendor($vendor_id=null)
	{
		if($vendor_id)
		{
			$vendor_details = $this->admin_model->get_vendor($vendor_id);
			if($vendor_details)
			{
				return $this->_flashdatacheck($success=$this->admin_model->delete_vendor($vendor_id),"Successfully deleted","Failed to save. please try again",'admin/getVendors');
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	public function addCustomer()
	{
		if($customer_details = $this->input->post())
		{
			$this->load->library('form_validation');
		    $this->form_validation->set_rules('customer_name','customer Name','required');
		    $this->form_validation->set_rules('customer_address','customer Address','required');
			if($this->form_validation->run())
			{
				return $this->_flashdatacheck($success=$this->admin_model->add_customer($customer_details),"Successfully saved","Failed to save. please try again",'admin/addCustomer');
			}
			else
			{
				$this->form_validation->set_error_delimiters("<span class='text text-danger'>", "</span>");
				$this->load->view('add-customer');
			}
		}
		else
		{
			$this->load->view('add-customer');
		}
	}
	public function getCustomers($offset = 0)
	{
		$customer_name = '';
		$customer_address = '';
		$customer_contact_no = '';
		$customer_contact_person = '';
		$per_page_row = 10;
		if($searched_customer_details = $this->input->post())
		{
			$this->session->set_userdata('serarched_customer_name',$searched_customer_details['customer_name']);
			$this->session->set_userdata('serarched_customer_address',$searched_customer_details['customer_address']);
			$this->session->set_userdata('serarched_customer_contact_no',$searched_customer_details['customer_contact_no']);
			$this->session->set_userdata('serarched_customer_contact_person',$searched_customer_details['customer_contact_person']);
			$this->session->set_userdata('searched_customer_per_page',$searched_customer_details['per_page_row']);
			$this->session->set_userdata('searched_customer',1);
		}
		if($this->session->userdata('searched_customer'))
		{
			$customer_name = $this->session->userdata('serarched_customer_name');
			$customer_address = $this->session->userdata('serarched_customer_address');
			$customer_contact_no = $this->session->userdata('serarched_customer_contact_no');
			$customer_contact_person = $this->session->userdata('serarched_customer_contact_person');
			$per_page_row = $this->session->userdata('searched_customer_per_page');
		}
		$search_array['customer_name']=$customer_name;
		$search_array['customer_address']=$customer_address;
		$search_array['customer_contact_no']=$customer_contact_no;
		$search_array['customer_contact_person']=$customer_contact_person;
		
		$this->load->library('pagination');
		
		$searched_customers_num = $this->admin_model->get_searched_customers_num($search_array);
		$pagination_generic = $this->set_pagination();
		$pagination_generic['base_url'] = base_url('admin/getCustomers');
		$pagination_generic['per_page'] = $per_page_row;
		$pagination_generic['total_rows'] = $searched_customers_num->total_count;
		$this->pagination->initialize($pagination_generic);
		$all_customers = $this->admin_model->get_searched_customers($search_array,$per_page_row,$this->uri->segment(3));
		$this->load->view('view-customers',['all_customers'=>$all_customers]);
	}
	public function editCustomer($customer_id=null)
	{
		if($customer_id)
		{
			$customer_details = $this->admin_model->get_customer($customer_id);
			if($customer_details)
			{
				if($customer_detailss = $this->input->post())
				{
					$this->load->library('form_validation');
					$this->form_validation->set_rules('customer_name','customer Name','required');
					$this->form_validation->set_rules('customer_address','customer Address','required');
					if($this->form_validation->run())
					{
						return $this->_flashdatacheck($success=$this->admin_model->update_customer($customer_detailss,$customer_id),"Successfully updated","Failed to save. please try again",'admin/getCustomers');
					}
					else
					{
						$this->form_validation->set_error_delimiters("<span class='text text-danger'>", "</span>");
						$this->load->view('edit-customer',['customer_details'=>$customer_details]);
					}
				}
				else
				{
					$this->load->view('edit-customer',['customer_details'=>$customer_details]);
				}
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	public function deleteCustomer($customer_id=null)
	{
		if($customer_id)
		{
			$customer_details = $this->admin_model->get_customer($customer_id);
			if($customer_details)
			{
				return $this->_flashdatacheck($success=$this->admin_model->delete_customer($customer_id),"Successfully deleted","Failed to save. please try again",'admin/getCustomers');
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	public function addProduct()
	{
		$all_vendors = $this->admin_model->get_vendors();
		$all_taxes = $this->admin_model->get_taxes();
		if($product_details = $this->input->post())
		{
			$this->load->library('form_validation');
		    $this->form_validation->set_rules('product_name','Product Name','required|is_unique[product_mstr.product_name]');
		    $this->form_validation->set_rules('product_stock','Product Stock','required');

			$this->form_validation->set_rules('expiry_date', 'Expiry Date', 'required|valid_date');
			$this->form_validation->set_rules('batch_no', 'Batch Number', 'required|alpha_numeric');	
			if($this->form_validation->run())
			{
  
				//added expiry and batch no
				$product_details['expiry_date'] = $this->input->post('expiry_date');
				$product_details['batch_no'] = $this->input->post('batch_no');

				return $this->_flashdatacheck($success=$this->admin_model->add_product($product_details),"Successfully saved","Failed to save. please try again",'admin/addProduct');
			}
			else
			{
				$this->form_validation->set_error_delimiters("<span class='text text-danger'>", "</span>");
				$this->load->view('add-Product',['all_vendors'=>$all_vendors,'all_taxes'=>$all_taxes]);
			}
		}
		else
		{
			$this->load->view('add-product',['all_vendors'=>$all_vendors,'all_taxes'=>$all_taxes]);
		}
	}
	
	public function getProducts($offset = 0)
	{
		$product_name = '';
		$product_hsn = '';
		$product_vendor_name = '';
		$product_discription = '';
		$product_expiry_date = '';
		$product_batch_no = '';
		$per_page_row = 10;
		if($serached_product_details = $this->input->post())
		{
			$this->session->set_userdata('searched_product_name',$serached_product_details['product_name']);
			$this->session->set_userdata('searched_product_hsn',$serached_product_details['product_hsn_code']);
			$this->session->set_userdata('searched_product_vendor_name',$serached_product_details['product_vendor_name']);
			$this->session->set_userdata('searched_product_discription',$serached_product_details['product_discription']);
			$this->session->set_userdata('searched_product_expiry_date', $serached_product_details['product_expiry_date']);
			$this->session->set_userdata('searched_product_batch_no', $serached_product_details['product_batch_no']);	
			$this->session->set_userdata('searched_product_per_page',$serached_product_details['per_page_row']);
			$this->session->set_userdata('searched_product',1);
		}
		if($this->session->userdata('searched_product'))
		{
			$product_name = $this->session->userdata('searched_product_name');
			$product_hsn = $this->session->userdata('searched_product_hsn');
			$product_vendor_name = $this->session->userdata('searched_product_vendor_name');
			$product_discription = $this->session->userdata('searched_product_discription');
			$product_expiry = $this->session->userdata('searched_product_expiry_date');
			$product_batch_no = $this->session->userdata('searched_product_batch_no');	
			$per_page_row = $this->session->userdata('searched_product_per_page');
		}
		$search_array['product_name'] = $product_name;
		$search_array['product_hsn'] = $product_hsn;
		$search_array['product_vendor_name'] = $product_vendor_name;
		$search_array['product_discription'] = $product_discription;
		$search_array['product_expiry_date'] = $product_expiry_date;
		$search_array['product_batch_no'] = $product_batch_no;
		$search_array['per_page_row'] = $per_page_row;
		
		
		$this->load->library('pagination');
		
		$searched_products_num = $this->admin_model->get_searched_products_num($search_array);
		$pagination_generic = $this->set_pagination();
		$pagination_generic['base_url'] = base_url('admin/getProducts');
		$pagination_generic['per_page'] = $per_page_row;
		$pagination_generic['total_rows'] = $searched_products_num->total_count;
		$this->pagination->initialize($pagination_generic);
		$all_products = $this->admin_model->get_searched_products($search_array,$per_page_row,$this->uri->segment(3));
		$this->load->view('view-products',['all_products'=>$all_products]);
	}

	public function editProduct($product_id = null)
	{
		if($product_id)
		{
			$product_detailss = $this->admin_model->get_product($product_id);
			if($product_detailss)
			{
				$all_vendors = $this->admin_model->get_vendors();
				$all_taxes = $this->admin_model->get_taxes();
				if($product_details = $this->input->post())
				{
					$this->load->library('form_validation');
					$check_duplicate_value = $this->admin_model->check_duplicate_value('product_mstr','product_name',$product_details['product_name'],'product_id',$product_id);
					if($check_duplicate_value)
					{
						$this->form_validation->set_rules('product_name','Product Name','required|is_unique[product_mstr.product_name]');
					}
					else
					{
						$this->form_validation->set_rules('product_name','Product Name','required');
					}
					$this->form_validation->set_rules('product_stock','Product Stock','required');
					
					// Added expiry_date and batch_no 
					$this->form_validation->set_rules('expiry_date','Expiry Date','required|valid_date');
					$this->form_validation->set_rules('batch_no', 'Batch Number', 'required|alpha_numeric');

					if($this->form_validation->run())
					{

							// Added expiry_date and batch_no 
							$product_data['expiry_date'] = $this->input->post('expiry_date');
							$product_data['batch_no'] = $this->input->post('batch_no');
		
						return $this->_flashdatacheck($success=$this->admin_model->update_product($product_details,$product_id),"Successfully saved","Failed to save. please try again",'admin/getProducts');
					}
					else
					{
						$this->form_validation->set_error_delimiters("<span class='text text-danger'>", "</span>");
						$this->load->view('edit-Product',['all_vendors'=>$all_vendors,'all_taxes'=>$all_taxes,'product_details'=>$product_detailss]);
					}
				}
				else
				{
					$this->load->view('edit-product',['all_vendors'=>$all_vendors,'all_taxes'=>$all_taxes,'product_details'=>$product_detailss]);
				}
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	public function deleteProduct($product_id=null)
	{
		if($product_id)
		{
			$product_details = $this->admin_model->get_product($product_id);
			if($product_details)
			{
				return $this->_flashdatacheck($success=$this->admin_model->delete_product($product_id),"Successfully deleted","Failed to save. please try again",'admin/getProducts');
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	public function createPurchaseEntry()
	{
		$all_vendors = $this->admin_model->get_vendors();
		if($purchase_details = $this->input->post())
		{
			return $this->_flashdatacheck($success=$this->admin_model->create_purchase_entry($purchase_details),"Successfully saved","Failed to save. please try again",'admin/createPurchaseEntry');
		}
		else
		{
			$this->load->view('create-purchase-entry',['all_vendors'=>$all_vendors]);
		}
	}
	public function createTaxInvoice()
	{
		$all_customers = $this->admin_model->get_customers();
		$all_products = $this->admin_model->get_products();
		if($invoice_details = $this->input->post())
		{
			$success=$this->admin_model->add_tax_invoice($invoice_details);
			if($success)
			{
				return redirect('admin/viewInvoice/'.$success);
				$this->session->set_flashdata('feedback','Successflly Saved invoice.');
				$this->session->set_flashdata('feedback_Class',"alert-success");
			}
			else
			{
				return redirect('admin/createTaxInvoice');
				$this->session->set_flashdata('feedback','Could not be saved. Try again latter.');
				$this->session->set_flashdata('feedback_Class',"alert-success");
			}
			
		}
		else
		{
			$this->load->view('create-tax-invoice',['all_customers'=>$all_customers,'all_products'=>$all_products]);
		}
	}
	public function createInvoice()
	{
		$all_customers = $this->admin_model->get_customers();
		$all_products = $this->admin_model->get_products();
		if($invoice_details = $this->input->post())
		{
			$success=$this->admin_model->add_invoice($invoice_details);
			if($success)
			{
				return redirect('admin/viewInvoice/'.$success);
				$this->session->set_flashdata('feedback','Successflly Saved invoice.');
				$this->session->set_flashdata('feedback_Class',"alert-success");
			}
			else
			{
				return redirect('admin/createTaxInvoice');
				$this->session->set_flashdata('feedback','Could not be saved. Try again latter.');
				$this->session->set_flashdata('feedback_Class',"alert-success");
			}
			
		}
		else
		{
			$this->load->view('create-invoice',['all_customers'=>$all_customers,'all_products'=>$all_products]);
		}
	}
	public function getInvoices($offset = 0)
	{
		$all_customers = $this->admin_model->get_customers();
		$customer_id = '';
		$customer_contact_no = '';
		$from_date = '';
		$to_date = '';
		$bill_no = '';
		$per_page = 10;
		if($searched_invoice_details = $this->input->post())
		{
				$this->session->set_userdata('searched_bill_customer_id',$searched_invoice_details['customer_id']);
				$this->session->set_userdata('searched_bill_contact_no',$searched_invoice_details['customer_contact_no']);
				$this->session->set_userdata('searched_bill_from_date',$searched_invoice_details['from_date']);
				$this->session->set_userdata('searched_bill_to_date',$searched_invoice_details['to_date']);
				$this->session->set_userdata('searched_bill_no',$searched_invoice_details['bill_no']);
				$this->session->set_userdata('searched_bill_per_page',$searched_invoice_details['per_page_row']);
				$this->session->set_userdata('searched_bill',1);
		}
		if($this->session->userdata('searched_bill'))
		{
			$customer_id = $this->session->userdata('searched_bill_customer_id');
			$customer_contact_no = $this->session->userdata('searched_bill_contact_no');
			$from_date = $this->session->userdata('searched_bill_from_date');
			$to_date = $this->session->userdata('searched_bill_to_date');
			$bill_no = $this->session->userdata('searched_bill_no');
			$per_page = $this->session->userdata('searched_bill_per_page');			
		}
		$search_array['customer_id'] = $customer_id;
		$search_array['customer_contact_no'] = $customer_contact_no;
		$search_array['from_date'] = $from_date;
		$search_array['to_date'] = $to_date;
		$search_array['bill_no'] = $bill_no;
		
		$this->load->library('pagination');
		$searched_invoices_num = $this->admin_model->get_searched_invoices_num($search_array);
		$pagination_generic = $this->set_pagination();
		$pagination_generic['base_url'] = base_url('admin/getInvoices');
		$pagination_generic['per_page'] = $per_page;
		$pagination_generic['total_rows'] = $searched_invoices_num->total_count;
		$this->pagination->initialize($pagination_generic);
		$all_bills = $this->admin_model->get_searched_invoices($search_array,$per_page,$this->uri->segment(3));
		$this->load->view('view-invoices',['all_customers'=>$all_customers,'all_bills'=>$all_bills]);
	}
	public function viewInvoice($invoice_id)
	{
		$shop_details = $this->admin_model->get_shop_details();
		if($invoice_id)
		{
			$invoice_details = $this->admin_model->get_invoice($invoice_id);
			if($invoice_details)
			{
				$billed_products = $this->admin_model->get_billed_products($invoice_id);
				$this->load->view('view-invoice',['invoice_details'=>$invoice_details,'shop_details'=>$shop_details,'billed_products'=>$billed_products]);
			}
			else
			{
				return redirect('admin/pageNotFound');
			}
		}
		else
		{
			return redirect('admin/pageNotFound');
		}
	}
	public function inwardTransaction()
	{
		$all_customers = $this->admin_model->get_customers();
		if($transaction_details = $this->input->post())
		{
			return $this->_flashdatacheck($success=$this->admin_model->make_inward_transaction($transaction_details),"Successfully saved","Failed to save. please try again",'admin/inwardTransaction');
		}
		else
		{
			$this->load->view('make-inward-transaction',['all_customers'=>$all_customers]);
		}
	}
	public function outwardTransaction()
	{
		$all_vendors = $this->admin_model->get_vendors();
		if($transaction_details = $this->input->post())
		{
			return $this->_flashdatacheck($success=$this->admin_model->make_outward_transaction($transaction_details),"Successfully saved","Failed to save. please try again",'admin/outwardTransaction');
		}
		else
		{
			$this->load->view('make-outward-transaction',['all_vendors'=>$all_vendors]);
		}
	}
	public function customerReport($selected_customer_id = null)
	{
		$all_customers = $this->admin_model->get_customers();
		$customer_id = $selected_customer_id;
		if($searched_details = $this->input->post())
		{
			$this->session->set_userdata('searched_creport_customer_id',$searched_details['customer_id']);
			$this->session->set_userdata('searched_creport_from_date',$searched_details['from_date']);
			$this->session->set_userdata('searched_creport_to_date',$searched_details['to_date']);
			$this->session->set_userdata('searched_ctrans_per_page',$searched_details['per_page_row']);
			$this->session->set_userdata('searched_customer_report',1);
			return $this->getCustomerReport();
		}
		else
		{
			$this->load->view('get-customer-report',['all_customers'=>$all_customers,'selected_customer_id'=>$selected_customer_id]);
		}
	}
	
	public function getCustomerReport()
	{
		$customer_id = '';
		$from_date = '';
		$to_date = '';
		$per_page_row = 10;
		
		if($this->session->userdata('searched_customer_report'))
		{
			$customer_id = $this->session->userdata('searched_creport_customer_id');
			$from_date = $this->session->userdata('searched_creport_from_date');
			$to_date = $this->session->userdata('searched_creport_to_date');
			$per_page_row = $this->session->userdata('searched_ctrans_per_page');
		}
		
		$search_array['customer_id'] = $customer_id;
		$search_array['from_date'] = $from_date;
		$search_array['to_date'] = $to_date;
		$search_array['per_page_row'] = $per_page_row;
			
		$this->load->library('pagination');
			
		$searched_transactions_num = $this->admin_model->get_customer_transactions_num($search_array);
		$pagination_generic = $this->set_pagination();
		$pagination_generic['base_url'] = base_url('admin/getCustomerReport');
		$pagination_generic['per_page'] = $per_page_row;
		$pagination_generic['total_rows'] = $searched_transactions_num->total_count;
		$this->pagination->initialize($pagination_generic);
		$all_transactions = $this->admin_model->get_customer_transactions($search_array,$per_page_row,$this->uri->segment(3));
		$customer_details = $this->admin_model->get_customer($customer_id);
		$this->load->view('view-customer-report',['all_transactions'=>$all_transactions,'customer_details'=>$customer_details]);
	}
	
	public function vendorReport($selected_vendor_id = null)
	{
		$all_vendors = $this->admin_model->get_vendors();
		$vendor_id = $selected_vendor_id;
		if($searched_details = $this->input->post())
		{
			$this->session->set_userdata('searched_vreport_vendor_id',$searched_details['vendor_id']);
			$this->session->set_userdata('searched_vreport_from_date',$searched_details['from_date']);
			$this->session->set_userdata('searched_vreport_to_date',$searched_details['to_date']);
			$this->session->set_userdata('searched_vtrans_per_page',$searched_details['per_page_row']);
			$this->session->set_userdata('searched_vendor_report',1);
			return $this->getvendorReport();
		}
		else
		{
			$this->load->view('get-vendor-report',['all_vendors'=>$all_vendors,'selected_vendor_id'=>$selected_vendor_id]);
		}
	}
	public function getvendorReport()
	{
		$vendor_id = '';
		$from_date = '';
		$to_date = '';
		$per_page_row = 10;
		
		if($this->session->userdata('searched_vendor_report'))
		{
			$vendor_id = $this->session->userdata('searched_vreport_vendor_id');
			$from_date = $this->session->userdata('searched_vreport_from_date');
			$to_date = $this->session->userdata('searched_vreport_to_date');
			$per_page_row = $this->session->userdata('searched_vtrans_per_page');
		}
		
		$search_array['vendor_id'] = $vendor_id;
		$search_array['from_date'] = $from_date;
		$search_array['to_date'] = $to_date;
		$search_array['per_page_row'] = $per_page_row;
			
		$this->load->library('pagination');
			
		$searched_transactions_num = $this->admin_model->get_vendor_transactions_num($search_array);
		$pagination_generic = $this->set_pagination();
		$pagination_generic['base_url'] = base_url('admin/getvendorReport');
		$pagination_generic['per_page'] = $per_page_row;
		$pagination_generic['total_rows'] = $searched_transactions_num->total_count;
		$this->pagination->initialize($pagination_generic);
		$all_transactions = $this->admin_model->get_vendor_transactions($search_array,$per_page_row,$this->uri->segment(3));
		$vendor_details = $this->admin_model->get_vendor($vendor_id);
		$this->load->view('view-vendor-report',['all_transactions'=>$all_transactions,'vendor_details'=>$vendor_details]);
	}
	
	 public function logout()
	{
		$this->session->sess_destroy();	
		return redirect('login');
	}
	private function _flashdatacheck($successfull, $successMessage, $failureMessage, $redirectTo)
	{
		if($successfull)
		{
			    $this->session->set_flashdata('feedback',$successMessage);
				$this->session->set_flashdata('feedback_Class',"alert-success");
		}
		else
		{
			    $this->session->set_flashdata('feedback',$failureMessage);
				$this->session->set_flashdata('feedback_Class',"alert-danger");
		}
		return redirect($redirectTo);
	}
}

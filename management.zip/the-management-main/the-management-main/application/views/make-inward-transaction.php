<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Inward Transaction</strong></span>
					</div>
					<div class="col-md-6">
							<?php echo anchor('admin/viewInvoices','<button class="btn btn-success"><span class="fa fa-eye"></span> View All Invoices</button>',['class'=>'pull-right']);?>
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/inwardTransaction');?>
			<div class="col-md-12 white-div">
				<div class="row dark-background">
					<div class="col-md-3">
                        <div class="form-group">
							<?php 
									$all_customers1 = $all_customers;
									$customers ="";
									$customers = array('' => 'Select customer',);
									foreach($all_customers1 as $vndr)
									{
										if($vndr->customer_status==1)
										{
											$customer_id=$vndr->customer_id;
											$customer_name=$vndr->customer_name;
											$customers[$customer_id]=$customer_name;
										}
									}
									echo form_dropdown('customer_id', $customers,  set_value('customer_id'), ['class'=>'form-control','id'=>'customer_id','required'=>'required']);
							?>
							<?php echo form_error('customer_id');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Customer Name : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'customer_name','class'=>'form-control customer-details','id'=>'customer_name','required'=>'required','value'=>set_value('customer_name')]);?>
							<?php echo form_error('customer_name');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address : </label>
							<?php echo form_input(['name'=>'customer_address','class'=>'form-control customer-details','id'=>'customer_address','value'=>set_value('customer_address')]);?>
							<?php echo form_error('customer_address');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact No : </label>
							<?php echo form_input(['name'=>'customer_contact_no','class'=>'form-control customer-details', 'id'=>'customer_contact_no','value'=>set_value('customer_contact_no')]);?>
							<?php echo form_error('customer_contact_no');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<?php echo form_input(['name'=>'customer_contact_person','class'=>'form-control customer-details', 'id'=>'customer_contact_person','value'=>set_value('customer_contact_person')]);?>
							<?php echo form_error('customer_contact_person');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Id : </label>
							<?php echo form_input(['name'=>'customer_email_id','class'=>'form-control customer-details', 'id'=>'customer_email_id','value'=>set_value('customer_email_id')]);?>
							<?php echo form_error('customer_email_id');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Outstanding : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'customer_outstand','class'=>'form-control customer-details','required'=>'required', 'id'=>'customer_outstand','value'=>set_value('customer_outstand')]);?>
							<?php echo form_error('customer_outstand');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">GST No : </label>
							<?php echo form_input(['name'=>'customer_gst_no','class'=>'form-control customer-details', 'id'=>'customer_gst_no','value'=>set_value('customer_gst_no')]);?>
							<?php echo form_error('customer_gst_no');?>
						</div>
                     </div>
					
				</div>
				<div class="row" style="margin-top:3%">
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Paid Amount : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'paid_amount','class'=>'form-control paid_amount', 'required'=>'required','id'=>'paid_amount','value'=>set_value('paid_amount')]);?>
							<?php echo form_error('paid_amount');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Remained Amount : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'remained_amount','class'=>'form-control','readonly'=>'readonly','required'=>'required', 'id'=>'remained_amount','value'=>set_value('remained_amount')]);?>
							<?php echo form_error('remained_amount');?>
						</div>
                     </div>
					  <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Note : </label>
							<?php echo form_input(['name'=>'paid_note','class'=>'form-control', 'id'=>'paid_note','value'=>set_value('paid_note')]);?>
							<?php echo form_error('paid_note');?>
						</div>
                     </div>
					  <div class="col-md-3">
                        <div class="form-group">
                         <button type="submit" id="save-btn" class="btn btn-info" ><span class="fa fa-save"></span>Save</button>
						 </div>
                     </div>
				</div>
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
<script>
var csrfName = '<?php echo $this->security->get_csrf_token_name();?>',
csrfHash = '<?php echo $this->security->get_csrf_hash();?>';
$('#customer_id').change(function(){
	
	var customer_id = $(this).val();
	if(customer_id != '')
	{
		$('#customer_name').val('');
		$('#customer_address').val('');
		$('#customer_contact_no').val('');
		$('#customer_contact_person').val('');
		$('#customer_email_id').val('');
		$('#customer_outstanding').val('');
		$('#customer_gst_no').val('');
		 $('.customer-details').attr('readonly', false);
		//Ajax request
		 $.ajax({
									       url      :  "<?php echo base_url()?>api/getCustomer/"+customer_id,
									      type      :  "POST",
									      data      :  {'csrf_test_name':csrfHash},
										 dataType   : 'json',
									      success   :  function(response){
											$('#customer_name').val(response.customer_name);
											$('#customer_address').val(response.customer_address);
											$('#customer_contact_no').val(response.customer_contact_no);
											$('#customer_contact_person').val(response.customer_contact_person);
											$('#customer_email_id').val(response.customer_email_id);
											$('#customer_outstand').val(response.customer_outstand);
											$('#customer_gst_no').val(response.customer_gst_no);
											$('#customer_name').focus();
											 $('.customer-details').attr('readonly', true);
									  },
									  error : function(){
										  alert('An Error has occured.Try after refreshing the page.');
										     $('#customer_name').val('');
											$('#customer_address').val('');
											$('#customer_contact_no').val('');
											$('#customer_contact_person').val('');
											$('#customer_email_id').val('');
											$('#customer_outstanding').val('');
											$('#customer_gst_no').val('');
											$('.customer-details').attr('readonly', false);
									  }
								  });
		//End AJAX request
	}
	else
	{
		$('#customer_name').val('');
		$('#customer_address').val('');
		$('#customer_contact_no').val('');
		$('#customer_contact_person').val('');
		$('#customer_email_id').val('');
		$('#customer_outstanding').val('');
		$('#customer_gst_no').val('');
		$('.customer-details').attr('readonly', false);
	}
});
$('#paid_amount').change(function(){
	var paid_amount = $('#paid_amount').val();
	var prev_outstand = $('#customer_outstand').val();
	var remaied_amount = $('#remained_amount').val();
	if(prev_outstand =='')
	{
		alert('Previous outstand in not available');
		$('#remained_amount').val('');
		$('#paid_amount').val('');
	}
	else
	{
		if(parseInt(paid_amount) > parseInt(prev_outstand))
		{
			$('#remained_amount').val('');
			$('#paid_amount').val('');
		}
		else
		{
			remaied_amount = prev_outstand - paid_amount;
			$('#remained_amount').val(remaied_amount);
		}
		
	}
});
</script>
<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>View All Invoice</strong></span>
					</div>
					<div class="col-md-6">
					<?php if(isset($all_bills)){ ?>
							<button class="btn btn-success" data-toggle="modal" data-target="#exportModal"><span class="fa fa-print"></span> Export</button>
					<?php } ?>
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/getInvoices');?>
			<div class="col-md-12 white-div">
				<div class="row dark-background">
					<div class="col-md-3">
                        <div class="form-group">
							<?php 
									$all_customers1 = $all_customers;
									$customers ="";
									$customers = array('' => 'Select customer',);
									foreach($all_customers1 as $vndr)
									{
										if($vndr->customer_status==1)
										{
											$customer_id=$vndr->customer_id;
											$customer_name=$vndr->customer_name;
											$customers[$customer_id]=$customer_name;
										}
									}
									echo form_dropdown('customer_id', $customers,  set_value('customer_id'), ['class'=>'form-control','id'=>'customer_id']);
							?>
							<?php echo form_error('customer_id');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Customer NO :</label>
							<?php echo form_input(['name'=>'customer_contact_no','class'=>'form-control customer-details','id'=>'customer_contact_no','value'=>set_value('customer_contact_no')]);?>
							<?php echo form_error('customer_contact_no');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">From Date :</label>
							<?php echo form_input(['type'=>'date','name'=>'from_date','class'=>'form-control customer-details','id'=>'from_date','value'=>set_value('from_date')]);?>
							<?php echo form_error('from_date');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">To Date : </label>
							<?php echo form_input(['type'=>'date','name'=>'to_date','class'=>'form-control customer-details', 'id'=>'to_date','value'=>set_value('to_date')]);?>
							<?php echo form_error('to_date');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Bill No : </label>
							<?php echo form_input(['name'=>'bill_no','class'=>'form-control customer-details', 'id'=>'bill_no','value'=>set_value('bill_no')]);?>
							<?php echo form_error('bill_no');?>
						</div>
                     </div>
					  <div class="col-md-3">
                        <div class="form-group">
							<?php 
									$pages_array = array('10'=>'Per Page','1'=>'1','10'=>'10','100'=>'100','200'=>'200','500'=>'500');
									if($this->session->userdata('searched_product_per_page'))
									{
										echo form_dropdown('per_page_row', $pages_array,  set_value('per_page_row',$this->session->userdata('searched_product_per_page')), ['class'=>'form-control','id'=>'per_page_row']);
									}
									else
									{
										echo form_dropdown('per_page_row', $pages_array,  set_value('per_page_row'), ['class'=>'form-control','id'=>'per_page_row']);
									}
							?>
							<?php echo form_error('per_page_row');?>
						</div>
                     </div>
					<div class="col-md-2">
						<div class="form-group">
                         <button class="btn btn-info"><span class='fa fa-search'></span> Search</button>
						</div>
					</div>
				</div>
				<?php if($all_bills) { ?>
				<div class="row" style="margin-top:3%">
					 <div class="col-md-12">
					 <?php if(count($all_bills) > 0){ ?>
						<div class="table-responsive">
							<table class="table">
								<thead><tr><td>Index</td><td>Bill Date</td><td>Bill No</td><td>Customer Name</td><td>Contact No</td><td>Address</td><td>Total Amount</td><td>Paid</td><td>Remained</td><td>Action</td></tr></thead>
								<tbody>
								<?php
								$i=1;
								foreach($all_bills as $bill)
								{
									?>
									<tr><td><?php echo $i;?></td><td><?php echo $bill->bill_date;?></td><td><?php echo $bill->bill_no;?></td><td><?php echo $bill->customer_name;?></td><td><?php echo $bill->customer_contact_no;?></td><td><?php echo $bill->customer_address;?></td><td><?php echo round($bill->total_amount,2);?></td><td><?php echo round($bill->paid_amount,2);?></td><td><?php echo round($bill->remained_amount,2);?></td><td><?php echo anchor('admin/viewInvoice/'.$bill->bill_id,'<button type="button" class="btn btn-success"><span class="fa fa-eye"></span>View</button>'); ?></td></tr>
									<?php
									$i++;
								}
								?>
								</tbody>
							</table>
						</div>
				<?php } else{
							?>
							<div class="alert alert-warning">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<i class="material-icons">close</i>
								</button>
								<span>
								<b> Warning - </b> You haven't addred any Invoice. Kindly click on "Add New Invoice" button. </span>
							</div>
							<?php
						}?>		
					 </div> 
				</div>
				<?php } ?>
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>

<!--Action modal-->	
 <div class="modal fade" id="exportModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
		  <!--Action buttons-->
		  <button type="button" id="export_to_excel" class="btn btn-primary">Get data in Excel</button>
		  <button type="button" id="export_to_print" class="btn btn-primary">Print</button>
        </div>
        <div class="modal-body">
          <div id="action_div">
		  
		  		<?php if(isset($all_bills)){ ?>
				<div class="row printable_div" style="margin-top:3%">
					 <div class="col-md-12 col-xs-12">
                        <div class="table-responsive">
							<table class="table table-bordered list-table">
								<thead><tr><td colspan="9"><center>Sales Report</center></td></tr></thead>
								<tbody>
								<tr><td colspan="9"><center>Report Date : <?php echo date('Y-m-d');?></center></td></tr>
								<tr><td>Index</td><td>Bill Date</td><td>Bill No</td><td>Customer Name</td><td>Contact No</td><td>Address</td><td>Total Amount</td><td>Paid</td><td>Remained</td></tr>
								<?php
								$i=1;
								foreach($all_bills as $bill)
								{
									?>
									<tr><td><?php echo $i;?></td><td><?php echo $bill->bill_date;?></td><td><?php echo $bill->bill_no;?></td><td><?php echo $bill->customer_name;?></td><td><?php echo $bill->customer_contact_no;?></td><td><?php echo $bill->customer_address;?></td><td><?php echo round($bill->total_amount,2);?></td><td><?php echo round($bill->paid_amount,2);?></td><td><?php echo round($bill->remained_amount,2);?></td></tr>
									<?php
									$i++;
								}
								?>
								</tbody>
							</table>
						</div>
                     </div>
				</div>
				<div class="row">
					 <div class="col-md-12">
					 <?php echo $this->pagination->create_links();?>
					 </div>
				</div>
				<?php } ?>
		  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!--EndAction modal-->	
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
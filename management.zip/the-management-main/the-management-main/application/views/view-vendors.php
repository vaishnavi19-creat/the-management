<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Registered Vendors</strong></span>
					</div>
					<div class="col-md-6">
						<?php if(isset($all_vendors)){ ?>
							<button class="btn btn-success" data-toggle="modal" data-target="#exportModal"><span class="fa fa-print"></span> Export</button>
						<?php } ?>
					</div>
				</div>
            </div>
			
			<div class="col-md-12 white-div">
			<?php echo form_open('admin/getVendors');?>
				<div class="row">
					<div class="col-md-3">
						<div class="form-group">
                          <label class="bmd-label-floating">Vendor Name : </label>
							<?php 
							if($this->session->userdata('searched_vendor_name'))
							{
								echo form_input(['name'=>'vendor_name','class'=>'form-control','id'=>'vendor_name','value'=>set_value('vendor_name',$this->session->userdata('searched_vendor_name'))]);
							}
							else
							{
								echo form_input(['name'=>'vendor_name','class'=>'form-control','id'=>'vendor_name','value'=>set_value('vendor_name')]);
							}
							?>
							<?php echo form_error('vendor_name');?>
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
                          <label class="bmd-label-floating">Contact No: </label>
							<?php 
							if($this->session->userdata('searched_vendor_contact_no'))
							{
								echo form_input(['name'=>'vendor_contact_no','class'=>'form-control','id'=>'vendor_contact_no','value'=>set_value('vendor_contact_no',$this->session->userdata('searched_vendor_contact_no'))]);
							}
							else
							{
								echo form_input(['name'=>'vendor_contact_no','class'=>'form-control','id'=>'vendor_contact_no','value'=>set_value('vendor_contact_no')]);
							} 
							echo form_error('vendor_contact_no');?>
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
                          <label class="bmd-label-floating">Address : </label>
							<?php 
							if($this->session->userdata('searched_vendor_address'))
							{
								echo form_input(['name'=>'vendor_address','class'=>'form-control','id'=>'vendor_address','value'=>set_value('vendor_address',$this->session->userdata('searched_vendor_address'))]);
							}
							else
							{
								echo form_input(['name'=>'vendor_address','class'=>'form-control','id'=>'vendor_address','value'=>set_value('vendor_address')]);
							}
							 echo form_error('vendor_address');?>
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<?php
							if($this->session->userdata('searched_vendor_contact_person'))
							{
								echo form_input(['name'=>'vendor_contact_person','class'=>'form-control','id'=>'vendor_contact_person','value'=>set_value('vendor_contact_person',$this->session->userdata('searched_vendor_contact_person'))]);
							}
							else
							{
								echo form_input(['name'=>'vendor_contact_person','class'=>'form-control','id'=>'vendor_contact_person','value'=>set_value('vendor_contact_person')]);
							}
							echo form_error('vendor_contact_person');?>
						</div>
					</div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Per page: </label>
							<?php 
									$pages_array = array('1'=>'1','10'=>'10','100'=>'100','200'=>'200','500'=>'500');
									if($this->session->userdata('searched_vendor_per_page'))
									{
										echo form_dropdown('per_page_row', $pages_array,  set_value('per_page_row',$this->session->userdata('searched_vendor_per_page')), ['class'=>'form-control','id'=>'per_page_row']);
									}
									else
									{
										echo form_dropdown('per_page_row', $pages_array,  set_value('per_page_row'), ['class'=>'form-control','id'=>'per_page_row']);
									}
							?>
							<?php echo form_error('per_page_row');?>
						</div>
                     </div>
					<div class="col-md-3">
						<div class="form-group">
                         <button class="btn btn-info"><span class='fa fa-search'></span> Search</button>
						</div>
					</div>
				</div>
				<?php echo form_close();?>
				<div class="row">
					 <div class="col-md-12">
					 <?php if($all_vendors && count($all_vendors)>0){ ?>
						<div class="table-responsive">
							<table class="table table-bordered">
								<thead><tr><td>Index</td><td>Vendor Id</td><td>Vendor Name</td><td>Address</td><td>Contact Person</td><td>Contact Number</td><td>Email Id</td><td>GST</td><td>Outstand</td><td>Action</td></tr></thead>
								<tbody>
									<?php
									$i=1;
										foreach($all_vendors as $vendor)
										{
											if($vendor->vendor_status==1)
											{
											?>
											<tr><td><?php echo $i;?></td><td><?php echo $vendor->vendor_id;?></td><td><?php echo $vendor->vendor_name;?></td><td><?php echo $vendor->vendor_address;?></td><td><?php echo $vendor->vendor_contact_person;?></td><td><?php echo $vendor->vendor_contact_no;?></td><td><?php echo $vendor->vendor_email_id;?></td><td><?php echo $vendor->vendor_gst_no;?></td><td><?php echo $vendor->vendor_outstand;?></td><td><?php echo anchor('admin/editVendor/'.$vendor->vendor_id,'<button class="btn btn-success">Edit</button>');?><?php echo anchor('admin/deleteVendor/'.$vendor->vendor_id,'<button class="btn btn-danger">Delete</button>');?></td></tr>
											<?php
											$i++;
											}
										}										
									?>
								</tbody>
							</table>
						</div> 
						<?php } else{
							?>
							<div class="alert alert-warning">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<i class="material-icons">close</i>
								</button>
								<span>
								<b> Warning - </b> You haven't addred any vendor details. Kindly click on "Add New Vendor" button. </span>
							</div>
							<?php
						}?>						
                     </div>
				</div>
				<div class="row">
					 <div class="col-md-12">
					 <?php echo $this->pagination->create_links();?>
					 </div>
				</div>
				
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			
<!--Action modal-->	
 <div class="modal fade" id="exportModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
		  <!--Action buttons-->
		  <button type="button" id="export_to_excel" class="btn btn-primary">Get data in Excel</button>
		  <button type="button" id="export_to_print" class="btn btn-primary">Print</button>
        </div>
        <div class="modal-body">
          <div id="action_div">
		  
		  		<?php if(isset($all_vendors)){ ?>
				<div class="row printable_div" style="margin-top:3%">
					 <div class="col-md-12 col-xs-12">
                        <div class="table-responsive">
							<table class="table table-bordered list-table">
								<thead><tr><td colspan="8"><center>Vendors Report</center></td></tr></thead>
								<tbody>
								<tr><td colspan="8"><center>Report Date : <?php echo date('Y-m-d');?></center></td></tr>
								<tr><td>Index</td><td>Vendor Name</td><td>Address</td><td>Contact Person</td><td>Contact Number</td><td>Email Id</td><td>GST</td><td>Outstand</td></tr>
									<?php
									$i=1;
										foreach($all_vendors as $vendor)
										{
											if($vendor->vendor_status==1)
											{
											?>
											<tr><td><?php echo $i;?></td><td><?php echo $vendor->vendor_name;?></td><td><?php echo $vendor->vendor_address;?></td><td><?php echo $vendor->vendor_contact_person;?></td><td><?php echo $vendor->vendor_contact_no;?></td><td><?php echo $vendor->vendor_email_id;?></td><td><?php echo $vendor->vendor_gst_no;?></td><td><?php echo $vendor->vendor_outstand;?></td></tr>
											<?php
											$i++;
											}
										}										
									?>
								</tbody>
							</table>
						</div>
                     </div>
				</div>
				<div class="row">
					 <div class="col-md-12">
					 <?php echo $this->pagination->create_links();?>
					 </div>
				</div>
				<?php } ?>
		  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!--EndAction modal-->				
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
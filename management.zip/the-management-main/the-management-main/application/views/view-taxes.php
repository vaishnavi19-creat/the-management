<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Registered Taxes</strong></span>
					</div>
					<div class="col-md-6">
						
							<?php echo anchor('admin/addTaxes','<button class="btn btn-success"><span class="fa fa-eye"></span> Add New Tax</button>',['class'=>'pull-right']);?>
						
					</div>
				</div>
            </div>
			
			<div class="col-md-12 white-div">
				<div class="row">
					 <div class="col-md-12">
					 <?php if($all_taxes && count($all_taxes)>0){ ?>
						<div class="table-responsive">
							<table class="table table-bordered">
								<thead><tr><td>Index</td><td>Tax Name</td><td>Amount (%)</td><td>Action</td></tr></thead>
								<tbody>
									<?php
									$i=1;
										foreach($all_taxes as $tax)
										{
											if($tax->tax_status==1)
											{
											?>
											<tr><td><?php echo $i;?></td><td><?php echo $tax->tax_name;?></td><td><?php echo $tax->tax_amount;?></td><td><?php echo anchor('admin/editTax/'.$tax->tax_id,'<button class="btn btn-success">Edit</button>');?><?php echo anchor('admin/deleteTax/'.$tax->tax_id,'<button class="btn btn-danger">Delete</button>');?></td></tr>
											<?php
											$i++;
											}
										}										
									?>
								</tbody>
							</table>
						</div> 
						<?php } else{
							?>
							<div class="alert alert-warning">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<i class="material-icons">close</i>
								</button>
								<span>
								<b> Warning - </b> You haven't addred any tax details. Kindly click on "Add New Tax" button. </span>
							</div>
							<?php
						}?>						
                     </div>
				</div>
				
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Create Tax Invoice</strong></span>
					</div>
					<div class="col-md-6">
							<?php echo anchor('admin/viewTaxInvoices','<button class="btn btn-success"><span class="fa fa-eye"></span> View All customers</button>',['class'=>'pull-right']);?>
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/createTaxInvoice');?>
			<div class="col-md-12 white-div">
				<div class="row dark-background">
					<div class="col-md-3">
                        <div class="form-group">
							<?php 
									$all_customers1 = $all_customers;
									$customers ="";
									$customers = array('' => 'Select customer',);
									foreach($all_customers1 as $vndr)
									{
										if($vndr->customer_status==1)
										{
											$customer_id=$vndr->customer_id;
											$customer_name=$vndr->customer_name;
											$customers[$customer_id]=$customer_name;
										}
									}
									echo form_dropdown('customer_id', $customers,  set_value('customer_id'), ['class'=>'form-control','id'=>'customer_id']);
							?>
							<?php echo form_error('customer_id');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Customer Name : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'customer_name','class'=>'form-control customer-details','id'=>'customer_name','required'=>'required','value'=>set_value('customer_name')]);?>
							<?php echo form_error('customer_name');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'customer_address','class'=>'form-control customer-details','required'=>'required','id'=>'customer_address','value'=>set_value('customer_address')]);?>
							<?php echo form_error('customer_address');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact No : </label>
							<?php echo form_input(['name'=>'customer_contact_no','class'=>'form-control customer-details', 'id'=>'customer_contact_no','value'=>set_value('customer_contact_no')]);?>
							<?php echo form_error('customer_contact_no');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<?php echo form_input(['name'=>'customer_contact_person','class'=>'form-control customer-details', 'id'=>'customer_contact_person','value'=>set_value('customer_contact_person')]);?>
							<?php echo form_error('customer_contact_person');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Id : </label>
							<?php echo form_input(['name'=>'customer_email_id','class'=>'form-control customer-details', 'id'=>'customer_email_id','value'=>set_value('customer_email_id')]);?>
							<?php echo form_error('customer_email_id');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Outstanding : </label>
							<?php echo form_input(['name'=>'customer_outstand','class'=>'form-control customer-details', 'id'=>'customer_outstand','value'=>set_value('customer_outstand')]);?>
							<?php echo form_error('customer_outstand');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">GST No : </label>
							<?php echo form_input(['name'=>'customer_gst_no','class'=>'form-control customer-details', 'id'=>'customer_gst_no','value'=>set_value('customer_gst_no')]);?>
							<?php echo form_error('customer_gst_no');?>
						</div>
                     </div>
					
				</div>
				<div class="row" style="margin-top:3%">
					 <div class="col-md-3">
                        <div class="form-group">
							<?php 
									$all_products1 = $all_products;
									$products ="";
									$products = array('' => 'Select product',);
									foreach($all_products1 as $vndr)
									{
										if($vndr->product_status==1)
										{
											$product_id=$vndr->product_id;
											$product_name=$vndr->product_name;
											$products[$product_id]=$product_name;
										}
									}
									echo form_dropdown('product_main_id', $products,  set_value('product_main_id'), ['class'=>'form-control','id'=>'product_main_id']);
							?>
							<?php echo form_error('product_main_id');?>
						</div>
                     </div>
					 <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Quantity : </label>
							<?php echo form_input(['name'=>'product_main_quantity','class'=>'form-control product-details', 'id'=>'product_main_quantity','value'=>set_value('product_main_quantity')]);?>
							<?php echo form_error('product_main_quantity');?>
						</div>
                     </div>
					  <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Rate : </label>
							<?php echo form_input(['name'=>'product_main_rate','class'=>'form-control product-details', 'id'=>'product_main_rate','value'=>set_value('product_main_rate')]);?>
							<?php echo form_error('product_main_rate');?>
						</div>
                     </div>
					  <div class="col-md-3">
                        <div class="form-group">
                         <button type="button" id="add-product-btn" class="btn btn-info" ><span class="fa fa-plus"></span>Add</button>
						 </div>
                     </div>
				</div>
				<div class="row dark-background">
					 <div class="col-md-12">
                        <div class="table-responsive">
                         <table class="table table-bordered product_list_table" id="product_list_table">
							<thead><tr><td>Index</td><td>Product Name</td><td>Stock</td><td>Quantity</td><td>Rate</td><td>Total</td><td>Tax</td><td>Incl. Tax</td><td>Action</td></tr></thead>
                         </table>
						 <tbody id="product_list">
							
						 </tbody>
						 </div>
                     </div>
				</div>
				<div class="row" style="margin-top:3%">
					 <div class="col-md-4">
                        <div class="form-group">
							<div class="form-group">
							  <label class="bmd-label-floating">Total : </label>
								<?php echo form_input(['name'=>'total_amount','class'=>'form-control', 'id'=>'total_amount','readonly'=>'readonly','value'=>set_value('total_amount',00)]);?>
								<?php echo form_error('total_amount');?>
							</div>
						 </div>
                     </div>
					 <div class="col-md-4">
                        <div class="form-group">
							<div class="form-group">
							  <label class="bmd-label-floating">Discount ( % ): </label>
								<?php echo form_input(['name'=>'discount_amount','class'=>'form-control', 'id'=>'discount_amount','value'=>set_value('discount_amount',00)]);?>
								<?php echo form_error('discount_amount');?>
							</div>
						 </div>
                     </div>
					 <div class="col-md-4">
                        <div class="form-group">
							<div class="form-group">
							  <label class="bmd-label-floating">Final Amount : </label>
								<?php echo form_input(['name'=>'final_amount','readonly'=>'readonly','class'=>'form-control', 'id'=>'final_amount','value'=>set_value('final_amount',00)]);?>
								<?php echo form_error('final_amount');?>
							</div>
						 </div>
                     </div>
				</div>
				<div class="row" style="margin-top:3%">
					 <div class="col-md-4">
                        <div class="form-group">
							<div class="form-group">
							  <label class="bmd-label-floating">Paid Amount : </label>
								<?php echo form_input(['name'=>'paid_amount','class'=>'form-control', 'id'=>'paid_amount','value'=>set_value('paid_amount',00)]);?>
								<?php echo form_error('paid_amount');?>
							</div>
						 </div>
                     </div>
					 <div class="col-md-4">
                        <div class="form-group">
							<div class="form-group">
							  <label class="bmd-label-floating">Remained Amount : </label>
								<?php echo form_input(['name'=>'remained_amount','class'=>'form-control', 'readonly'=>'readonly','id'=>'remained_amount','value'=>set_value('remained_amount')]);?>
								<?php echo form_error('remained_amount');?>
							</div>
						 </div>
                     </div>
					 <div class="col-md-4">
                        <div class="form-group">
								<input type="submit" class="btn btn-success" value="Save"/>
						 </div>
                     </div>
				</div>				
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
<script>
var csrfName = '<?php echo $this->security->get_csrf_token_name();?>',
csrfHash = '<?php echo $this->security->get_csrf_hash();?>';
$('#customer_id').change(function(){
	
	var customer_id = $(this).val();
	if(customer_id != '')
	{
		$('#customer_name').val('');
		$('#customer_address').val('');
		$('#customer_contact_no').val('');
		$('#customer_contact_person').val('');
		$('#customer_email_id').val('');
		$('#customer_outstanding').val('');
		$('#customer_gst_no').val('');
		 $('.customer-details').attr('readonly', false);
		//Ajax request
		 $.ajax({
									       url      :  "<?php echo base_url()?>api/getCustomer/"+customer_id,
									      type      :  "POST",
									      data      :  {'csrf_test_name':csrfHash},
										 dataType   : 'json',
									      success   :  function(response){
											$('#customer_name').val(response.customer_name);
											$('#customer_address').val(response.customer_address);
											$('#customer_contact_no').val(response.customer_contact_no);
											$('#customer_contact_person').val(response.customer_contact_person);
											$('#customer_email_id').val(response.customer_email_id);
											$('#customer_outstand').val(response.customer_outstand);
											$('#customer_gst_no').val(response.customer_gst_no);
											$('#customer_name').focus();
											 $('.customer-details').attr('readonly', true);
									  },
									  error : function(){
										  alert('An Error has occured.Try after refreshing the page.');
										     $('#customer_name').val('');
											$('#customer_address').val('');
											$('#customer_contact_no').val('');
											$('#customer_contact_person').val('');
											$('#customer_email_id').val('');
											$('#customer_outstanding').val('');
											$('#customer_gst_no').val('');
											$('.customer-details').attr('readonly', false);
									  }
								  });
		//End AJAX request
	}
	else
	{
		$('#customer_name').val('');
		$('#customer_address').val('');
		$('#customer_contact_no').val('');
		$('#customer_contact_person').val('');
		$('#customer_email_id').val('');
		$('#customer_outstanding').val('');
		$('#customer_gst_no').val('');
		$('.customer-details').attr('readonly', false);
	}
});
var count = 1;
$('#add-product-btn').click(function(){
	var product_id = $('#product_main_id').val();
	var product_quantity = $('#product_main_quantity').val();
	var product_rate = $('#product_main_rate').val();
	if(product_id != '')
	{
		if(product_quantity == '')
		{
			product_quantity = 1;
		}
		//Ajax request
		 $.ajax({
									       url      :  "<?php echo base_url()?>api/getProduct/"+product_id,
									      type      :  "POST",
									      data      :  {'csrf_test_name':csrfHash},
										 dataType   : 'json',
									      success   :  function(response){
											  if(product_rate == '')
											  {
												  product_rate = response.product_mrp;
											  }
											 // $('#product_list_table').find('tbody').append( );
											 var temp = new Array();
											 temp = response.amounts.split(",");
											 for (a in temp ) 
											 {
												temp[a] = parseInt(temp[a], 10); // Explicitly include base as per Álvaro's comment
											 }
											 var tax_amount = temp.reduce((a, b) => a + b, 0);
											 var total = product_quantity*product_rate;
											 var total_tax = (tax_amount/100)*total;
											 var incl_tax = total + total_tax;
											 var inputs = '<input type="hidden" name="product_id[]" value="'+response.product_id+'" />'+'<input type="hidden" name="product_quantity[]" value="'+product_quantity+'" />'+'<input type="hidden" name="product_rate[]" value="'+product_rate+'" />'+ '<input type="hidden" name="product_taxes[]" value="'+response.product_taxes+'" />';
											  $("table.product_list_table").append("<tr><td>"+count+inputs+"</td><td>"+response.product_name+"</td><td>"+response.product_stock+"</td><td>"+product_quantity+"</td><td>"+product_rate+"</td><td>"+total+"</td><td>"+response.taxes+"("+tax_amount+")</td><td class='countable'>"+incl_tax+"</td><td><input type='button' class='deleteRow' value='-' /></td></tr>" );
											  count++;
											  calculate_grand()
											  $('#product_main_quantity').val('');
											  $('#product_main_rate').val('');
											  $('#product_main_id').val('');
											  $('#product_main_id').focus();
											
									  },
									  error : function(){
										  alert('An Error has occured.Try after refreshing the page.');
										    
									  }
								  });
		//End AJAX request
	}
	else
	{
		alert('Please select product');
	}
});
 $("table.product_list_table").on("click", ".deleteRow", function (event) {
		if(count > 1)
		{
			$(this).closest("tr").remove();
			count--;
			calculate_grand();
		}
});
function calculate_grand()
{
	var discount = $('#discount_amount').val();
	var remained = '';
	var paid = $('#paid_amount').val();
	if(discount == '')
	{
		discount = 0;
	}
	var sum = 0;
	var table = document.getElementById("product_list_table");
	var ths = table.getElementsByTagName('th');
	var tds = table.getElementsByClassName('countable');
	for(var i=0;i<tds.length;i++)
	{
		sum += isNaN(tds[i].innerText) ? 0 : parseInt(tds[i].innerText);
	}
	$('#total_amount').val(sum);
	var discount_amount = (discount/100)*sum;
	
	var final_total = sum - discount_amount;
	$('#final_amount').val(final_total);
	if(paid == '')
	{
		paid = 0;
	}
	remained = final_total - paid;
	$('#remained_amount').val(remained);
}
$('#discount_amount').change(function(){
	calculate_grand();
});
$('#paid_amount').change(function(){
	calculate_grand();
});
</script>
<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Register Product</strong></span>
					</div>
					<div class="col-md-6">
						
							<?php echo anchor('admin/getProducts','<button class="btn btn-success"><span class="fa fa-eye"></span> View All Products</button>',['class'=>'pull-right']);?>
						
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/addProduct');?>
			<div class="col-md-12 white-div">
				<div class="row">
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Product Name : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'product_name','class'=>'form-control','id'=>'product_name','required'=>'required','value'=>set_value('product_name')]);?>
							<?php echo form_error('product_name');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Stock : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'product_stock','class'=>'form-control','required'=>'required','id'=>'product_stock','value'=>set_value('product_stock')]);?>
							<?php echo form_error('product_stock');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Unit : </label>
							<?php echo form_input(['name'=>'product_unit','class'=>'form-control', 'id'=>'product_unit','value'=>set_value('product_unit','PC')]);?>
							<?php echo form_error('product_unit');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Min Stock : </label>
							<?php echo form_input(['name'=>'product_min_stock','class'=>'form-control', 'id'=>'product_min_stock','value'=>set_value('product_min_stock')]);?>
							<?php echo form_error('product_min_stock');?>
						</div>


						<!--Added expiry date -->

						<div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Expiry Date : </label>
							<?php echo form_input(['name'=>'product_expiry_date','class'=>'form-control', 'id'=>'product_expiry_date','value'=>set_value('product_expiry_date')]);?>
							<?php echo form_error('product_expiry_date');?>
						</div>

                       <!-- Added  batch no -->
					   
					   <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Batch Number : </label>
							<?php echo form_input(['name'=>'product_batch_no','class'=>'form-control', 'id'=>'product_batch_no','value'=>set_value('product_batch_no')]);?>
							<?php echo form_error('product_batch_no');?>
						</div>
						<!--end-->

                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">HSN Code : </label>
							<?php echo form_input(['name'=>'product_hsn_code','class'=>'form-control', 'id'=>'product_hsn_code','value'=>set_value('product_hsn_code')]);?>
							<?php echo form_error('product_hsn_code');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">MRP : </label>
							<?php echo form_input(['name'=>'product_mrp','class'=>'form-control', 'id'=>'product_mrp','value'=>set_value('product_mrp')]);?>
							<?php echo form_error('product_mrp');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">ASP : </label>
							<?php echo form_input(['name'=>'product_asp','class'=>'form-control', 'id'=>'product_asp','value'=>set_value('product_asp')]);?>
							<?php echo form_error('product_asp');?>
						</div>
                     </div>

					 

					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Discription : </label>
							<?php echo form_input(['name'=>'product_discription','class'=>'form-control', 'id'=>'product_discription','value'=>set_value('product_discription')]);?>
							<?php echo form_error('product_discription');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Taxes : </label>
							<?php 
									$all_taxes1 = $all_taxes;
									$taxes ="";
									$taxes = array('' => 'Select Tax',);
									foreach($all_taxes1 as $tx)
									{
										if($tx->tax_status==1)
										{
											$tax_id=$tx->tax_id;
											$tax_name=$tx->tax_name;
											$taxes[$tax_id]=$tax_name;
										}
									}
									echo form_dropdown('product_taxes[]', $taxes,  set_value('product_taxes[]'), ['class'=>'form-control','id'=>'product_taxres','multiple'=>'multiple']);
							?>
							<?php echo form_error('product_taxes[]');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Vendor : </label>
							<?php 
									$all_vendors1 = $all_vendors;
									$vendors ="";
									$vendors = array('' => 'Select Vendor',);
									foreach($all_vendors1 as $vndr)
									{
										if($vndr->vendor_status==1)
										{
											$vendor_id=$vndr->vendor_id;
											$vendor_name=$vndr->vendor_name;
											$vendors[$vendor_id]=$vendor_name;
										}
									}
									echo form_dropdown('product_vendor_code', $vendors,  set_value('product_vendor_code'), ['class'=>'form-control','id'=>'product_vendor_code']);
							?>
							<?php echo form_error('product_vendor_code');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                         <input type="submit" class="btn btn-success" value="Save"/>
						 </div>
                     </div>
				</div>
				
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
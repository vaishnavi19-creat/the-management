<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Dashboard</strong></span>
					</div>
				</div>
            </div>
			
			<div class="col-md-12 white-div">
				<div class="row">
					
					 <div class="col-md-3">
                        <div class="card card-stats">
							<div class="card-header card-header-warning">
							  <div class="card-icon">
								<i class="fa fa-cube"><?php echo $all_products_count->total_count;?></i>
							  </div>
							  <h3 class="card-title"><?php echo anchor('admin/getProructs','View');?></h3>
							</div>
							<div class="card-footer">
							  <div class="stats">
								Items
							  </div>
							</div>
						  </div>
                     </div>
					 
					 <div class="col-md-3">
                        <div class="card card-stats">
							<div class="card-header card-header-warning">
							  <div class="card-icon">
								<i class="fa fa-users"><?php echo $all_customers_count->total_count;?></i>
							  </div>
							  <h3 class="card-title"><?php echo anchor('admin/getCustomers','View');?></h3>
							</div>
							<div class="card-footer">
							  <div class="stats">
								Customers
							  </div>
							</div>
						  </div>
                     </div>
					 
					  <div class="col-md-3">
                        <div class="card card-stats">
							<div class="card-header card-header-warning">
							  <div class="card-icon">
								<i class="fa fa-users"><?php echo $all_vendors_count->total_count;?></i>
							  </div>
							  <h3 class="card-title"><?php echo anchor('admin/getVendors','View');?></h3>
							</div>
							<div class="card-footer">
							  <div class="stats">
								Vendors
							  </div>
							</div>
						  </div>
                     </div>
					 
					 <div class="col-md-3">
                        <div class="card card-stats">
							<div class="card-header card-header-warning">
							  <div class="card-icon">
								<i class="fa fa-cube"><?php echo $all_min_stocked_count->total_count;?></i>
							  </div>
							  <h3 class="card-title"><?php echo anchor('admin/getLowStockProducts','View');?></h3>
							</div>
							<div class="card-footer">
							  <div class="stats">
								Low Stock
							  </div>
							</div>
						  </div>
                     </div>
					 
					 <div class="col-md-3">
                        <div class="card card-stats">
							<div class="card-header card-header-warning">
							  <div class="card-icon">
								<i class="fa fa-cube"><?php echo $todays_invoices_count->total_count;?></i>
							  </div>
							  <h3 class="card-title"><?php echo anchor('admin/getInvoices','View');?></h3>
							</div>
							<div class="card-footer">
							  <div class="stats">
								Today's Invoices
							  </div>
							</div>
						  </div>
                     </div>
					 
					  <div class="col-md-3">
                        <div class="card card-stats">
							<div class="card-header card-header-warning">
							  <div class="card-icon">
								<i class="fa fa-inr"><?php echo round($todays_invoices_count->total_sale);?></i>
							  </div>
							  <h3 class="card-title"><?php echo anchor('admin/getInvoices','View');?></h3>
							</div>
							<div class="card-footer">
							  <div class="stats">
								Today's Sale
							  </div>
							</div>
						  </div>
                     </div>
					 
					  <div class="col-md-3">
                        <div class="card card-stats">
							<div class="card-header card-header-warning">
							  <div class="card-icon">
								<i class="fa fa-inr"><?php echo round($all_customers_count->total_outstand);?></i>
							  </div>
							  <h3 class="card-title"><?php echo anchor('admin/getCustomers','View');?></h3>
							</div>
							<div class="card-footer">
							  <div class="stats">
								Inward Outstand
							  </div>
							</div>
						  </div>
                     </div>
					 
					 <div class="col-md-3">
                        <div class="card card-stats">
							<div class="card-header card-header-warning">
							  <div class="card-icon">
								<i class="fa fa-inr"><?php echo round($all_vendors_count->total_outstand);?></i>
							  </div>
							  <h3 class="card-title"><?php echo anchor('admin/getOutwardOutstand','View');?></h3>
							</div>
							<div class="card-footer">
							  <div class="stats">
								Outward Outstand
							  </div>
							</div>
						  </div>
                     </div>
					 
					 
				</div>
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url();?>thems/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="<?php echo base_url();?>thems/assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
	Tresability Management - Register PVMS Page
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <link href="<?php echo base_url();?>thems/assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <link href="<?php echo base_url();?>thems/assets/css/custome.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar sidebar-template" data-color="white">
      <div class="logo top-logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          <img src="<?php echo base_url();?>thems/assets/img/logo.jpg" style="width:130px;"/>
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav side-nav">
          <li class="nav-item active">
            <?php echo anchor('admin','<i class="fa fa-home"></i> <p>My Shop</p>',['class'=>'nav-link']); ?>
          </li>
		   <li class="nav-item">
            <?php echo anchor('admin/dashboard','<i class="fa fa-dashboard"></i> <p>Dashboard</p>',['class'=>'nav-link']); ?>
          </li>
		  
		  <li class="nav-item dropdown">
			  <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<i class="fa fa-text-height"></i>
				<span>Tax</span>
			  </a>
			  <div class="dropdown-menu" aria-labelledby="pagesDropdown">
				<div class="dropdown-divider"></div>
				<?php echo anchor('admin/addTax','<i class="fa fa-plus"></i> <p>Add Tax</p>',['class'=>'dropdown-item']); ?>
				<?php echo anchor('admin/getTaxes','<i class="fa fa-eye"></i> <p>View Taxes</p>',['class'=>'dropdown-item']); ?>
				<div class="dropdown-divider"></div>
			  </div>
          </li>
		  
          <li class="nav-item dropdown">
			  <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<i class="fa fa-user-circle"></i>
				<span>Vendor Master</span>
			  </a>
			  <div class="dropdown-menu" aria-labelledby="pagesDropdown1">
				<div class="dropdown-divider"></div>
				<?php echo anchor('admin/addVendor','<i class="fa fa-plus"></i> <p>Add Vendor</p>',['class'=>'dropdown-item']); ?>
				<?php echo anchor('admin/getVendors','<i class="fa fa-eye"></i> <p>View Vendors</p>',['class'=>'dropdown-item']); ?>
				<div class="dropdown-divider"></div>
			  </div>
          </li>
		  
		  <li class="nav-item dropdown">
			  <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<i class="fa fa-user"></i>
				<span>Customer Master</span>
			  </a>
			  <div class="dropdown-menu" aria-labelledby="pagesDropdown2">
				<div class="dropdown-divider"></div>
				<?php echo anchor('admin/addCustomer','<i class="fa fa-plus"></i> <p>Add Customer</p>',['class'=>'dropdown-item']); ?>
				<?php echo anchor('admin/getCustomers','<i class="fa fa-eye"></i> <p>View Customers</p>',['class'=>'dropdown-item']); ?>
				<div class="dropdown-divider"></div>
			  </div>
        </li>
		
		<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown3" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-cube"></i>
            <span>Product Master</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown3">
		    <div class="dropdown-divider"></div>
			<?php echo anchor('admin/addProduct','<i class="fa fa-plus"></i> <p>Add Product</p>',['class'=>'dropdown-item']); ?>
			 <?php echo anchor('admin/getProducts','<i class="fa fa-eye"></i> <p>View Products</p>',['class'=>'dropdown-item']); ?>
            <div class="dropdown-divider"></div>
          </div>
        </li>
		
		<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown4" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-file-o"></i>
            <span>Purchase Master</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown4">
           <?php echo anchor('admin/createPurchaseEntry','<i class="fa fa-plus"></i> <p>Purchase Entry</p>',['class'=>'dropdown-item']); ?>
          </div>
        </li>
		
		<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown5" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-file"></i>
            <span>Invoice Master</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown5">
		    <div class="dropdown-divider"></div>
			 <?php echo anchor('admin/createTaxInvoice','<i class="fa fa-plus"></i> <p>Create Tax Invoice</p>',['class'=>'dropdown-item']); ?>
			 <?php echo anchor('admin/createInvoice','<i class="fa fa-plus"></i> <p>Create Invoice</p>',['class'=>'dropdown-item']); ?>
			 <?php echo anchor('admin/getInvoices','<i class="fa fa-eye"></i> <p>View Invoices</p>',['class'=>'dropdown-item']); ?>
            <div class="dropdown-divider"></div>
          </div>
        </li>
		
		<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown6" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-exchange"></i>
            <span>Transactions</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown6">
		    <div class="dropdown-divider"></div>
			 <?php echo anchor('admin/inwardTransaction','<i class="fa fa-undo"></i> <p>Inward Transaction</p>',['class'=>'dropdown-item']); ?>
			 <?php echo anchor('admin/outwardTransaction','<i class="fa fa-repeat"></i> <p>Outward Transaction</p>',['class'=>'dropdown-item']); ?>
            <div class="dropdown-divider"></div>
          </div>
        </li>
		
		<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown7" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-list"></i>
            <span>Reports</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown7">
		    <div class="dropdown-divider"></div>
			 <?php echo anchor('admin/customerReport','<i class="fa fa-list"></i> <p>Customer Report</p>',['class'=>'dropdown-item']); ?>
			 <?php echo anchor('admin/vendorReport','<i class="fa fa-list"></i> <p>Vendor Report</p>',['class'=>'dropdown-item']); ?>
            <div class="dropdown-divider"></div>
          </div>
        </li>
		<li class="nav-item">
            <?php echo anchor('admin/logout','<i class="fa fa-sign-out"></i> <p>Logout</p>',['class'=>'nav-link']); ?>
        </li>
		<li class="nav-item">jnjnjkn
        </li>
		<li class="nav-item">
        </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="#dashboard.html">The Management</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
			  <?php echo anchor('admin/logout','<span class="fa fa-user"></span>'.$this->session->userdata('admin_full_name').'- Admin<p class="d-lg-none d-md-block">'.$this->session->userdata('admin_full_name').'- Admin</p>',['class'=>'nav-link']);?>
                 
				
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
	  
	  
	  
      <div class="content body-background">
        <div class="container-fluid">
          <div class="row">
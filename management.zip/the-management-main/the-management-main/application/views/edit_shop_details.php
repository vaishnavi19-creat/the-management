<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Shop Details</strong></span>
					</div>
					<div class="col-md-6">
						
							<?php echo anchor('admin/updateShopDetails','<button class="btn btn-success"><span class="fa fa-eye"></span> Update Shop Details</button>',['class'=>'pull-right']);?>
						
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/updateShopDetails');?>
			<div class="col-md-12 white-div">
			<?php if($shop_details){ ?>
				<div class="row">
					 <div class="col-md-12">
                        <center><img src="<?php echo base_url();?>thems/assets/img/<?php echo $shop_details->shop_logo;?>" id="shop_logo" class="img" style="width:200px;"></img></center>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Shop Name : </label>
							<?php echo form_input(['name'=>'shop_name','class'=>'form-control','id'=>'shop_name','value'=>set_value('shop_name',$shop_details->shop_name)]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address : </label>
							<?php echo form_input(['name'=>'shop_address','class'=>'form-control','id'=>'shop_address','value'=>set_value('shop_address',$shop_details->shop_address)]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact No : </label>
							<?php echo form_input(['name'=>'shop_contact_no','class'=>'form-control','id'=>'shop_contact_no','value'=>set_value('shop_contact_no',$shop_details->shop_contact_no)]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<?php echo form_input(['name'=>'shop_contact_person','class'=>'form-control','id'=>'shop_contact_person','value'=>set_value('shop_contact_person',$shop_details->shop_contact_person)]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">GST No : </label>
							<?php echo form_input(['name'=>'shop_gst_no','class'=>'form-control','id'=>'shop_gst_no','value'=>set_value('shop_gst_no',$shop_details->shop_gst_no)]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                         <input type="submit" value="Update" class="btn btn-success pull-right" />
							<?php echo form_upload(['name'=>'shop_logo','class'=>'form-control','id'=>'shop_logo1','accept'=>'image/*','value'=>set_value('shop_logo',$shop_details->shop_logo)]);?>
						</div>
                     </div>
				</div>
				<?php } else { ?>
					<div class="row">
					<div class="col-md-12">
                        <center><img src="<?php echo base_url();?>thems/assets/img/update_logo.png" id="shop_logo" class="img" style="width:200px;border:1px solid black;"></img></center>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Shop Name : </label>
							<?php echo form_input(['name'=>'shop_name','class'=>'form-control','id'=>'shop_name','value'=>set_value('shop_name')]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address : </label>
							<?php echo form_input(['name'=>'shop_address','class'=>'form-control','id'=>'shop_address','value'=>set_value('shop_address')]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact No : </label>
							<?php echo form_input(['name'=>'shop_contact_no','class'=>'form-control','id'=>'shop_contact_no','value'=>set_value('shop_contact_no')]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<?php echo form_input(['name'=>'shop_contact_person','class'=>'form-control','id'=>'shop_contact_person','value'=>set_value('shop_contact_person')]);?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">GST No : </label>
							<?php echo form_input(['name'=>'shop_gst_no','class'=>'form-control','id'=>'shop_gst_no','value'=>set_value('shop_gst_no')]);?>
						</div>
                     </div>
					  <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"> </label>
							<?php echo form_upload(['name'=>'shop_logo','class'=>'form-control','id'=>'shop_logo1','accept'=>'image/*','value'=>set_value('shop_logo')]);?>
						</div>
                     </div>
				</div>
				<?php } ?>
				
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
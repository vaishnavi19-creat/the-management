<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
		date_default_timezone_set("Asia/Kolkata");
	}

	public function getCustomer($customer_id = null)
	{
		if($customer_id)
		{
			$customer_details = $this->admin_model->get_customer($customer_id);
			if($customer_details)
			{
				echo json_encode($customer_details);
			}
		}
	}
	
	public function getProduct($product_id = null)
	{
		if($product_id)
		{
			$product_details = $this->admin_model->get_product($product_id);
			if($product_details)
			{
				echo json_encode($product_details);
			}
		}
	}
	
	public function getVendor($vendor_id = null)
	{
		if($vendor_id)
		{
			$vendor_details = $this->admin_model->get_vendor($vendor_id);
			if($vendor_details)
			{
				echo json_encode($vendor_details);
			}
		}
	}
	
	private function _flashdatacheck($successfull, $successMessage, $failureMessage, $redirectTo)
	{
		if($successfull)
		{
			    $this->session->set_flashdata('feedback',$successMessage);
				$this->session->set_flashdata('feedback_Class',"alert-success");
		}
		else
		{
			    $this->session->set_flashdata('feedback',$failureMessage);
				$this->session->set_flashdata('feedback_Class',"alert-danger");
		}
		return redirect($redirectTo);
	}
}

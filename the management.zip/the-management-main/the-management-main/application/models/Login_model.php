<?php

Class Login_model extends CI_Model
{
	
	public function validate_admin($login_details)
	{
		$user_name = $login_details['username'];
		$password = $login_details['password'];
		$is_valid = $this->db->select('admin_mstr.*')->from('admin_mstr')->where(['admin_username'=>$user_name])->get();
		$is_valid = $is_valid->row(); 
			 if($is_valid)
			 {
				 if($is_valid->admin_password === $password && $is_valid->admin_status == 1)
				 {
					return $is_valid;
				 }
				 else
				 {
					 return false;
				 }
		     }
			 else
			 {
				 return false;
			 }
	}
	
}

?>
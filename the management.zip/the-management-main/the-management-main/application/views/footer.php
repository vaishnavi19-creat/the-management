 </div>
        </div>
      </div>
	  
	  
	  
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="<?php echo base_url();?>thems/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>thems/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>thems/assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>thems/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="<?php echo base_url();?>thems/assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="<?php echo base_url();?>thems/assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo base_url();?>thems/assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="<?php echo base_url();?>thems/assets/demo/demo.js"></script>
  <script src="<?php echo base_url();?>thems/assets/js/jquery.table2excel.js"></script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();

    });
	$('#shop_logo').click(function(){
		$('#shop_logo1').click();
	});
  </script>
  <script>
$("#export_to_print").click(function () {
		
        var contents = $(".printable_div").html();
        var frame1 = $('<iframe />');
        frame1[0].name = "frame1";
        frame1.css({ "position": "absolute", "top": "-1000000px" });
        $("body").append(frame1);
        var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
        frameDoc.document.open();
        //Create a new HTML document.
        frameDoc.document.write('<html><head><title> Printing Page </title>');
        frameDoc.document.write('</head><body>');
        //Append the external CSS file.
        frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url();?>thems/assets/css/material-dashboard.css?v=2.1.0">');
		frameDoc.document.write('<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>thems/assets/css/custome.css">');
		//Append the DIV contents.
        frameDoc.document.write(contents);
        frameDoc.document.write('</body></html>');
        frameDoc.document.close();
        setTimeout(function () {
            window.frames["frame1"].focus();
            window.frames["frame1"].print();
            frame1.remove();
        }, 500);
    });
	$('#export_to_excel').click(function(){
		$(".list-table").table2excel({
					exclude: ".action",
					name: "Excel report",
					filename: "Excel Report",
					fileext: ".xls",
					exclude_img: true,
					exclude_links: true,
					exclude_inputs: true
				});
		
		
	});
</script>
<script>
	$(document).on("keypress", ":input:not(textarea):not([type=submit])", function(event) {
    if (event.keyCode == 13) {
        event.preventDefault();
		}
	});
	window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(1000, function(){
        $(this).remove(); 
    });
	}, 3000);
	$(".entry-form").submit(function () {
		$(this).find(':submit').value('Please wait...');
        $(this).find(':submit').attr('disabled', 'disabled');
        return true;
    });
	
<?php if ($error=$this->session->flashdata('feedback')){ ?>
	alert('<?php echo $error;?>');
<?php } ?>
</script>

</body>

</html>
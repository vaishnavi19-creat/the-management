<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Update Tax</strong></span>
					</div>
					<div class="col-md-6">
						
							<?php echo anchor('admin/getTaxes','<button class="btn btn-success"><span class="fa fa-eye"></span> View All Taxes</button>',['class'=>'pull-right']);?>
						
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/editTax/'.$tax_details->tax_id);?>
			<div class="col-md-12 white-div">
				<div class="row">
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Tax Name : </label>
							<?php echo form_input(['name'=>'tax_name','class'=>'form-control','id'=>'tax_name','required'=>'required','value'=>set_value('tax_name',$tax_details->tax_name)]);?>
							<?php echo form_error('tax_name');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Anount(%) : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'tax_amount','class'=>'form-control','required'=>'required','id'=>'tax_amount','value'=>set_value('tax_amount',$tax_details->tax_amount)]);?>
							<?php echo form_error('tax_amount');?>
						</div>
                     </div>
				</div>
				<div class="row">
					 <div class="col-md-6">
                        <div class="form-group">
                         <input type="submit" class="btn btn-success" value="Update"/>
						 </div>
                     </div>
				</div>
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Update Customer</strong></span>
					</div>
					<div class="col-md-6">
						
							<?php echo anchor('admin/getCustomers','<button class="btn btn-success"><span class="fa fa-eye"></span> View All customers</button>',['class'=>'pull-right']);?>
						
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/editCustomer/'.$customer_details->customer_id);?>
			<div class="col-md-12 white-div">
				<div class="row">
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Customer Name : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'customer_name','class'=>'form-control','id'=>'customer_name','required'=>'required','value'=>set_value('customer_name',$customer_details->customer_name)]);?>
							<?php echo form_error('customer_name');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'customer_address','class'=>'form-control','required'=>'required','id'=>'customer_address','value'=>set_value('customer_address',$customer_details->customer_address)]);?>
							<?php echo form_error('customer_address');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact No : </label>
							<?php echo form_input(['name'=>'customer_contact_no','class'=>'form-control', 'id'=>'customer_contact_no','value'=>set_value('customer_contact_no',$customer_details->customer_contact_no)]);?>
							<?php echo form_error('customer_contact_no');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<?php echo form_input(['name'=>'customer_contact_person','class'=>'form-control', 'id'=>'customer_contact_person','value'=>set_value('customer_contact_person',$customer_details->customer_contact_person)]);?>
							<?php echo form_error('customer_contact_person');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Id : </label>
							<?php echo form_input(['name'=>'customer_email_id','class'=>'form-control', 'id'=>'customer_email_id','value'=>set_value('customer_email_id',$customer_details->customer_email_id)]);?>
							<?php echo form_error('customer_email_id');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Outstanding : </label>
							<?php echo form_input(['name'=>'customer_outstand','class'=>'form-control', 'id'=>'customer_outstand','value'=>set_value('customer_outstand',$customer_details->customer_outstand)]);?>
							<?php echo form_error('customer_outstand');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">GST No : </label>
							<?php echo form_input(['name'=>'customer_gst_no','class'=>'form-control', 'id'=>'customer_gst_no','value'=>set_value('customer_gst_no',$customer_details->customer_gst_no)]);?>
							<?php echo form_error('customer_gst_no');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                         <input type="submit" class="btn btn-success" value="Save"/>
						 </div>
                     </div>
				</div>
				
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
<?php include('header.php');?>
<style>
.hide {
	display:none;
}
    .page {
      width: 210mm;
      min-height: 297mm;
      padding: 20mm;
      margin: 10mm auto;
      border: 1px #D3D3D3 solid;
      border-radius: 5px;
      background: white;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }

    @page {
      size: A4;
      margin: 0;
    }

    @media print {

      html,
      body {
        width: 210mm;
        height: 297mm;
      }

      .page {
        margin: 0;
        border: initial;
        border-radius: initial;
        width: initial;
        min-height: initial;
        box-shadow: initial;
        background: initial;
        page-break-after: always;
		color : red;
		font-size : 10px;
      }
    }

</style>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 col-xs-12 white-div">
				<div class="row">
					<div class="col-md-6 col-xs-6">
						<span><strong>Estimate</strong></span>
					</div>
					<div class="col-md-6 col-xs-6">
							<?php echo anchor('admin/createInvoice','<button class="btn btn-success"><span class="fa fa-eye"></span> Create New Invoice</button>',['class'=>'pull-left']);?>
							<button class="btn btn-success pull-right print-btn"><span class="fa fa-print"></span> Print</button>
					</div>
				</div>
            </div>

			<div class="white-div printable" id="printable">
			<div class="table-responsive">
					<table class="table table-bordered">
						<tr>
							<td colspan="2">
								<center><strong>Estimate</strong></center>
							</td>
						</tr>
						<tr>
							<td align="left">
								<ul style="list-style-type: none;">
									<li><strong>From</strong></li>
									<li><strong><?php echo $shop_details->shop_name; ?></strong></li>
									<li><strong><?php echo $shop_details->shop_address; ?></strong>,</li>
									<li><strong><?php echo $shop_details->shop_contact_no; ?></strong>,</li>
									<li><strong><?php echo $shop_details->shop_contact_person; ?></strong>.</li>
									<li><strong><?php echo $shop_details->shop_gst_no; ?></strong>.</li>
								</ul>
							</td>
							<td align="left">
								<ul style="list-style-type: none;">
									<li><strong>To</strong></li>
									<li><strong><?php echo $invoice_details->customer_name; ?></strong>,</li>
									<li><strong><?php echo $invoice_details->customer_address; ?></strong>,</li>
									<li><strong><?php echo $invoice_details->customer_contact_no; ?></strong>.</li>
								</ul>
							</td>
						</tr>
						<tr>
							<td align="left"><b>Invoice No : </b><?php echo $invoice_details->bill_no; ?></td>
							<td align="right"><b>Dated On : </b><?php echo date("d-m-Y", strtotime( $invoice_details->bill_date ) ); ?></td>
						</tr>
						<tr>
							<td align="left"><b>Total ( &#8377 ) : </b><?php echo $invoice_details->final_amount; ?>/-</td>
							<td align="right"><b>Paid ( &#8377 ) : </b><?php echo $invoice_details->paid_amount; ?>/-</td>
						</tr>
					</table>
				</div>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead><tr><td colspan="<?php echo($invoice_details->tax_bill==1)?6:8 ?>" align="center"><strong>Product Details</strong></td></tr></thead>
						<tbody>
							<tr><td>Index</td><td>Item Name</td><td>Qty</td><td>Rate</td><td>Unit</td><td>Total</td><?php if($invoice_details->tax_bill==1){ ?><td>Tax</td><td>Incl.Tax</td><?php } ?></tr>
							
							<?php
								$i = 1;
								if(isset($billed_products))
								{
									$grand_total = 0;
									foreach($billed_products as $product)
									{
										$total = $product->product_quantity * $product->product_rate;
										?>
										<tr><td><?php echo $i;?></td><td><?php echo $product->product_name;?></td><td><?php echo $product->product_quantity;?></td><td><?php echo $product->product_rate;?></td><td><?php echo $product->product_unit;?></td><td><?php echo $product->product_rate * $product->product_quantity;?></td>
										<?php
										if($invoice_details->tax_bill==1)
										{
											?>
											<td><?php echo $product->total_taxes; ?> %</td>
											<td><?php 
											$final_total = $total + (($product->total_taxes/100)*$total);
											echo $final_total;
											?>
											</td>
											<?php
											$grand_total = $grand_total + $final_total;
										}
										else
										{
											$grand_total = $grand_total + $total;
										}
										?>
										</tr>
										<?php
										$i++;
									}
									if($invoice_details->tax_bill==1)
									{
										?>
										<tr><td colspan="7" align="right">Net Total ( &#8377 )</td><td><?php echo round($grand_total,2);?></td></tr>
										<tr><td colspan="7" align="right">Discount @ <?php echo round($invoice_details->discount_amount,2);?> % ( &#8377 )</td><td><?php echo $grand_total-(($invoice_details->discount_amount/100)*$grand_total);?></td></tr>
										<tr><td colspan="7" align="right">Paid ( &#8377 )</td><td><?php echo round($invoice_details->paid_amount,2);?></td></tr>
										<tr><td colspan="7" align="right">Outstand ( &#8377 )</td><td><?php echo round($invoice_details->remained_amount,2);?></td></tr>
										<?php
									}
									else
									{
										?>
										<tr><td colspan="5" align="right">Net Total ( &#8377 )</td><td><?php echo round($grand_total,2);?></td></tr>
										<tr><td colspan="5" align="right">Discount @ <?php echo $invoice_details->discount_amount;?> % ( &#8377 )</td><td><?php echo round($grand_total-(($invoice_details->discount_amount/100)*$grand_total),2);?></td></tr>
										<tr><td colspan="5" align="right">Paid ( &#8377 )</td><td><?php echo round($invoice_details->paid_amount,2);?></td></tr>
										<tr><td colspan="5" align="right">Outstand ( &#8377 )</td><td><?php echo round($invoice_details->remained_amount,2);?></td></tr>
										<?php
									}
								}
							?>
							<tr><td colspan="<?php echo($invoice_details->tax_bill==1)?6:8 ?>" align="center"><strong>THANK YOU! VISIT AGAIN....</strong></td></tr>
						</tbody>
					</table>
				</div>
            </div>

			<div class="page hide" id="page">
				<div class="table-responsive">
					<table class="table">
						<tr>
							<td id="copyOne"></td>
							<td id="copyTwo"></td>
						</tr>
					</table>
				</div>
				<hr>
			</div>

<!-- Main designing ends here -->
<?php include('footer.php');?>

<script>

$(function () {
 $(".print-btn").click(function () {

var printableDivContent = document.getElementById('printable');
var copyOne = document.getElementById('copyOne');
var copyTwo = document.getElementById('copyTwo');
copyOne.innerHTML = printableDivContent.innerHTML;
copyTwo.innerHTML = printableDivContent.innerHTML;

 var contents = $(".page").html();
 var frame1 = $('<iframe />');
 frame1[0].name = "frame1";
 frame1.css({ "position": "absolute", "top": "-1000000px" });
 frame1.width = "210mm";
 $("body").append(frame1);
 var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
 frameDoc.document.open();
 frameDoc.document.write('<html><head><title>Estimate</title>');
 frameDoc.document.write('</head><body>');
 frameDoc.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" rel="stylesheet" type="text/css" />');
 frameDoc.document.write('<link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet" type="text/css" />');
 frameDoc.document.write('<link href="<?php echo base_url();?>thems/assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" type="text/css" />');
 frameDoc.document.write('<link href="<?php echo base_url();?>thems/assets/css/custome.css" rel="stylesheet" type="text/css" />');
 var source = '<?php echo base_url();?>thems/assets/js/core/jquery.min.js';
 var script = document.createElement('script');
 script.setAttribute('type', 'text/javascript');
 script.setAttribute('src', source);
 frameDoc.document.write(contents);
 frameDoc.document.write('</body></html>');
 frameDoc.document.close();
 setTimeout(function () {
 window.frames["frame1"].focus();
 window.frames["frame1"].print();
 frame1.remove();
 copyOne.innerHTML = '';
 copyTwo.innerHTML = '';
 }, 500);
 });
});
</script>
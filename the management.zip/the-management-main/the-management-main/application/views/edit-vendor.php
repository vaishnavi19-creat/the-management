<?php include('header.php');?>
           <!--Main designing goes here-->
		   
			<div class="col-md-12 white-div">
				<div class="row">
					<div class="col-md-6">
						<span><strong>Update Vendor</strong></span>
					</div>
					<div class="col-md-6">
						
							<?php echo anchor('admin/getVendors','<button class="btn btn-success"><span class="fa fa-eye"></span> View All Vendors</button>',['class'=>'pull-right']);?>
						
					</div>
				</div>
            </div>
			
			<?php echo form_open_multipart('admin/editVendor/'.$vendor_details->vendor_id);?>
			<div class="col-md-12 white-div">
				<div class="row">
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Vendor Name : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'vendor_name','class'=>'form-control','id'=>'vendor_name','required'=>'required','value'=>set_value('vendor_name',$vendor_details->vendor_name)]);?>
							<?php echo form_error('vendor_name');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address : <span class="text text-danger"> * </span></label>
							<?php echo form_input(['name'=>'vendor_address','class'=>'form-control','required'=>'required','id'=>'vendor_address','value'=>set_value('vendor_address',$vendor_details->vendor_address)]);?>
							<?php echo form_error('vendor_address');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact No : </label>
							<?php echo form_input(['name'=>'vendor_contact_no','class'=>'form-control', 'id'=>'vendor_contact_no','value'=>set_value('vendor_contact_no',$vendor_details->vendor_contact_no)]);?>
							<?php echo form_error('vendor_contact_no');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Contact Person : </label>
							<?php echo form_input(['name'=>'vendor_contact_person','class'=>'form-control', 'id'=>'vendor_contact_person','value'=>set_value('vendor_contact_person',$vendor_details->vendor_contact_person)]);?>
							<?php echo form_error('vendor_contact_person');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Id : </label>
							<?php echo form_input(['name'=>'vendor_email_id','class'=>'form-control', 'id'=>'vendor_email_id','value'=>set_value('vendor_email_id',$vendor_details->vendor_email_id)]);?>
							<?php echo form_error('vendor_email_id');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Outstanding : </label>
							<?php echo form_input(['name'=>'vendor_outstand','class'=>'form-control', 'id'=>'vendor_outstand','value'=>set_value('vendor_outstand',$vendor_details->vendor_outstand)]);?>
							<?php echo form_error('vendor_outstand');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">GST No : </label>
							<?php echo form_input(['name'=>'vendor_gst_no','class'=>'form-control', 'id'=>'vendor_gst_no','value'=>set_value('vendor_gst_no',$vendor_details->vendor_gst_no)]);?>
							<?php echo form_error('vendor_gst_no');?>
						</div>
                     </div>
					 <div class="col-md-6">
                        <div class="form-group">
                         <input type="submit" class="btn btn-success" value="Save"/>
						 </div>
                     </div>
				</div>
				
				
				<div class="row" style="color:white">
				<div class="col-md-12">
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
					<p>The Management Application is  useful for Managing all activities going in your shop.The Management Application is  useful for Managing all activities going in your shop.</p>
				</div>
				</div>
				
            </div>
			<?php echo form_close();?>
			
			
		   <!-- Main designing ends here -->
<?php include('footer.php');?>
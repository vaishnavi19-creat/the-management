<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="<?php echo base_url();?>thems/assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Smart Shop Management
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>thems/assets/css/material_icon.css" />
  <link rel="stylesheet" href="<?php echo base_url();?>thems/assets/css/font_awesome.min.css">
  <!-- CSS Files -->
  <link href="<?php echo base_url();?>thems/assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?php echo base_url();?>thems/assets/demo/demo.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>thems/assets/css/style.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>thems/assets/css/custome.css" rel="stylesheet" />
</head>
<body style="background-image: url(<?php echo base_url();?>thems/assets/img/72-01.jpg);background-repeat: no-repeat;background-size: cover;">
<div class="container-fluid">

      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
		 
          <div class="row" style="margin-top:10%;">
				
			<div class="col-md-8">
			</div>
            <div class="col-md-3 pull-left">
              <div class="card shadow-box" style="background  : #cacbc67d;border:10px solid white;">
               
                <div class="card-body">
				<?php echo form_open('login');?>
				   <div class="row" style="margin-top:-65px;">
						<div class="col-md-1">
						</div>
						<div class="col-md-7">
						<center>
							<img src="<?php echo base_url();?>thems/assets/img/logo.jpg" style="width:180px;height:auto;border:2px solid #73a5d2;"/>
						</center>
						</div>
						<div class="col-md-3">
						</div>
				   </div>
				   <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Username </label>
							<input type="text" name="username" class="form-control" required id="username" value="" />
						</div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password </label>
                          <input type="password" name="password" class="form-control" required id="password" value="" />
						</div>
                      </div>
                    </div>
					<div class="row">
						<div class="col-md-12">
								<button type="submit" class="btn btn-sm login-btn" id="login_btn"><span class="login-text">Login</span></button>
						</div>
					</div>
                <?php echo form_close();?>
					<div class="row">
						<?php if($this->session->flashdata('login_failed')){ echo '<span class="text text-danger" >Wrong username or password.</span>';} ?></span>
					</div>
				   <div class="row" style="margin-top:20px;">
						<!--<div class="col-md-6">
							<input type="checkbox" name="remember-me" id="remember-me" class="remember-me"><span>Remember Me<span>
						</div>-->
						<div class="col-md-12">
							<span class="pull-right forgot-password"><a href="forgot-password.html">Forgot Password?<a></span>
						</div>
				   </div>
				   
					<div class="clearfix"></div>
                </div>
              </div>
            </div>
			<div class="col-md-1">
		   </div>
          </div>
        </div>
      </div>
</div>

	  
  <script src="<?php echo base_url();?>thems/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>thems/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>thems/assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>thems/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
 <!-- Chartist JS -->
  <script src="<?php echo base_url();?>thems/assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="<?php echo base_url();?>thems/assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo base_url();?>thems/assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="<?php echo base_url();?>thems/assets/demo/demo.js"></script>
  <script src="<?php echo base_url();?>thems/assets/js/custom.js"></script>
 
</body>
</html>
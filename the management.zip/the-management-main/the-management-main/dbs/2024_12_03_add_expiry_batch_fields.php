<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Add_Expiry_Batch_Fields extends CI_Controller {
    public function up()
    {
        // Load the database library
        $this->load->database();

        // SQL query to alter the product table
        $sql = "
            ALTER TABLE `product` 
            ADD COLUMN `expiry_date` DATE NULL AFTER `existing_column`,
            ADD COLUMN `batch_no` VARCHAR(255) NULL AFTER `expiry_date`;
        ";

        // Execute the query
        if ($this->db->query($sql)) {
            echo "Migration completed: Added expiry_date and batch_no fields to product table.";
        } else {
            echo "Migration failed: " . $this->db->error();
        }
    }
}

-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2019 at 01:27 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `billing_work`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_mstr`
--

CREATE TABLE `admin_mstr` (
  `admin_id` varchar(50) NOT NULL,
  `admin_full_name` varchar(150) NOT NULL,
  `admin_added_date` varchar(50) NOT NULL,
  `admin_status` int(11) NOT NULL DEFAULT '1',
  `admin_username` varchar(10) NOT NULL,
  `admin_password` text NOT NULL,
  `admin_contact_number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_mstr`
--

INSERT INTO `admin_mstr` (`admin_id`, `admin_full_name`, `admin_added_date`, `admin_status`, `admin_username`, `admin_password`, `admin_contact_number`) VALUES
('151277', 'Shriyash Dindore', '2018-12-23', 1, 'shree', 'shree', '7028050808');

-- --------------------------------------------------------

--
-- Table structure for table `billed_product_mstr`
--

CREATE TABLE `billed_product_mstr` (
  `tr_id` varchar(50) NOT NULL,
  `bill_id` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `product_quantity` double NOT NULL,
  `product_rate` double NOT NULL,
  `applied_taxes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billed_product_mstr`
--

INSERT INTO `billed_product_mstr` (`tr_id`, `bill_id`, `product_id`, `product_quantity`, `product_rate`, `applied_taxes`) VALUES
('DbRjfun4s6toEON2ACgmPJ7Q0relKd', 'fD5B1PbFOlQwdh7z6UnZLvRTi20km', '4sjz7AJkiwh8FL3gQaxRvGdWZS', 5, 120, ',EKPceTk4G2lQ03i6Cu,u4ahw9JDIPGE6v8'),
('Ig13edJ4Plrx20GiyWuzVbQ7ncKOD', 'vxEb9YaXqJnM4OwUPcf3CR5ZD', '4sjz7AJkiwh8FL3gQaxRvGdWZS', 1, 300, ''),
('kXnTeYBF7WHfQ8gZIiGEN', 'fD5B1PbFOlQwdh7z6UnZLvRTi20km', 'OfCBwxHQnDoeSIr7Gl', 7, 80, 'EKPceTk4G2lQ03i6Cu,u4ahw9JDIPGE6v8'),
('tCcXJx1usPS0EM2l', 'vxEb9YaXqJnM4OwUPcf3CR5ZD', 'OfCBwxHQnDoeSIr7Gl', 1, 100, ''),
('UZ7DoAdlqvpwCN615XcHzMJ9kxgPny', 'fD5B1PbFOlQwdh7z6UnZLvRTi20km', 'GLS7Ehf6ncxaJ4VltkjFw2r10WKb', 5, 120, 'EKPceTk4G2lQ03i6Cu,u4ahw9JDIPGE6v8');

-- --------------------------------------------------------

--
-- Table structure for table `bill_mstr`
--

CREATE TABLE `bill_mstr` (
  `bill_id` varchar(50) NOT NULL,
  `bill_no` varchar(50) NOT NULL,
  `bill_date` varchar(50) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `tax_bill` int(11) NOT NULL DEFAULT '0',
  `total_amount` double NOT NULL,
  `discount_amount` double NOT NULL,
  `final_amount` double NOT NULL,
  `paid_amount` double NOT NULL,
  `remained_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill_mstr`
--

INSERT INTO `bill_mstr` (`bill_id`, `bill_no`, `bill_date`, `customer_id`, `tax_bill`, `total_amount`, `discount_amount`, `final_amount`, `paid_amount`, `remained_amount`) VALUES
('fD5B1PbFOlQwdh7z6UnZLvRTi20km', '2018122620451912', '2018-12-26 20:45:19', 'rudai5bjg4VITPm', 1, 2076, 10, 1868.4, 1700, 168.4000000000001),
('vxEb9YaXqJnM4OwUPcf3CR5ZD', '2018122621011412', '2019-01-05 21:01:14', 'NP6jXJ187mTtZOgKbeCx', 0, 400, 10, 360, 300, 60);

-- --------------------------------------------------------

--
-- Table structure for table `customer_mstr`
--

CREATE TABLE `customer_mstr` (
  `customer_id` varchar(50) NOT NULL,
  `customer_name` text NOT NULL,
  `customer_address` text NOT NULL,
  `customer_contact_person` varchar(50) NOT NULL,
  `customer_contact_no` varchar(50) NOT NULL,
  `customer_email_id` varchar(50) NOT NULL,
  `customer_gst_no` varchar(50) NOT NULL,
  `customer_outstand` double NOT NULL,
  `customer_status` int(11) NOT NULL DEFAULT '1',
  `customer_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_mstr`
--

INSERT INTO `customer_mstr` (`customer_id`, `customer_name`, `customer_address`, `customer_contact_person`, `customer_contact_no`, `customer_email_id`, `customer_gst_no`, `customer_outstand`, `customer_status`, `customer_added_date`) VALUES
('NP6jXJ187mTtZOgKbeCx', 'Mahesh Chavhan', 'Jamgaon', 'Mahesh Chavhan', '78451299', '', '', 160, 1, '2018-12-26 21:01:13'),
('NP6jXJ187OgKbeCx', 'Mehesh Chavhan', 'Jamgaon', 'Mahesh Chavhan', '78451299', '', '', 160, 1, '2018-12-26 21:01:13'),
('NP6jXJ187OgKuhiuh55beCx', 'Meresh Chavhan', 'Jamgaon', 'Mahesh Chavhan', '78451299', '', '', 160, 1, '2018-12-26 21:01:13'),
('rudai5bjg4VITPm', 'Shriyash Dindore', 'Vairag', 'Shriyash Dindore', '7028050808', 'shriyash3333@gmail.com', '', 68.40000000000009, 1, '2018-12-26 20:45:19');

-- --------------------------------------------------------

--
-- Table structure for table `customer_transactions`
--

CREATE TABLE `customer_transactions` (
  `c_transaction_id` varchar(50) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `c_transaction_date` varchar(50) NOT NULL,
  `c_transaction_discription` text NOT NULL,
  `c_transaction_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_transactions`
--

INSERT INTO `customer_transactions` (`c_transaction_id`, `customer_id`, `c_transaction_date`, `c_transaction_discription`, `c_transaction_amount`) VALUES
('iy4nPzBMeO1qJcRvmVWEH96gxbGA', 'NP6jXJ187mTtZOgKbeCx', '2018-12-26 21:01', 'Purchased of bill no2018122621011412', 60),
('jkBNc4wGS6vK7qgpsR2aiyWme5Eb', 'rudai5bjg4VITPm', '2018-12-27 20:10', 'Paid. Will pay on 28th dec 2018', 100),
('Lzkd2cRfZ8wD9qX', 'rudai5bjg4VITPm', '2018-12-26 20:45', 'Purchased of bill no2018122620451912', 168.4000000000001),
('RWHYDqGl4b2EX03ykKe', 'NP6jXJ187mTtZOgKbeCx', '2018-12-26 21:01', 'Initial balance(Prev.)', 100),
('VxorCydHYL80EwKuJ71XW', 'rudai5bjg4VITPm', '2018-12-26 20:45', 'Initial balance(Prev.)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_mstr`
--

CREATE TABLE `product_mstr` (
  `product_id` varchar(50) NOT NULL,
  `product_name` text NOT NULL,
  `product_stock` double NOT NULL,
  `product_unit` varchar(10) NOT NULL,
  `product_min_stock` double NOT NULL,
  `product_hsn_code` varchar(50) NOT NULL,
  `product_mrp` double NOT NULL,
  `product_asp` double NOT NULL,
  `product_discription` text NOT NULL,
  `product_taxes` text NOT NULL,
  `product_vendor_code` varchar(50) NOT NULL,
  `product_status` int(11) NOT NULL DEFAULT '1',
  `product_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_mstr`
--

INSERT INTO `product_mstr` (`product_id`, `product_name`, `product_stock`, `product_unit`, `product_min_stock`, `product_hsn_code`, `product_mrp`, `product_asp`, `product_discription`, `product_taxes`, `product_vendor_code`, `product_status`, `product_added_date`) VALUES
('4sjz7AJkiwh8FL3gQaxRvGdWZS', '5 HP Motor', 40, 'PC', 50, '121212', 150, 100, 'motor', ',EKPceTk4G2lQ03i6Cu,u4ahw9JDIPGE6v8', 'o8yA3rbxjhPgGiwT4Yk5lsJpOZKzU', 1, '2018-12-23 18:44:17'),
('GLS7Ehf6ncxaJ4VltkjFw2r10WKb', '10 HP Motor', 5, 'PC', 4, '15488', 100, 85, 'For motor', 'EKPceTk4G2lQ03i6Cu,u4ahw9JDIPGE6v8', 'o8yA3rbxjhPgGiwT4Yk5lsJpOZKzU', 1, '2018-12-25 10:13:01'),
('OfCBwxHQnDoeSIr7Gl', 'T - Joint', 2, 'PC', 100, '89666', 17, 15, 't- joint', 'EKPceTk4G2lQ03i6Cu,u4ahw9JDIPGE6v8', 'o8yA3rbxjhPgGiwT4Yk5lsJpOZKzU', 1, '2018-12-25 10:13:51');

-- --------------------------------------------------------

--
-- Table structure for table `shop_mstr`
--

CREATE TABLE `shop_mstr` (
  `shop_id` int(11) NOT NULL,
  `shop_name` text NOT NULL,
  `shop_address` text NOT NULL,
  `shop_contact_person` text NOT NULL,
  `shop_contact_no` varchar(70) NOT NULL,
  `shop_email_id` varchar(70) NOT NULL,
  `shop_gst_no` varchar(50) NOT NULL,
  `shop_logo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_mstr`
--

INSERT INTO `shop_mstr` (`shop_id`, `shop_name`, `shop_address`, `shop_contact_person`, `shop_contact_no`, `shop_email_id`, `shop_gst_no`, `shop_logo`) VALUES
(1, 'My Smart Shop', 'Vairag', 'Shriyash Dindore', '7028050808', 'shop@gmail.com', '1234567890', 'afmsd-logo2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tax_mstr`
--

CREATE TABLE `tax_mstr` (
  `tax_id` varchar(50) NOT NULL,
  `tax_name` varchar(50) NOT NULL,
  `tax_amount` double NOT NULL,
  `tax_added_date` varchar(50) NOT NULL,
  `tax_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax_mstr`
--

INSERT INTO `tax_mstr` (`tax_id`, `tax_name`, `tax_amount`, `tax_added_date`, `tax_status`) VALUES
('EKPceTk4G2lQ03i6Cu', 'CGST @9%', 9, '2018-12-23 13:06:22', 1),
('u4ahw9JDIPGE6v8', 'SGST @9%', 9, '2018-12-23 13:06:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_mstr`
--

CREATE TABLE `vendor_mstr` (
  `vendor_id` varchar(50) NOT NULL,
  `vendor_name` text NOT NULL,
  `vendor_address` text NOT NULL,
  `vendor_contact_person` varchar(50) NOT NULL,
  `vendor_contact_no` varchar(50) NOT NULL,
  `vendor_email_id` varchar(50) NOT NULL,
  `vendor_gst_no` varchar(50) NOT NULL,
  `vendor_outstand` double NOT NULL,
  `vendor_status` int(11) NOT NULL DEFAULT '1',
  `vendor_added_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_mstr`
--

INSERT INTO `vendor_mstr` (`vendor_id`, `vendor_name`, `vendor_address`, `vendor_contact_person`, `vendor_contact_no`, `vendor_email_id`, `vendor_gst_no`, `vendor_outstand`, `vendor_status`, `vendor_added_date`) VALUES
('5ZG8RQYWubXrlKmjE462Nq9V0MSt', 'Prasanna', 'Nashik', 'Prasanna Shinde', '9921357844', '', '', 1170, 1, '2018-12-23 14:57:16'),
('o8yA3rbxjhPgGiwT4Yk5lsJpOZKzU', 'CRI pumps', 'pune', 'Mr. Anil Shah', '7894561230', '', '', 100, 1, '2018-12-23 14:55:53');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_transactions`
--

CREATE TABLE `vendor_transactions` (
  `v_transaction_id` varchar(50) NOT NULL,
  `vendor_id` varchar(50) NOT NULL,
  `v_transaction_date` varchar(50) NOT NULL,
  `v_transaction_discription` text NOT NULL,
  `v_transaction_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_transactions`
--

INSERT INTO `vendor_transactions` (`v_transaction_id`, `vendor_id`, `v_transaction_date`, `v_transaction_discription`, `v_transaction_amount`) VALUES
('8pQBhxO1DeVGyF0XwsHN4am3rcbk', 'o8yA3rbxjhPgGiwT4Yk5lsJpOZKzU', '2018-12-23 15:30', 'Updated Entry', 100),
('BpMm0a6HjgA7GQn3VwD4ch', '5ZG8RQYWubXrlKmjE462Nq9V0MSt', '2018-12-23 15:26', 'Deleted Vendorr', 0),
('D9Qw8EUvhsWNgn01z54FcroB2RIOKX', '5ZG8RQYWubXrlKmjE462Nq9V0MSt', '2018-12-23 14:57', 'Initial balance(Prev.)', 200),
('L4GIYXrMDtzeuTPasBHhAxN2W1C', '5ZG8RQYWubXrlKmjE462Nq9V0MSt', '2018-12-27 21:32', 'Paid. ', 30),
('MqCz91dHfo2IGiOJWNb3', '5ZG8RQYWubXrlKmjE462Nq9V0MSt', '2018-12-23 15:22', 'Updated Entry', 200),
('vbzgcuXAW4p9oLDe5I', 'o8yA3rbxjhPgGiwT4Yk5lsJpOZKzU', '2018-12-23 14:55', 'Initial balance(Prev.)', 1000),
('YfqIesOtKN6Q1d23yLjbEnU9', '5ZG8RQYWubXrlKmjE462Nq9V0MSt', '2019-01-06 13:58', 'Purchased of bill no134. Paid 4000 And total amount5000', 4000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billed_product_mstr`
--
ALTER TABLE `billed_product_mstr`
  ADD PRIMARY KEY (`tr_id`);

--
-- Indexes for table `bill_mstr`
--
ALTER TABLE `bill_mstr`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `customer_mstr`
--
ALTER TABLE `customer_mstr`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_transactions`
--
ALTER TABLE `customer_transactions`
  ADD PRIMARY KEY (`c_transaction_id`);

--
-- Indexes for table `product_mstr`
--
ALTER TABLE `product_mstr`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `shop_mstr`
--
ALTER TABLE `shop_mstr`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `tax_mstr`
--
ALTER TABLE `tax_mstr`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `vendor_mstr`
--
ALTER TABLE `vendor_mstr`
  ADD PRIMARY KEY (`vendor_id`);

--
-- Indexes for table `vendor_transactions`
--
ALTER TABLE `vendor_transactions`
  ADD PRIMARY KEY (`v_transaction_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
